178-file selected known-hash baseline. Not a full repository, live database, or fresh whole-Drive export. No production credentials or original media included.
