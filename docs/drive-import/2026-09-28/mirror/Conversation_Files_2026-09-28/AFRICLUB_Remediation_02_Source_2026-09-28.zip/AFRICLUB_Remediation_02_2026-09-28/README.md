# AFRICLUB production remediation — continuation 02

This is a cumulative **scoped source candidate**, not a full repository export or a
production-ready application. `SOURCE_CHANGES.json` distinguishes inherited changes,
new authoring and one unchanged current-Drive migration prerequisite.

All new work and the prior unuploaded remediation deliverables are preserved here.
No Google Drive writes, deployments, migrations or permission changes were performed
in this continuation. `UPLOAD_PENDING.json` records intended destinations, not uploads.

Run from this extracted directory with source editors and builds stopped:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB"
python3 apply_patch.py --root "/path/to/AFRICLUB" --apply
python3 verify_bundle.py --phase contracts --results "/tmp/africlub-02-contracts"
python3 verify_bundle.py --phase installer --results "/tmp/africlub-02-installer"
python3 verify_bundle.py --phase native --results "/tmp/africlub-02-native"
```

The installer accepts only exact recognized before/previous/after hashes, preserves
permissions, writes a rollback journal and stops on unknown edits. It never executes
SQL or deployment commands. Individual writes are atomic; a multi-file installation
is not an atomic transaction for concurrent readers. Do not apply old archives over
this newer candidate. The matching prior candidate is accepted as an upgrade path.

The package verifier distinguishes passing targeted contracts from **blocked release
gates**. A missing/wrong pinned runtime is not a pass. Actual Android/iOS hosts,
Dart/Flutter, device/browser, Cloudflare, provider and security acceptance are still
required. No real credentials, fonts, SDKs or external provider calls are included.
