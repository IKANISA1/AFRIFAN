Scoped previous candidate and five narrow source reads only; not a full repository, production database, device backup or private-key archive.
