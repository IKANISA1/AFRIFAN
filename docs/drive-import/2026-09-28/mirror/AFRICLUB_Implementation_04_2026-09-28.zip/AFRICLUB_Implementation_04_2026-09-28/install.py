#!/usr/bin/env python3
"""Source-only installer wrapper with migration-lineage preflight. Default: dry-run."""
import argparse,sys,json
from pathlib import Path
from bundle_tools.check_migration_lineage import check
import apply_patch

def main():
 parser=argparse.ArgumentParser(add_help=False);parser.add_argument('--root',required=True,type=Path);parser.add_argument('--rollback');args,_=parser.parse_known_args()
 if args.rollback is None:
  result=check(args.root)
  if not result['passed']:
   print(json.dumps(result,indent=2),file=sys.stderr);return 2
 return apply_patch.main()
if __name__=='__main__':raise SystemExit(main())
