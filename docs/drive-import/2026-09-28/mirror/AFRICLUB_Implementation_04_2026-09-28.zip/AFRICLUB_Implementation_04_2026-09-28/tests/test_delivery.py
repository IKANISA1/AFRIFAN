import unittest,subprocess,sys,tempfile,shutil,json,hashlib
from pathlib import Path
BUNDLE=Path(__file__).resolve().parents[1]
MANIFEST=json.loads((BUNDLE/'manifest.json').read_text())
class DeliveryTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)/'repo';shutil.copytree(BUNDLE/'source',self.root)
  for e in MANIFEST['entries']:
   p=self.root/e['path']
   if e['before_sha256'] is None:p.unlink()
   else:shutil.copyfile(BUNDLE/'before'/e['path'],p)
 def run_cli(self,*args):
  return subprocess.run([sys.executable,str(BUNDLE/'install.py'),'--root',str(self.root),*map(str,args)],capture_output=True,text=True,timeout=15)
 def snapshot(self):
  return {str(p.relative_to(self.root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in self.root.rglob('*') if p.is_file() and 'output' not in p.relative_to(self.root).parts}
 def test_dry_run_no_writes(self):
  before=self.snapshot();r=self.run_cli();self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(json.loads(r.stdout)['source_files_to_change'],len(MANIFEST['entries']));self.assertEqual(self.snapshot(),before);self.assertFalse((self.root/'output').exists())
 def test_apply_repeat_exact_rollback(self):
  before=self.snapshot();r=self.run_cli('--apply');self.assertEqual(r.returncode,0,r.stderr);result=json.loads(r.stdout)
  for e in MANIFEST['entries']:self.assertEqual(hashlib.sha256((self.root/e['path']).read_bytes()).hexdigest(),e['after_sha256'])
  r=self.run_cli('--apply');self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(json.loads(r.stdout)['source_files_changed'],0)
  r=self.run_cli('--rollback',result['rollback_directory']);self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(self.snapshot(),before)
 def test_unknown_edit_preserved(self):
  e=next(e for e in MANIFEST['entries'] if e['before_sha256']);(self.root/e['path']).write_text('independent edit');before=self.snapshot();r=self.run_cli('--apply');self.assertEqual(r.returncode,2);self.assertEqual(self.snapshot(),before)
 def test_unknown_new_file_preserved(self):
  e=next(e for e in MANIFEST['entries'] if e['before_sha256'] is None);p=self.root/e['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_text('independent implementation');before=self.snapshot();r=self.run_cli('--apply');self.assertEqual(r.returncode,2);self.assertEqual(self.snapshot(),before)
 def test_duplicate_migration_stops_before_writes(self):
  (self.root/'cloudflare/payment-allocation/migrations/0003_server_handoff_recovery.sql').write_text('conflicting variant');before=self.snapshot();r=self.run_cli('--apply');self.assertEqual(r.returncode,2);self.assertIn('Duplicate migration',r.stderr);self.assertEqual(self.snapshot(),before);self.assertFalse((self.root/'output').exists())
 def test_payload_tamper_rejected(self):
  copy=Path(self.temp.name)/'bundle';shutil.copytree(BUNDLE,copy,ignore=shutil.ignore_patterns('__pycache__'))
  e=MANIFEST['entries'][0];(copy/'files'/e['path']).write_text('tampered payload');before=self.snapshot()
  r=subprocess.run([sys.executable,str(copy/'install.py'),'--root',str(self.root),'--apply'],capture_output=True,text=True,timeout=15);self.assertEqual(r.returncode,2);self.assertEqual(self.snapshot(),before)
if __name__=='__main__':unittest.main()
