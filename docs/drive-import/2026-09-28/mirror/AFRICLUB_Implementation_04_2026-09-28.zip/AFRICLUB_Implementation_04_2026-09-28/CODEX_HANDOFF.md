# AFRICLUB Implementation 04 — Codex handover

## Target and scope

Exact Implementation 03 322-file scoped source baseline. The root Drive snapshot is not
assumed to match. All 130 tasks remain unaccepted; current status is 31 In progress / 99 Open.
The delta is 46 paths (20 new, 26 modified); 296 other source hashes must match.

## Inspect and install source only

Stop concurrent editors/builds and preserve the existing working tree. From the extracted
package (this is not the monorepo root):

```sh
python3 install.py --root /path/to/reviewed/AFRICLUB
python3 install.py --root /path/to/reviewed/AFRICLUB --apply
# Use the exact rollback_directory returned by a successful apply:
python3 install.py --root /path/to/reviewed/AFRICLUB --rollback /path/from/apply/result
```

Exit 2 from the installer is a conflict/block, not approval to force replacement. It does
not run SQL, provision resources, send payments or change sharing. Source replacement is
atomic per file, not a transaction across concurrent readers. Read manifest/provenance first.
Never copy all of source/ over a full repository or apply the reference_only migration.

## Verify in the legitimate development environment

From the reconciled repository, using its required runtimes:

```sh
node cloudflare/operator-api/scripts/build-ui.mjs --check
node cloudflare/operator-api/scripts/check-deployment.mjs
node cloudflare/payment-exceptions/scripts/check-deployment.mjs
python3 tools/scripts/verify_converged_source.py --profile complete --results /tmp/africlub04-checks
python3 cloudflare/payment-exceptions/tests/browser/run_browser.py --output /tmp/africlub04-browser
```

The local browser run in this delivery was blocked by administrator policy. Do not change
transport/flags/policy to bypass it. Run the harness only where navigation is legitimately
permitted. It uses synthetic identities and local SQLite, not hosted Access/D1 or money.
Do not infer source gate success from a portable-native or unpinned Node pass.

## Features and route contracts

- Direct Worker case page: /operator/clubs/{clubId}/payment-exceptions.
- Case session and own-operation reads supplement the existing four case API routes.
- Native current membership read: GET /v1/supporter/clubs/{clubId}/membership/status.
- Optional HTTP metrics: OPERATOR_METRICS_ENABLED remains false.
- No SQL migration changed. All templates remain disabled pending reviewed environment setup.

## Continue the complete task plan

Read TASK_REGISTER.json and EXECUTION_PLAN.json for all IDs, dependencies, missing named
owners and original acceptance requirements. The priority is to converge protected source,
restrict link sharing, reconcile real migration histories and prove actual runtime/browser
boundaries. Then finish authentic financial evidence/refunds, native and browser composition,
remaining product work and operational/club/country/store approvals. Do not replace those
requirements with additional unit-test counts or fabricated external evidence.

The case workflow does not settle payments. The current membership read does not grant
permission to future mutations. The migration comparator does not prove extraction coverage.
The task planner does not verify sign-offs. Do not close any task without its real evidence.
