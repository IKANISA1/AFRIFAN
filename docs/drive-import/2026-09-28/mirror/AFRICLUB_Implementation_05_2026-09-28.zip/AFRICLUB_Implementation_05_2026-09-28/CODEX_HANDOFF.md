# AFRICLUB Implementation 05 — handover

## Input and authority

Continue from the exact Implementation 04 scoped source specified by `manifest.json` and
`SOURCE_PROVENANCE.json`. This is a 25-path additive/update delta, not a full monorepo.
The root Drive snapshot may be older. Do not force mismatches, replace the entire repository
with `source/`, downgrade newer independent edits, or reconcile the two financial 0003
migrations by renaming them. No runtime or legal release gate is overridden.

## Apply locally

Stop other editors/builds. From the extracted bundle:

```sh
python3 install.py --root /path/to/reviewed/AFRICLUB
python3 install.py --root /path/to/reviewed/AFRICLUB --apply
# The installer prints a rollback_directory. Preserve it.
python3 install.py --root /path/to/reviewed/AFRICLUB --rollback /exact/printed/rollback_directory
```

Dry-run is the default. Hash conflicts stop before source modification. The installer writes
no cloud resources and applies no SQL. Review failure JSON/stderr; do not bypass the guard.

## Verify with the supported toolchain

In the assembled reviewed source, install/use the existing pinned Node, Dart/Flutter and
native SDK dependencies without rewriting their locks. This delivery ran Node 22.16.0 and
therefore does not satisfy the source-required 22.23.2 gate.

```sh
node --test cloudflare/supporter-browser-api/tests/*.test.mjs
node cloudflare/supporter-browser-api/scripts/check-deployment.mjs
node cloudflare/operator-api/scripts/build-ui.mjs --check
python3 tools/scripts/verify_converged_source.py --profile complete --results /tmp/africlub-05-verification
```

The strict verifier returns 2 for blocked runtime/platform checks; it must not be represented
as success. Its Python/native reruns are not additional unique tests.
For delivery safety from the bundle:

```sh
python3 -m unittest discover -s tests -p 'test_*.py'
```

## Integration work to perform next

Read `cloudflare/supporter-browser-api/README.md` and
`cloudflare/supporter-auth/BROWSER_SESSIONS.md`. The browser API/client is implemented; the
actual Next.js/PWA membership route, visual states, service-worker policy, browser testing
and all five host/club compositions still need integration and acceptance.

Use the SAME existing AUTH_DB for BrowserIdentity. Inspect actual hosted identity migration
history before the forward-only `0004_browser_sessions.sql`. Review origin/club mapping,
lifetime/rate settings and existing identity key management. Keep API, membership, checkout,
SQL control/origin rows and any schedules disabled until those reviews and target tests pass.
No real origins, cloud account identifiers, credentials or approved commercial inputs are
invented by these templates.

Bind only the narrow identity/checkout/read/receipt capabilities. Do not forward cookies to
the native bearer gateway or expose native access/refresh tokens to JavaScript. The configured
host must be the member application's same origin, not an arbitrary CORS-enabled API domain.

Inject an approved durable checkout recovery store and cross-tab lock. Explicitly review
shared-device and retention behavior. Read-only recovery must preserve original IDs; a missing
lookup result is not authorization to issue a replacement order. Do not add automatic retries
on app resume, polling, storage failure or timeout.

The browser code does not implement contribution initiation, financial settlement, refunds,
provider authenticity, complete erasure or cross-database atomic revocation. Keep these tasks
in the updated register. Do not close acceptance tasks from code presence or local test counts.

`TASK_REGISTER.json` preserves all 130 tasks and acceptance criteria. `EXECUTION_PLAN.json`
orders closure prerequisites, not a prohibition on parallel source implementation. Named
owners and their approvals remain missing rather than being assigned without authorization.
