import ast
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[2]
class ConvergedInventoryTests(unittest.TestCase):
    def setUp(self): self.text = (ROOT/'tools/scripts/verify_converged_source.py').read_text()
    def test_case_backend_is_in_pinned_gate(self):
        self.assertIn("'cloudflare/payment-exceptions/tests'", self.text)
    def test_browser_backend_is_in_pinned_gate(self):
        self.assertIn("'cloudflare/supporter-browser-api/tests'", self.text)
    def test_browser_config_is_checked(self):
        self.assertIn("cloudflare/supporter-browser-api/scripts/check-deployment.mjs", self.text)
    def test_router_tests_are_registered(self):
        self.assertIn("'cloudflare/supporter-web-router/tests'", self.text)
    def test_router_configuration_is_checked(self):
        self.assertIn('cloudflare/supporter-web-router/scripts/validate-config.mjs', self.text)
    def test_all_named_python_modules_exist(self):
        constants = [n.value for n in ast.walk(ast.parse(self.text)) if isinstance(n, ast.Constant) and isinstance(n.value, str)]
        for name in (s for s in constants if s.startswith('test_')):
            self.assertTrue((ROOT/'tools/scripts'/f'{name}.py').is_file(), name)
    def test_all_deployment_scripts_exist(self):
        constants = [n.value for n in ast.walk(ast.parse(self.text)) if isinstance(n, ast.Constant) and isinstance(n.value, str)]
        for name in (s for s in constants if s.startswith('cloudflare/') and s.endswith('.mjs')):
            self.assertTrue((ROOT/name).is_file(), name)
    def test_pin_is_not_downgraded_or_bypassed(self):
        self.assertEqual((ROOT/'.nvmrc').read_text().strip(), '22.23.2')
        self.assertIn('if actual!=expected:', self.text); self.assertNotIn('--ignore-pin', self.text)
    def test_scoped_success_is_not_production_acceptance(self):
        self.assertIn("'productionReady':False", self.text); self.assertIn("'fullApplicationBuildVerified':False", self.text)

if __name__ == '__main__': unittest.main()
