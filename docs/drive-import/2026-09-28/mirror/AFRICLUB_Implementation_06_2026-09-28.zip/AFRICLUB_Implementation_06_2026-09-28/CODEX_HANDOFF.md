# AFRICLUB Implementation 06 — handover

## Exact starting state

Use the reviewed Implementation 05 candidate plus the four original Next/SW files identified
in SOURCE_PROVENANCE.json. This is a scoped patch, not a full monorepo replacement. The supplied
source/ includes only the test candidate and exact context; many unchanged application imports
live in the complete repository. Stop editors/builds during application. Never bypass an
unknown hash, missing prerequisite or migration-lineage conflict.

```sh
python3 install.py --root /path/to/reviewed/AFRICLUB
python3 install.py --root /path/to/reviewed/AFRICLUB --apply
# Use the exact rollback_directory returned by the apply result:
python3 install.py --root /path/to/reviewed/AFRICLUB --rollback /path/to/returned/rollback_directory
```

The installer does not apply SQL, send codes/payments, enable features, change permissions or
make a remote Git commit. All 17 SQL files remain unchanged. The 0003 conflict is still a hosted
history/reconciliation task, not permission to rename migrations.

## Source changes

The actual /membership page selects the new client/controller only in explicitly enabled
cookie-v1 mode. The original default/legacy source remains. Read
cloudflare/supporter-browser-api/PORTAL_INTEGRATION.md and
cloudflare/supporter-web-router/README.md before editing deployment configuration.

Keep one approved same origin/club across the Next variables, browser API configuration and
identity DB origin record. Bind the original Request through the outer Worker to BROWSER_API;
do not implement an ad hoc Next proxy with invented Cloudflare metadata. Bind the reviewed
OpenNext build as NEXT_APP and close alternate public origins. Do not enable the provided
empty/disabled template. No production origin or signing/provider credential is in this pack.

## Verification commands (from the complete reviewed repo)

```sh
node --test cloudflare/supporter-browser-api/tests/*.test.mjs cloudflare/supporter-web-router/tests/*.test.mjs
node cloudflare/supporter-web-router/scripts/validate-config.mjs
python3 tools/scripts/verify_converged_source.py --profile complete --results /tmp/africlub-06-results
(cd apps/rayon_sports/web && corepack npm run typecheck && corepack npm test && corepack npm run lint && corepack npm run build)
```

The strict verifier needs the actual pinned Node 22.23.2 and supported Dart/Flutter. Exit 2 is a
blocked runtime, not permission to lower pins or remove tests. The local evidence here used
Node 22.16.0, Python 3.13.5 and TypeScript 5.8.3. TSX parsing was checked, but actual React/Next
semantic compilation/build and rendering were not possible with absent dependencies and
EAI_AGAIN registry reads. The uploaded source is not a signed or deployable accepted artifact.

## Required next acceptance

Build and render the actual page at an approved same-origin isolated deployment. Test signed-out
and code entry, all current membership states, catalog changes, order recovery after response
loss, old-worker cache handshake, offline/BFCache/multiple tabs, session rotation/logout recovery,
large text, keyboard and screen readers. Capture actual network headers and cookie/CF context
across Worker bindings. No screenshot or local TypeScript test substitutes for these checks.

No timer/restoration may submit a command. Preparation is not payment. A not-observed original
operation is not failure. Never erase uncertain recovery metadata or allow a historical receipt
to reactivate suspension. Remembered order IDs require an approved privacy/retention policy.

TASK_REGISTER.json preserves all 130 original tasks; EXECUTION_PLAN.json orders closure
prerequisites without granting approval. Financial evidence, refunds, contributions, native apps,
real D1, security/privacy/club approvals and controlled cutover remain separate work.
