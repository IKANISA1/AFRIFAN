# AFRICLUB cumulative v3 source package — 26 September 2026

83 cumulative source changes: 24 original-file modifications and 59 additions.
This batch changes 28 files relative to v2 (14 edits, 14 additions). All earlier
v1/v2 changes are included. It is a source patch, not a replacement repository.

**No Drive write or deployment occurred in this turn.** Current tools expose only
reads. The new protected operator UI is implemented locally and disabled by default.
308 targeted tests pass; Chromium blocked local browser navigation, so no rendered
UI/browser acceptance is claimed. Read IMPLEMENTATION_REPORT.md and remaining_actions.json.

## Source application

Extract outside an authorized AFRICLUB checkout. Stop source editors and builds.
Use macOS/Linux and Python 3.10+. First run the read-only preflight:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB"
```

Apply only when preflight matches the intended checkout:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB" --apply
```

Recognized starting bytes are the original baseline or the explicitly enumerated
v1/v2 hashes in the manifest. Already matching files are preserved. Unknown edits,
symlinks, corrupt payloads or changed prerequisites stop the operation; there is
no force flag. Do not edit hashes just to bypass a source conflict.

The printed rollback_directory is stored under this checkout's
output/refactor-backups/. Restore with this exact bundle:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB" \
  --rollback "/path/to/AFRICLUB/output/refactor-backups/<run-id>"
```

Rollback restores the actual recognized version installed before v3, including
previously added v1/v2 files. It does not overwrite unrecognized later edits.
Individual source writes are atomic; all files together are not atomic to other
readers. Source backups are not production database backups.

## Repeat targeted verification

Preinstalled Node with node:sqlite, Python, Git and TypeScript are required.
No dependency downloads, credential requests or external account actions occur.

```sh
python3 verify_bundle.py --results /tmp/africlub-v3-source-checks
```

The script reconstructs the source subset, runs 215 Node and 60 Python source tests,
33 installer tests, generated-UI parity and disabled deployment checks. It does
not run a full repository build or count browser tests as passed. The browser
harness and its explicit command are in files/cloudflare/operator-api/ui/README.md.
Use the repository's pinned web/mobile toolchains for complete checks; requirements
were not weakened to match this environment.

The new forward index migration and prior unapplied source migrations must use a
governed migration process. Adding SQL files does not execute them. Do not deploy
only the UI assets or enable a flag without the complete source and real staging
identity, grant, schema and browser verification. No deployment, financial operation,
provider call, role change, billing operation or production reset is performed by
the installer or verifier.

## Contents

- files/: exact cumulative source paths; context/: unchanged test prerequisites.
- manifest.json: original IDs/hashes, accepted prior versions and target hashes.
- batch3-changes.json and batch3.patch: changes relative to v2.
- changes.patch: cumulative text diff from the original scoped source baseline.
- evidence/: executed source logs, saved-source replay, rollback trials, syntax
  checks and the explicit browser blocker; no fake rendered screenshots.
- Earlier implementation reports retain their historical completion boundaries.

No original exported content, media, databases, real tokens, temporary TLS keys,
user credentials, dependency caches or font files are included.
