import pathlib,tempfile,zipfile,json,subprocess,hashlib,shutil
R=pathlib.Path('/mnt/data/africlub_batch2');B=R/'AFRICLUB_Source_Patch_v2_2026-09-26';m=json.loads((B/'manifest.json').read_text());summary=[]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
def run(root,*args):
 r=subprocess.run(['python3',str(B/'apply_patch.py'),'--root',str(root),*args],capture_output=True,text=True);assert r.returncode==0,r.stderr;return json.loads(r.stdout)
for scenario in ['original_baseline','current_drive_additions','v1_applied']:
 with tempfile.TemporaryDirectory(prefix='africlub-v2-install-') as td:
  root=pathlib.Path(td)
  with zipfile.ZipFile('/mnt/data/AFRICLUB_Source_Baseline_Before_Patch_2026-09-26.zip') as z:
   for name in z.namelist():
    if name.startswith('originals/'):
     target=root/name.removeprefix('originals/');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
  for c in m['preconditions']:
   target=root/c['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/'context'/c['path'],target)
  if scenario=='current_drive_additions':
   saved=json.loads((R/'evidence/source-drive-verification.json').read_text())['readback_verified_source_files'];existing=[x['path'] for x in saved]+['docs/governance/legacy-reference-exceptions.json']
   for rel in existing:
    target=root/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/'files'/rel,target)
  if scenario=='v1_applied':
   for e in json.loads((R/'AFRICLUB_Source_Patch_2026-09-26/manifest.json').read_text())['entries']:
    target=root/e['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/'files'/e['path'],target)
  before={e['path']:digest(root/e['path']) for e in m['entries']}
  dry=run(root);applied=run(root,'--apply')
  assert all(digest(root/e['path'])==e['after_sha256'] for e in m['entries'])
  repeat=run(root,'--apply');assert repeat['status']=='already_applied'
  restored=run(root,'--rollback',applied['rollback_directory']);assert all(digest(root/name)==h for name,h in before.items())
  summary.append({'scenario':scenario,'changed':applied['source_files_changed'],'preflightMatched':dry['already_matching'],'all_after_hashes_match':True,'reapply_no_op':True,'all_before_hashes_restored':True})
report={'scope':'disposable source baselines only, no original Drive or deployed service modified','trials':summary}
(R/'evidence/cumulative-installation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
