#!/usr/bin/env python3
"""Apply this source-only patch with exact-hash preconditions and scoped rollback.

Default is a read-only dry run. No network, database, deployment, billing,
permission changes or credential operations are performed. POSIX hosts only.
"""
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tempfile
import uuid


class PatchError(RuntimeError):
    """A conflict or invalid bundle; never override an unrecognized source."""


HASH = re.compile(r"[0-9a-f]{64}\Z")


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def relative(value: object) -> str:
    if not isinstance(value, str) or not value or "\\" in value or "\x00" in value:
        raise PatchError("Invalid relative path")
    p = PurePosixPath(value)
    if p.is_absolute() or str(p) != value or any(x in ("", ".", "..") for x in value.split("/")):
        raise PatchError(f"Unsafe path: {value!r}")
    return value


def safe_path(base: Path, value: str) -> Path:
    value = relative(value)
    target = base / value
    # lstat catches dangling symlinks too. Do not resolve() and silently follow one.
    current = base
    for part in PurePosixPath(value).parts:
        current = current / part
        if current.is_symlink():
            raise PatchError(f"Symlink is not permitted: {current}")
        if current != target and current.exists() and not current.is_dir():
            raise PatchError(f"Parent is not a directory: {current}")
    return target


def host_path(path: Path) -> Path:
    absolute = Path(os.path.abspath(path.expanduser()))
    for item in [absolute, *absolute.parents]:
        if item.is_symlink():
            raise PatchError(f"Use a non-symlink path: {item}")
    if not absolute.is_dir():
        raise PatchError(f"Directory not found: {absolute}")
    return absolute


def file_hash(path: Path) -> str | None:
    if path.is_symlink():
        raise PatchError(f"Symlink is not permitted: {path}")
    if not path.exists():
        return None
    if not path.is_file():
        raise PatchError(f"Expected a regular file: {path}")
    return digest(path)


def read_manifest(bundle: Path) -> tuple[dict, str]:
    target = safe_path(bundle, "manifest.json")
    raw = target.read_bytes()
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeError) as error:
        raise PatchError("Invalid manifest JSON") from error
    if type(data.get("schema_version")) is not int or data["schema_version"] != 1:
        raise PatchError("Unsupported manifest version")
    if data.get("kind") != "source-only-patch" or not isinstance(data.get("entries"), list) or not data["entries"]:
        raise PatchError("Not a source-only patch manifest")
    if not isinstance(data.get("patch_id"), str) or not re.fullmatch(r"[A-Za-z0-9_.-]+", data["patch_id"]):
        raise PatchError("Invalid patch identity")
    seen = set()
    for entry in data["entries"] + data.get("preconditions", []):
        if not isinstance(entry, dict):
            raise PatchError("Invalid manifest entry")
        name = relative(entry.get("path"))
        if name.split("/")[0] in (".git", "output", ".recovery"):
            raise PatchError(f"Protected source path: {name}")
        if name in seen or any(name.startswith(x + "/") or x.startswith(name + "/") for x in seen):
            raise PatchError(f"Duplicate or overlapping source path: {name}")
        seen.add(name)
    for entry in data["entries"]:
        before = entry.get("before_sha256")
        if before is not None and (not isinstance(before, str) or not HASH.fullmatch(before)):
            raise PatchError("Invalid before hash")
        if not isinstance(entry.get("after_sha256"), str) or not HASH.fullmatch(entry["after_sha256"]):
            raise PatchError("Invalid after hash")
        if type(entry.get("new_mode")) is not int or not 0 <= entry["new_mode"] <= 0o777:
            raise PatchError("Invalid file mode")
    for entry in data.get("preconditions", []):
        if not isinstance(entry.get("sha256"), str) or not HASH.fullmatch(entry["sha256"]):
            raise PatchError("Invalid prerequisite hash")
    if "pubspec.yaml" not in seen:
        raise PatchError("Bundle must identify the AFRICLUB root manifest")
    return data, hashlib.sha256(raw).hexdigest()


def preflight(root: Path, bundle: Path, manifest: dict) -> list[dict]:
    for condition in manifest.get("preconditions", []):
        if file_hash(safe_path(root, condition["path"])) != condition["sha256"]:
            raise PatchError(f"Unchanged prerequisite differs: {condition['path']}")
    planned = []
    for entry in manifest["entries"]:
        source = safe_path(bundle, "files/" + entry["path"])
        if file_hash(source) != entry["after_sha256"]:
            raise PatchError(f"Payload checksum failed: {entry['path']}")
        target = safe_path(root, entry["path"])
        actual = file_hash(target)
        if actual == entry["after_sha256"]:
            continue  # Already installed; do not back it up or alter permissions.
        if actual != entry["before_sha256"]:
            raise PatchError(f"Source conflict; preserved without changes: {entry['path']}")
        planned.append({
            "path": entry["path"], "before_sha256": actual,
            "after_sha256": entry["after_sha256"],
            "mode": stat.S_IMODE(target.stat().st_mode) if actual else entry["new_mode"],
        })
    return planned


def atomic_write(path: Path, contents: bytes, mode: int) -> None:
    fd, name = tempfile.mkstemp(prefix=".africlub-patch-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as target:
            target.write(contents)
            target.flush()
            os.fsync(target.fileno())
            os.fchmod(target.fileno(), mode)
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def save_journal(run: Path, journal: dict) -> None:
    atomic_write(run / "journal.json", (json.dumps(journal, indent=2) + "\n").encode(), 0o600)


@contextlib.contextmanager
def repository_lock(root: Path):
    try:
        import fcntl
    except ImportError as error:
        raise PatchError("This installer requires a POSIX host (macOS or Linux)") from error
    store = safe_path(root, "output/refactor-backups")
    store.mkdir(parents=True, exist_ok=True, mode=0o700)
    lock = safe_path(root, "output/refactor-backups/.apply.lock")
    fd = os.open(lock, os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0), 0o600)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise PatchError("Another patch operation is running for this repository") from error
        yield store
    finally:
        os.close(fd)  # Kernel releases the lock even when a process crashes.


def restore(root: Path, run: Path, manifest: dict, manifest_hash: str) -> dict:
    safe_run = host_path(run)
    store = safe_path(root, "output/refactor-backups")
    if safe_run.parent != store:
        raise PatchError("Rollback journal must be directly under this root's output/refactor-backups")
    journal_file = safe_path(safe_run, "journal.json")
    journal = json.loads(journal_file.read_text())
    if journal.get("root") != str(root) or journal.get("manifest_sha256") != manifest_hash:
        raise PatchError("Rollback journal does not match this root and exact bundle")
    catalog = {e["path"]: e for e in manifest["entries"]}
    actions = journal.get("operations")
    if not isinstance(actions, list):
        raise PatchError("Invalid rollback operations")
    names = set()
    # Preflight every restore before changing a single source file.
    for action in actions:
        name = relative(action.get("path"))
        entry = catalog.get(name)
        if name in names or entry is None:
            raise PatchError("Rollback operation is outside the patch")
        names.add(name)
        if action.get("before_sha256") != entry["before_sha256"] or action.get("after_sha256") != entry["after_sha256"]:
            raise PatchError("Rollback hashes differ from this patch")
        if type(action.get("mode")) is not int or not 0 <= action["mode"] <= 0o777:
            raise PatchError("Invalid backup mode")
        target = safe_path(root, name)
        current = file_hash(target)
        if current not in (action["before_sha256"], action["after_sha256"]):
            raise PatchError(f"Concurrent edit preserved; rollback stopped: {name}")
        if action["before_sha256"] is not None:
            backup = safe_path(safe_run, "files/" + name)
            if file_hash(backup) != action["before_sha256"]:
                raise PatchError(f"Backup checksum failed: {name}")
    for action in reversed(actions):
        target = safe_path(root, action["path"])
        current = file_hash(target)
        if current == action["before_sha256"]:
            continue
        if current != action["after_sha256"]:
            raise PatchError(f"Concurrent edit preserved: {action['path']}")
        if action["before_sha256"] is None:
            target.unlink()
        else:
            backup = safe_path(safe_run, "files/" + action["path"])
            atomic_write(target, backup.read_bytes(), action["mode"])
    journal["state"] = "rolled_back"
    journal["rolled_back_at_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    save_journal(safe_run, journal)
    # Empty newly-created parent directories are harmless and deliberately kept.
    return {"status": "rolled_back", "operations": len(actions), "journal": str(journal_file)}


def apply(root: Path, bundle: Path, manifest: dict, manifest_hash: str) -> dict:
    with repository_lock(root) as store:
        operations = preflight(root, bundle, manifest)
        if not operations:
            return {"status": "already_applied", "source_files_changed": 0}
        run = store / (dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ-") + uuid.uuid4().hex[:10])
        run.mkdir(mode=0o700)
        journal = {
            "schema_version": 1, "patch_id": manifest["patch_id"],
            "manifest_sha256": manifest_hash, "root": str(root),
            "state": "preparing", "operations": operations, "written": [],
        }
        # Persist verified backups for ALL planned changes before source mutation.
        for action in operations:
            if action["before_sha256"] is not None:
                target = safe_path(root, action["path"])
                backup = safe_path(run, "files/" + action["path"])
                backup.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                atomic_write(backup, target.read_bytes(), 0o600)
                if digest(backup) != action["before_sha256"]:
                    raise PatchError(f"Source changed during backup: {action['path']}")
        save_journal(run, journal)
        try:
            for action in operations:
                target = safe_path(root, action["path"])
                if file_hash(target) != action["before_sha256"]:
                    raise PatchError(f"Source changed after preflight: {action['path']}")
                payload = safe_path(bundle, "files/" + action["path"]).read_bytes()
                if hashlib.sha256(payload).hexdigest() != action["after_sha256"]:
                    raise PatchError(f"Payload changed after preflight: {action['path']}")
                target.parent.mkdir(parents=True, exist_ok=True)
                safe_path(root, action["path"])
                atomic_write(target, payload, action["mode"])
                journal["written"].append(action["path"])
                journal["state"] = "applying"
                save_journal(run, journal)
            for action in operations:
                if file_hash(safe_path(root, action["path"])) != action["after_sha256"]:
                    raise PatchError(f"Post-write checksum failed: {action['path']}")
            journal["state"] = "applied"
            save_journal(run, journal)
        except Exception as error:
            try:
                restore(root, run, manifest, manifest_hash)
            except Exception as rollback_error:
                raise PatchError(f"Apply stopped: {error}. Rollback also stopped to preserve edits: {rollback_error}. Journal: {run}") from error
            raise PatchError(f"Apply stopped and source changes rolled back: {error}. Journal: {run}") from error
        return {"status": "applied", "source_files_changed": len(operations), "journal": str(run / "journal.json"),
                "rollback_directory": str(run), "deployment_performed": False, "database_changed": False}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path, help="Existing AFRICLUB repository root")
    parser.add_argument("--bundle", type=Path, default=Path(__file__).parent, help=argparse.SUPPRESS)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--apply", action="store_true", help="Write checked source changes; default is dry-run")
    mode.add_argument("--rollback", type=Path, help="Restore a journal directory from this exact bundle")
    args = parser.parse_args(argv)
    try:
        root, bundle = host_path(args.root), host_path(args.bundle)
        manifest, manifest_hash = read_manifest(bundle)
        if args.rollback:
            with repository_lock(root):
                result = restore(root, args.rollback, manifest, manifest_hash)
        elif args.apply:
            result = apply(root, bundle, manifest, manifest_hash)
        else:
            operations = preflight(root, bundle, manifest)
            result = {"status": "dry_run", "source_files_to_change": len(operations),
                      "already_matching": len(manifest["entries"]) - len(operations),
                      "paths": [e["path"] for e in operations], "source_files_changed": 0}
        print(json.dumps(result, indent=2))
        return 0
    except (PatchError, OSError, ValueError, KeyError, TypeError) as error:
        print(f"Patch operation stopped: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
