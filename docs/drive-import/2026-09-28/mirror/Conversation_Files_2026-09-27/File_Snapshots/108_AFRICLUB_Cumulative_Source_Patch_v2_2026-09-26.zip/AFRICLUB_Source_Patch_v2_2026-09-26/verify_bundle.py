#!/usr/bin/env python3
"""Repeat bounded source tests in a disposable subset; never applies the patch."""
from __future__ import annotations
import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

BUNDLE = Path(__file__).resolve().parent
sys.path.insert(0, str(BUNDLE))
from apply_patch import digest, read_manifest, safe_path


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, help='Optional output directory for test logs')
    args=parser.parse_args()
    for tool in ('node','git','tsc'):
        if not shutil.which(tool):
            parser.error(f'{tool} is required')
    manifest, _ = read_manifest(BUNDLE)
    results=[]
    with tempfile.TemporaryDirectory(prefix='africlub-patch-verify-') as temporary:
        root=Path(temporary)/'candidate'; root.mkdir()
        for condition in manifest.get('preconditions',[]):
            source=safe_path(BUNDLE, 'context/'+condition['path'])
            if digest(source)!=condition['sha256']: raise RuntimeError('Context checksum failed: '+condition['path'])
            target=safe_path(root,condition['path']);target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(source,target)
        for entry in manifest['entries']:
            source=safe_path(BUNDLE, 'files/'+entry['path'])
            if digest(source)!=entry['after_sha256']:raise RuntimeError('Payload checksum failed: '+entry['path'])
            target=safe_path(root,entry['path']);target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(source,target)
        cases=[
            ('node-regressions', ['node','--experimental-sqlite','--test',
                'tools/scripts/validate_repository_boundary.test.mjs',
                'tools/scripts/validate_predict_economics_contract.test.mjs',
                'cloudflare/rayon-public/tests/snapshot.test.mjs'],root),
            ('operator-regressions',['node','--test',
                'cloudflare/operator-api/tests/auth-http.test.mjs',
                'cloudflare/operator-api/tests/publication.test.mjs',
                'cloudflare/operator-api/tests/client.test.mjs',
                'cloudflare/operator-api/tests/deployment.test.mjs',
                'cloudflare/operator-api/tests/contract.test.mjs'],root),
            ('python-regressions',[sys.executable,'-m','unittest','-v',
                'test_supporter_sms_boundary','test_public_snapshot_import','test_migration_release'],root/'tools/scripts'),
            ('installer-regressions',[sys.executable,'-m','unittest','discover','-s',str(BUNDLE/'tests'),'-v'],BUNDLE),
        ]
        for label,command,cwd in cases:
            run=subprocess.run(command,cwd=cwd,capture_output=True,text=True,timeout=120,
                               env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
            text=run.stdout+run.stderr
            print(f'{label}: {"PASS" if run.returncode==0 else "FAIL"}')
            if args.results:
                args.results.mkdir(parents=True,exist_ok=True)
                (args.results/f'{label}.log').write_text(text)
            if run.returncode: print(text,file=sys.stderr)
            results.append({'name':label,'exit_code':run.returncode})
    report={'scope':'targeted disposable source subset, not full checkout or Cloudflare runtime',
            'tests':results,'node':subprocess.check_output(['node','--version'],text=True).strip(),
            'python':sys.version.split()[0], 'dart_flutter_executed':False,
            'deployment_performed':False,'database_migrations_applied_remotely':False}
    if args.results:(args.results/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if all(r['exit_code']==0 for r in results) else 1


if __name__=='__main__':sys.exit(main())
