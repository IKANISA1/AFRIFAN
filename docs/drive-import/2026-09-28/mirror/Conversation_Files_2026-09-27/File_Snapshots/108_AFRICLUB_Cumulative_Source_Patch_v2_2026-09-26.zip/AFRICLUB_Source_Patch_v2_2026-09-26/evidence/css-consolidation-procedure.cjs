const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');const assert=require('node:assert/strict');const postcss=require('postcss');
const base=__dirname;const root=path.join(base,'worktree');
const hash=data=>crypto.createHash('sha256').update(data).digest('hex');
function semantic(node){
 const entries=[];
 for(const child of node.nodes??[]){
  if(child.type==='comment')continue;
  if(child.type==='rule'){
   const body=semantic(child);
   for(const selector of child.selectors)entries.push(['rule',selector.trim(),body]);
  }else if(child.type==='decl')entries.push(['decl',child.prop,child.value,!!child.important]);
  else if(child.type==='atrule')entries.push(['at',child.name,child.params,semantic(child)]);
  else throw new Error(`Unhandled CSS node: ${child.type}`);
 }
 return entries;
}
const records=[];
for(const name of ['admin.css','theme.css']){
 const rel=`apps/rayon_sports/web/src/ui-kit/${name}`;const source=fs.readFileSync(path.join(root,rel),'utf8');const ast=postcss.parse(source);const before=semantic(ast);let merged=0;
 // Only physically adjacent, declaration-only rules. No rules cross media,
 // container, layer or source-order boundaries; nesting is never combined.
 ast.walkRules(rule=>{
  const next=rule.next();
  if(next?.type!=='rule'||!(rule.nodes??[]).every(n=>n.type==='decl'||n.type==='comment')||!(next.nodes??[]).every(n=>n.type==='decl'||n.type==='comment'))return;
  if(JSON.stringify(semantic(rule))!==JSON.stringify(semantic(next)))return;
  rule.selector=rule.selector+',\n'+(/\n([ \t]*)$/.exec(next.raws.before??'')?.[1]??'')+next.selector;next.remove();merged++;
  // A second adjacent identical rule may become eligible after removal.
  let following=rule.next();
  while(following?.type==='rule'&&(following.nodes??[]).every(n=>n.type==='decl'||n.type==='comment')&&JSON.stringify(semantic(rule))===JSON.stringify(semantic(following))){
   rule.selector+=',\n'+(/\n([ \t]*)$/.exec(following.raws.before??'')?.[1]??'')+following.selector;following.remove();merged++;following=rule.next();
  }
 });
 const target=ast.toString();assert.deepEqual(semantic(postcss.parse(target)),before,'Per-selector ordered CSS declarations changed');fs.writeFileSync(path.join(root,rel),target);
 records.push({path:rel,mergedRedundantRules:merged,beforeBytes:Buffer.byteLength(source),afterBytes:Buffer.byteLength(target),beforeSha256:hash(source),afterSha256:hash(target),expandedAstSha256:hash(JSON.stringify(before)),orderedSelectorDeclarationParity:true});
}
fs.writeFileSync(path.join(base,'evidence/css-consolidation.json'),JSON.stringify({postcssVersion:postcss().version,scope:'adjacent identical leaf rules only',visualApproval:false,records},null,2)+'\n');console.log(JSON.stringify(records,null,2));
