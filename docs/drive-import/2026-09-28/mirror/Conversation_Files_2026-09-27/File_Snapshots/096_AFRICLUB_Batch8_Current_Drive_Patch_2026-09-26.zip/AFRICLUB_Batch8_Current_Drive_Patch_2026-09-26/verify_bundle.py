#!/usr/bin/env python3
"""Offline verification: exact new source, real local SQLite tests, source rollback.
No provider, remote database, account, network or deployment operation is performed.
"""
from pathlib import Path
import argparse, concurrent.futures, hashlib, importlib.util, json, re, shutil, subprocess, sys, tempfile, unittest
import os
sys.dontwritebytecode=True
os.environ['PYTHONDONTWRITEBYTECODE']='1'
BUNDLE=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd,cwd,path):
 r=subprocess.run(cmd,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 path.write_text(r.stdout)
 if r.returncode: raise RuntimeError(f'Check failed: {path}')
 return r.stdout
def source_map(root): return {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file() and 'output' not in p.relative_to(root).parts}
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--results',required=True,type=Path);args=a.parse_args()
 out=args.results.absolute();out.mkdir(parents=True,exist_ok=True)
 m=json.loads((BUNDLE/'manifest.json').read_text())
 for e in m['entries']: assert sha(BUNDLE/'files'/e['path'])==e['after_sha256'],e['path']
 for e in m['entries']:
  if e['before_sha256'] is not None: assert sha(BUNDLE/'context'/e['path'])==e['before_sha256']
 for e in m['preconditions']: assert sha(BUNDLE/'context'/e['path'])==e['sha256'],e['path']
 summary={'manifestSha256':sha(BUNDLE/'manifest.json'),'sourceAdditions':sum(e['before_sha256'] is None for e in m['entries']),'originalFilesModified':sum(e['before_sha256'] is not None for e in m['entries']),'nodeVersion':subprocess.check_output(['node','--version'],text=True).strip(),'pythonVersion':sys.version.split()[0],'runtimeProductionEnabled':False,'liveProviderRequests':0,'actualCloudflareRuntimeVerified':False,'databaseMigrationsAppliedRemotely':0}
 with tempfile.TemporaryDirectory(prefix='africlub-b8-') as tmp:
  root=Path(tmp)/'candidate';shutil.copytree(BUNDLE/'context',root);shutil.copytree(BUNDLE/'files',root,dirs_exist_ok=True)
  tests=sorted(root.glob('cloudflare/payment-allocation/tests/*.test.mjs'))
  text=run(['node','--test',*map(str,tests)],root,out/'node-tests.log')
  counts={x:int(re.search(rf'^# {x} (\d+)$',text,re.M).group(1)) for x in ['tests','pass','fail','skipped']}
  assert counts['fail']==0 and counts['skipped']==0
  summary['moduleTests']=counts
  summary['preservedAllocationTests']=202
  summary['newCheckoutTests']=counts['pass']-202
  run(['node','cloudflare/payment-allocation/scripts/check-deployment.mjs'],root,out/'disabled-config.json')
  run(['node','cloudflare/payment-allocation/scripts/check-checkout-deployment.mjs'],root,out/'checkout-disabled-config.json')
  run(['node','cloudflare/payment-allocation/scripts/compile-checkout-client.mjs'],root,out/'checkout-client-compile.log')
  run(['node','-e',"const {DatabaseSync}=require('node:sqlite');const db=new DatabaseSync(':memory:');console.log(JSON.stringify(db.prepare(require('node:fs').readFileSync('cloudflare/payment-allocation/scripts/check-sql-runtime.sql','utf8')).get()));db.close()"],root,out/'sql-runtime.json')
  summary['sqliteRuntime']=json.loads((out/'sql-runtime.json').read_text().splitlines()[0])
  syntax=0
  for p in sorted((BUNDLE/'files').rglob('*')):
   if p.suffix=='.mjs':run(['node','--check',str(p)],root,out/f'syntax-{syntax}.log');syntax+=1
   elif p.suffix in ['.json','.jsonc']:json.loads(p.read_text());syntax+=1
  summary['syntaxAndJsonChecks']=syntax
  spec=importlib.util.spec_from_file_location('installer_tests',BUNDLE/'tests/test_patch_installer.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  names=unittest.defaultTestLoader.getTestCaseNames(mod.PatchInstallerTests)
  def task(i):
   selected=names[i::6]
   code="import sys,unittest;sys.path.insert(0,sys.argv[1]);import test_patch_installer as m;r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(m.PatchInstallerTests(n) for n in sys.argv[2:]));sys.exit(not r.wasSuccessful())"
   run([sys.executable,'-c',code,str(BUNDLE/'tests'),*selected],root,out/f'installer-{i}.log');return len(selected)
  with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:summary['installerTestsPassed']=sum(pool.map(task,range(6)))
  trials=[]
  for label,number in [('no-additions',0),('half-preinstalled',len(m['entries'])//2),('all-preinstalled',len(m['entries']))]:
   checkout=Path(tmp)/label;shutil.copytree(BUNDLE/'context',checkout)
   for e in m['entries'][:number]:
    dest=checkout/e['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(BUNDLE/'files'/e['path'],dest)
   before=source_map(checkout);cmd=[sys.executable,str(BUNDLE/'apply_patch.py'),'--root',str(checkout)]
   run(cmd,checkout,out/f'{label}-preflight.json')
   applied=json.loads(run(cmd+['--apply'],checkout,out/f'{label}-apply.json'))
   for e in m['entries']:assert sha(checkout/e['path'])==e['after_sha256']
   again=json.loads(run(cmd+['--apply'],checkout,out/f'{label}-repeat.json'));assert again['status']=='already_applied'
   if applied['source_files_changed']:
    run(cmd+['--rollback',applied['rollback_directory']],checkout,out/f'{label}-rollback.json')
   assert source_map(checkout)==before
   trials.append({'startingState':label,'sourceFilesChanged':applied['source_files_changed'],'repeatChanged':0,'startingBytesRestored':True})
  summary['sourceInstallationTrials']=trials
 summary['targetedTestsPassed']=summary['moduleTests']['pass']+summary['installerTestsPassed']
 (out/'verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
