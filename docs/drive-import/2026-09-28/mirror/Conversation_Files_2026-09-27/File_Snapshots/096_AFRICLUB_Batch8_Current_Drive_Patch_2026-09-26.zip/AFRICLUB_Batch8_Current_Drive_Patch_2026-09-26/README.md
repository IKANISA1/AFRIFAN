# AFRICLUB Batch 8 source delivery

All 22 source changes are saved in Drive and byte-verified. This package is an
incremental extension against the prior current payment-allocation module, not a
cumulative downgrade. Read the implementation report and MEMBERSHIP_CHECKOUT.md.

Run `python3 apply_patch.py --root /path/to/AFRICLUB` for read-only preflight;
add `--apply` only on a matching authorized checkout with builds/editors stopped.
Retain the printed rollback directory. No installer command executes SQL, makes a
provider call, changes roles/billing, or deploys. The runtime remains disabled.

Run `python3 verify_bundle.py --results /tmp/africlub-batch8-checks` to repeat local
source/SQL/client tests and installation/rollback trials. Requires Node with
node:sqlite, Python and TypeScript. Full pinned repository and Cloudflare tests
remain separate. Reports/evidence are not production approval.
