#!/usr/bin/env python3
"""Offline source tests and disposable installer trials. No service deployment or import."""
from pathlib import Path
import argparse,hashlib,json,re,shutil,subprocess,sys,tempfile
B=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True);a=p.parse_args();a.results.mkdir(parents=True,exist_ok=True)
 catalog=B/'bundle_checksums.json'
 if catalog.exists():
  for name,digest in json.loads(catalog.read_text()).items():
   if hashlib.sha256((B/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('Bundle checksum mismatch: '+name)
 def run(name,args,cwd=B,timeout=120):
  r=subprocess.run(args,cwd=cwd,text=True,capture_output=True,timeout=timeout);(a.results/(name+'.log')).write_text(r.stdout+r.stderr)
  if r.returncode:raise RuntimeError('Failed: '+name)
  return r.stdout+r.stderr
 manifest=json.loads((B/'manifest.json').read_text());entries=manifest['entries'];trial_results=[]
 with tempfile.TemporaryDirectory(prefix='africlub-batch9-') as td:
  root=Path(td)/'repo';shutil.copytree(B/'context',root)
  baseline={str(q.relative_to(root)):q.read_bytes() for q in root.rglob('*') if q.is_file()}
  for label,preset in [('partial-drive-baseline',[]),('some-new-files-already-saved',entries[::2]),('all-matching',entries)]:
   if root.exists():shutil.rmtree(root)
   shutil.copytree(B/'context',root)
   for e in preset:
    target=root/e['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(B/'files'/e['path'],target)
   before={str(q.relative_to(root)):q.read_bytes() for q in root.rglob('*') if q.is_file()}
   args=[sys.executable,str(B/'apply_patch.py'),'--root',str(root)]
   pre=json.loads(run(label+'-preflight',args));applied=json.loads(run(label+'-apply',args+['--apply']));again=json.loads(run(label+'-repeat',args+['--apply']))
   if again['status']!='already_applied':raise RuntimeError('Non-idempotent source installer')
   for e in entries:
    if hashlib.sha256((root/e['path']).read_bytes()).hexdigest()!=e['after_sha256']:raise RuntimeError('Bad applied bytes')
   if applied.get('rollback_directory'):run(label+'-rollback',args+['--rollback',applied['rollback_directory']])
   for rel,content in before.items():
    if (root/rel).read_bytes()!=content:raise RuntimeError('Rollback changed starting bytes')
   for e in entries:
    if e['path'] not in before and (root/e['path']).exists():raise RuntimeError('Rollback retained a new file')
   trial_results.append({'scenario':label,'changes':pre['source_files_to_change'],'rollback_restored_starting_bytes':True})
  # Assembled source, never the live Drive folder.
  shutil.rmtree(root);shutil.copytree(B/'context',root)
  for e in entries:
   dst=root/e['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(B/'files'/e['path'],dst)
  groups={
   'new-gateway':sorted((root/'cloudflare/supporter-membership-api/tests').glob('*.test.mjs')),
   'payment-regressions':sorted((root/'cloudflare/payment-allocation/tests').glob('*.test.mjs')),
   'auth-regressions':[root/'cloudflare/supporter-auth/tests'/x for x in ['identity.test.mjs','delivery.test.mjs','security-http.test.mjs']]}
  totals={}
  for name,files in groups.items():
   text=run(name,['node','--test',*map(str,files)],cwd=root)
   for marker in ['fail','cancelled','skipped','todo']:
    if not re.search(r'^# '+marker+r' 0$',text,re.M):raise RuntimeError('Incomplete node suite '+name)
   totals[name]=int(re.search(r'^# pass (\d+)$',text,re.M).group(1))
  for name,path in [('gateway-config','cloudflare/supporter-membership-api/scripts/check-deployment.mjs'),('gateway-ts','cloudflare/supporter-membership-api/scripts/compile-client.mjs'),('allocation-config','cloudflare/payment-allocation/scripts/check-deployment.mjs'),('checkout-config','cloudflare/payment-allocation/scripts/check-checkout-deployment.mjs')]:run(name,['node',path],cwd=root)
  syntaxes=0
  for e in entries:
   file=root/e['path']
   if file.suffix=='.mjs':run('syntax-'+str(syntaxes),['node','--check',str(file)]);syntaxes+=1
   elif file.suffix in ['.json','.jsonc']:json.loads(file.read_text());syntaxes+=1
  methods=re.findall(r'^    def (test_[a-z0-9_]+)\(', (B/'tests/test_patch_installer.py').read_text(),re.M)
  totals['installer']=0
  for start in range(0,len(methods),6):
   group=['test_patch_installer.PatchInstallerTests.'+name for name in methods[start:start+6]]
   text=run('installer-regressions-'+str(start//6),[sys.executable,'-m','unittest','-v',*group],cwd=B/'tests',timeout=45)
   totals['installer']+=int(re.search(r'Ran (\d+) tests',text).group(1))
  report={'sourcePaths':len(entries),'testGroups':totals,'targetedTestsPassed':sum(totals.values()),'syntaxAndJsonChecks':syntaxes,'installerTrials':trial_results,'realCloudflareRuntime':False,'fullFlutterBuild':False,'liveProviderCalls':0}
  (a.results/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
