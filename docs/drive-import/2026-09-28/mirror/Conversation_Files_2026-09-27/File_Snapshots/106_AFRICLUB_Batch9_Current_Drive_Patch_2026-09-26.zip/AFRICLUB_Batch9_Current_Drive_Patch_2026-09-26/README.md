# AFRICLUB Batch9 incremental source package

Completes the partially saved authenticated-supporter membership gateway. Twenty
source paths are included: ten additions in this continuation, two corrections,
and eight unchanged current source files. All twenty are already saved in Drive.
No deployment or database migration is performed by this package.

Read AFRICLUB_Batch9_Implementation_Report_2026-09-26.md for scope and limitations.
The local final evidence records 702 passing targeted tests, including 160 gateway
checks. All 669 code tests passed again on downloaded Drive module bytes. These are
not real Cloudflare/native release tests. Native storage and cross-database
revocation remain unfinished.

From this extracted directory, with editors and builds stopped:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB"
python3 apply_patch.py --root "/path/to/AFRICLUB" --apply
python3 verify_bundle.py --results "/tmp/africlub-batch9-verification"
```

The first command is read-only. Unknown source edits stop application. Rollback
requires the exact directory returned by a successful apply:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB" --rollback "/returned/rollback/directory"
```

The verifier runs offline source trials, Node tests, TypeScript compilation and
Python installer tests. Node with node:sqlite/Web Crypto, tsc and Python are required.
The original higher monorepo SDK requirements remain unchanged. Allow a full local
verification run to finish; constrained tool windows may require group execution.

Do not force an old cumulative archive over newer canonical source. The context
folder is scoped recovery/test material, not a full repository or production backup.
No real payments, accounts, credentials, media originals, font files or dependency
caches are included. Test fixtures are synthetic.
