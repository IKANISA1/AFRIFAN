from __future__ import annotations
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

SCRIPT = Path(__file__).resolve().parents[1] / 'apply_patch.py'
spec = importlib.util.spec_from_file_location('installer', SCRIPT)
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)


def sha(data):
    return hashlib.sha256(data).hexdigest()


class PatchInstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.root = self.base / 'repo'
        self.bundle = self.base / 'bundle'
        self.root.mkdir(); self.bundle.mkdir()
        self.original = {'pubspec.yaml': b'name: africlub_workspace\n', 'src/existing.txt': b'original\n'}
        self.payload = {'pubspec.yaml': b'name: africlub_workspace\n# new command\n',
                        'src/existing.txt': b'revised\n', 'src/new.txt': b'new file\n'}
        entries = []
        for path, data in self.payload.items():
            target = self.bundle / 'files' / path
            target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
            before = self.original.get(path)
            if before is not None:
                target = self.root / path
                target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(before)
            entries.append({'path': path, 'before_sha256': sha(before) if before else None,
                            'after_sha256': sha(data), 'new_mode': 0o644})
        (self.root/'baseline.sql').write_text('-- preserve\n')
        self.manifest = {'schema_version': 1, 'kind': 'source-only-patch', 'patch_id': 'test-patch',
                         'entries': entries, 'preconditions': [{'path':'baseline.sql', 'sha256':sha(b'-- preserve\n')}]}
        self.save()

    def save(self):
        (self.bundle/'manifest.json').write_text(json.dumps(self.manifest))

    def run_cli(self, *args):
        return subprocess.run([sys.executable, str(SCRIPT), '--bundle', str(self.bundle), '--root', str(self.root), *map(str,args)],
                              capture_output=True, text=True)

    def install(self):
        result = self.run_cli('--apply')
        self.assertEqual(result.returncode, 0, result.stderr)
        return Path(json.loads(result.stdout)['rollback_directory'])

    def assert_original(self):
        for path,data in self.original.items(): self.assertEqual((self.root/path).read_bytes(), data)
        self.assertFalse((self.root/'src/new.txt').exists())

    def test_dry_run_has_no_writes_or_backup_directory(self):
        result=self.run_cli(); self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(json.loads(result.stdout)['source_files_to_change'],3)
        self.assert_original(); self.assertFalse((self.root/'output').exists())

    def test_apply_writes_exact_payloads_and_verified_backups(self):
        run=self.install()
        for path,data in self.payload.items(): self.assertEqual((self.root/path).read_bytes(),data)
        for path,data in self.original.items(): self.assertEqual((run/'files'/path).read_bytes(),data)
        self.assertEqual(json.loads((run/'journal.json').read_text())['state'],'applied')

    def test_reapplying_is_idempotent(self):
        self.install(); result=self.run_cli('--apply')
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(json.loads(result.stdout)['status'],'already_applied')
        self.assertEqual(len(list((self.root/'output/refactor-backups').glob('*/journal.json'))),1)

    def test_source_conflict_prevents_all_source_writes(self):
        (self.root/'src/existing.txt').write_bytes(b'other author\n')
        result=self.run_cli('--apply'); self.assertEqual(result.returncode,2)
        self.assertEqual((self.root/'pubspec.yaml').read_bytes(),self.original['pubspec.yaml'])
        self.assertFalse((self.root/'src/new.txt').exists())

    def test_existing_new_file_is_not_overwritten(self):
        (self.root/'src/new.txt').write_text('unrelated')
        self.assertEqual(self.run_cli('--apply').returncode,2)
        self.assertEqual((self.root/'src/new.txt').read_text(),'unrelated')

    def test_corrupt_payload_prevents_source_writes(self):
        (self.bundle/'files/src/new.txt').write_text('tampered')
        self.assertEqual(self.run_cli('--apply').returncode,2); self.assert_original()

    def test_changed_baseline_prevents_source_writes(self):
        (self.root/'baseline.sql').write_text('changed')
        self.assertEqual(self.run_cli('--apply').returncode,2); self.assert_original()

    def test_manifest_traversal_rejected(self):
        self.manifest['entries'][0]['path']='../escape'; self.save()
        self.assertEqual(self.run_cli('--apply').returncode,2); self.assert_original()
        self.assertFalse((self.base/'escape').exists())

    def test_protected_repository_paths_rejected(self):
        self.manifest['entries'][1]['path']='.git/config'; self.save()
        self.assertEqual(self.run_cli('--apply').returncode,2); self.assert_original()

    def test_duplicate_paths_rejected(self):
        self.manifest['entries'].append(self.manifest['entries'][0]); self.save()
        self.assertEqual(self.run_cli('--apply').returncode,2); self.assert_original()

    def test_parent_symlink_rejected(self):
        (self.root/'src/existing.txt').unlink(); (self.root/'src').rmdir()
        outside=self.base/'outside'; outside.mkdir(); (outside/'existing.txt').write_bytes(self.original['src/existing.txt'])
        (self.root/'src').symlink_to(outside, target_is_directory=True)
        self.assertEqual(self.run_cli('--apply').returncode,2)
        self.assertEqual((outside/'existing.txt').read_bytes(),self.original['src/existing.txt'])

    def test_dangling_target_symlink_rejected(self):
        (self.root/'src/new.txt').symlink_to(self.base/'missing')
        self.assertEqual(self.run_cli('--apply').returncode,2)
        self.assertFalse((self.base/'missing').exists())

    def test_payload_symlink_rejected(self):
        target=self.bundle/'files/src/new.txt'; target.unlink()
        outside=self.base/'payload'; outside.write_bytes(self.payload['src/new.txt']); target.symlink_to(outside)
        self.assertEqual(self.run_cli('--apply').returncode,2); self.assert_original()

    def test_original_permissions_preserved(self):
        (self.root/'src/existing.txt').chmod(0o750)
        run=self.install()
        self.assertEqual(stat.S_IMODE((self.root/'src/existing.txt').stat().st_mode),0o750)
        result=self.run_cli('--rollback',run); self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(stat.S_IMODE((self.root/'src/existing.txt').stat().st_mode),0o750)

    def test_rollback_restores_originals_and_removes_only_added_files(self):
        run=self.install(); (self.root/'src/unrelated.txt').write_text('keep')
        result=self.run_cli('--rollback',run); self.assertEqual(result.returncode,0,result.stderr)
        self.assert_original(); self.assertEqual((self.root/'src/unrelated.txt').read_text(),'keep')

    def test_rollback_is_idempotent(self):
        run=self.install()
        self.assertEqual(self.run_cli('--rollback',run).returncode,0)
        self.assertEqual(self.run_cli('--rollback',run).returncode,0); self.assert_original()

    def test_rollback_refuses_concurrent_edits_before_restoring_anything(self):
        run=self.install(); (self.root/'src/new.txt').write_text('post-install author edit')
        self.assertEqual(self.run_cli('--rollback',run).returncode,2)
        self.assertEqual((self.root/'pubspec.yaml').read_bytes(),self.payload['pubspec.yaml'])
        self.assertEqual((self.root/'src/new.txt').read_text(),'post-install author edit')

    def test_rollback_refuses_corrupt_backup(self):
        run=self.install(); (run/'files/src/existing.txt').write_text('corrupted backup')
        self.assertEqual(self.run_cli('--rollback',run).returncode,2)
        self.assertEqual((self.root/'pubspec.yaml').read_bytes(),self.payload['pubspec.yaml'])

    def test_rollback_rejects_foreign_directory(self):
        run=self.install()
        self.assertEqual(self.run_cli('--rollback',self.bundle).returncode,2)
        self.assertEqual(json.loads((run/'journal.json').read_text())['state'],'applied')

    def test_rollback_journal_cannot_add_out_of_scope_operations(self):
        run=self.install(); path=run/'journal.json'; data=json.loads(path.read_text())
        data['operations'].append({'path':'unrelated.txt','before_sha256':None,'after_sha256':sha(b'x'),'mode':0o644})
        path.write_text(json.dumps(data))
        self.assertEqual(self.run_cli('--rollback',run).returncode,2)
        self.assertEqual((self.root/'pubspec.yaml').read_bytes(),self.payload['pubspec.yaml'])

    def test_exception_after_first_write_rolls_back(self):
        manifest, mh=installer.read_manifest(self.bundle)
        original_write=installer.atomic_write
        failed=False
        def fail_once(path,data,mode):
            nonlocal failed
            if path==self.root/'src/existing.txt' and data==b'revised\n' and not failed:
                failed=True; raise OSError('injected disk failure')
            return original_write(path,data,mode)
        with mock.patch.object(installer,'atomic_write',side_effect=fail_once):
            with self.assertRaises(installer.PatchError):
                installer.apply(self.root,self.bundle,manifest,mh)
        self.assertTrue(failed); self.assert_original()
        journal=next((self.root/'output/refactor-backups').glob('*/journal.json'))
        self.assertEqual(json.loads(journal.read_text())['state'],'rolled_back')

    def test_repository_lock_blocks_second_writer(self):
        with installer.repository_lock(self.root):
            result=self.run_cli('--apply')
        self.assertEqual(result.returncode,2); self.assertIn('Another patch operation',result.stderr)
        self.assert_original()

    def test_already_installed_file_is_not_reverted_by_later_patch_rollback(self):
        (self.root/'src/existing.txt').write_bytes(self.payload['src/existing.txt'])
        run=self.install()
        self.assertEqual(self.run_cli('--rollback',run).returncode,0)
        self.assertEqual((self.root/'src/existing.txt').read_bytes(),self.payload['src/existing.txt'])
        self.assertEqual((self.root/'pubspec.yaml').read_bytes(),self.original['pubspec.yaml'])

    def test_boolean_manifest_version_rejected(self):
        self.manifest['schema_version']=True; self.save()
        self.assertEqual(self.run_cli('--apply').returncode,2); self.assert_original()


    def test_upgrade_of_prior_added_file_backs_up_and_restores_that_version(self):
        previous=b'previous batch addition\n'
        entry=next(e for e in self.manifest['entries'] if e['path']=='src/new.txt')
        entry['accepted_before_sha256']=[sha(previous)];self.save()
        (self.root/'src/new.txt').write_bytes(previous)
        run=self.install();self.assertEqual((run/'files/src/new.txt').read_bytes(),previous)
        self.assertEqual(self.run_cli('--rollback',run).returncode,0)
        self.assertEqual((self.root/'src/new.txt').read_bytes(),previous)

    def test_upgrade_accepts_only_enumerated_versions_of_an_original(self):
        entry=next(e for e in self.manifest['entries'] if e['path']=='src/existing.txt')
        old=b'known v2 version\n';entry['accepted_before_sha256']=[sha(old)];self.save()
        (self.root/'src/existing.txt').write_bytes(old)
        run=self.install();self.assertEqual(self.run_cli('--rollback',run).returncode,0)
        self.assertEqual((self.root/'src/existing.txt').read_bytes(),old)

    def test_prior_hash_does_not_allow_unknown_concurrent_edit(self):
        entry=self.manifest['entries'][1];entry['accepted_before_sha256']=[sha(b'known\n')];self.save()
        (self.root/'src/existing.txt').write_bytes(b'unknown\n')
        self.assertEqual(self.run_cli('--apply').returncode,2)
        self.assertFalse((self.root/'src/new.txt').exists())

    def test_invalid_prior_hash_lists_rejected_without_source_writes(self):
        for invalid in (None,True,'abc',[None],['*'],['f'*64,'f'*64],['x'*64]):
            with self.subTest(invalid=invalid):
                self.manifest['entries'][1]['accepted_before_sha256']=invalid;self.save()
                self.assertEqual(self.run_cli('--apply').returncode,2);self.assert_original()

    def test_prior_hash_limits_and_redundant_hashes_rejected(self):
        entry=self.manifest['entries'][1]
        for invalid in ([sha(str(n).encode()) for n in range(5)],[entry['before_sha256']],[entry['after_sha256']]):
            with self.subTest(invalid=invalid):
                entry['accepted_before_sha256']=invalid;self.save()
                self.assertEqual(self.run_cli('--apply').returncode,2);self.assert_original()

    def test_absent_new_file_still_installs_when_prior_version_is_accepted(self):
        self.manifest['entries'][2]['accepted_before_sha256']=[sha(b'prior addition\n')];self.save()
        run=self.install();self.assertEqual(self.run_cli('--rollback',run).returncode,0);self.assert_original()

    def test_upgrade_disk_failure_restores_installed_prior_version(self):
        prior=b'previous version\n';entry=self.manifest['entries'][0]
        entry['accepted_before_sha256']=[sha(prior)];self.save();(self.root/'pubspec.yaml').write_bytes(prior)
        manifest,mh=installer.read_manifest(self.bundle);real=installer.atomic_write
        def failing(path,data,mode):
            if path==self.root/'src/existing.txt' and data==b'revised\n':raise OSError('injected')
            return real(path,data,mode)
        with mock.patch.object(installer,'atomic_write',side_effect=failing):
            with self.assertRaises(installer.PatchError):installer.apply(self.root,self.bundle,manifest,mh)
        self.assertEqual((self.root/'pubspec.yaml').read_bytes(),prior)
        self.assertEqual((self.root/'src/existing.txt').read_bytes(),self.original['src/existing.txt'])

    def test_upgrade_rollback_refuses_unrecognized_journal_before_hash(self):
        prior=b'previous version\n';self.manifest['entries'][0]['accepted_before_sha256']=[sha(prior)];self.save()
        (self.root/'pubspec.yaml').write_bytes(prior);run=self.install();p=run/'journal.json';j=json.loads(p.read_text())
        j['operations'][0]['before_sha256']='f'*64;p.write_text(json.dumps(j))
        self.assertEqual(self.run_cli('--rollback',run).returncode,2)
        self.assertEqual((self.root/'pubspec.yaml').read_bytes(),self.payload['pubspec.yaml'])

    def test_upgraded_payload_reapply_is_idempotent(self):
        prior=b'previous version\n';self.manifest['entries'][0]['accepted_before_sha256']=[sha(prior)];self.save()
        (self.root/'pubspec.yaml').write_bytes(prior);self.install()
        result=self.run_cli('--apply');self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(json.loads(result.stdout)['status'],'already_applied')


if __name__=='__main__': unittest.main()
