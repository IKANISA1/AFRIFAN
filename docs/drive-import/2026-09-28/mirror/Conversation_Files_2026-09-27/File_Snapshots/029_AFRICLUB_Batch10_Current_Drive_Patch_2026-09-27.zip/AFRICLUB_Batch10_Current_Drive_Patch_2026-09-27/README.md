# AFRICLUB Batch 10 incremental source package

27 September 2026. Apply only to a matching current checkout. Do not install old
v1-v4 cumulative packages over newer Drive source. This contains the native handoff
continuation, not a complete repository, native release or production migration.

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB"
python3 apply_patch.py --root "/path/to/AFRICLUB" --apply
python3 verify_bundle.py --results "/tmp/africlub-batch10-verification"
```

The installer stops on unknown edits, preserves current versions on rollback and
performs no network, database, provider, account or deployment operations. Stop
builds/editors during multi-file application and retain its rollback journal.

**Dart/Flutter execution is not verified at delivery.** The bundle verifier returns
exit 2 when its pure-Dart SDK check is blocked, even if all Node and installer tests
pass. This is not a green release gate. The real Flutter bridge, secure platform
store/lock, lifecycle UI and physical-device checks remain required.

`context/` contains a scoped, checksum-verified source baseline for offline tests,
not source files to overwrite. `files/` contains the only 21 proposed source changes.
The original source IDs, test logs, exact hashes and separate implementation report
record scope and limitations. All synthetic fixtures are test-only; do not use their
in-memory recovery store or identities in shipped apps.
