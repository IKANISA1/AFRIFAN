# AFRICLUB Batch 7 — additive current-Drive payment candidate

All 22 new source paths are in `files/`. `context/` preserves seven read-only
source migrations and the unchanged root manifest for hash checks, not overwrites.
The source-readback register identifies each newly uploaded Drive file and hash.

No previous cumulative package should downgrade newer source. This package is
additive and staging-only. It does not implement the complete financial migration.
The report documents contribution allocation without reward/referral finalization.

From this package directory, against an authorized matching checkout:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB"
python3 apply_patch.py --root "/path/to/AFRICLUB" --apply
python3 verify_bundle.py --results "/tmp/africlub-batch7-checks"
```

Stop source editors/builds before multi-file changes. Conflicts mean stop and
reconcile, not force replacement. Application creates a scoped rollback journal
when files change; retain it. A checkout matching saved Drive should report zero
changes. No command deploys, sends money/messages, imports SQL or enables access.

Run full pinned repository, real D1, client/provider and human release acceptance
separately. No production membership was changed. All fixtures are synthetic.
