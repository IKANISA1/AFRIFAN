from pathlib import Path
import json,re,hashlib,py_compile
W=Path('/mnt/data/africlub_batch11');E=W/'evidence/final-run';B=W/'bundle/AFRICLUB_Batch11_Current_Drive_Patch_2026-09-27'
manifest=json.loads((B/'manifest.json').read_text());totals={}
for name in ['gateway-and-handoff','payment-regressions','auth-regressions']:
 t=(E/(name+'.log')).read_text()
 for mark in ['fail','cancelled','skipped','todo']:assert re.search(r'^# '+mark+r' 0$',t,re.M)
 totals[name]=int(re.search(r'^# pass (\d+)$',t,re.M)[1])
installer=0
for n in range(6):
 t=(E/f'installer-regressions-{n}.log').read_text();assert re.search(r'\nOK\s*$',t),n
 installer+=int(re.search(r'Ran (\d+) tests',t)[1])
assert installer==33;totals['installer']=installer
jvm=json.loads((E/'jvm/android-recovery-verification.json').read_text());assert jvm['status']=='passed_portable_jvm_only'
for rel,h in jvm['sourceHashes'].items():assert hashlib.sha256((B/'files'/rel).read_bytes()).hexdigest()==h,rel
kt=(E/'jvm/contracts.log').read_text();n=int(re.search(r'^SUMMARY passed=(\d+) failed=0 skipped=0$',kt,re.M)[1]);assert n==len(re.findall('^PASS ',kt,re.M))==jvm['portableJvmTestsPassed'];totals['portable-kotlin-recovery']=n
trials=[]
for name in ['current-drive-baseline','some-new-files-already-saved','all-matching']:
 pre=json.loads((E/(name+'-preflight.log')).read_text());repeated=json.loads((E/(name+'-repeat.log')).read_text());assert repeated['status']=='already_applied'
 if pre['source_files_to_change']:assert json.loads((E/(name+'-rollback.log')).read_text())['status']=='rolled_back'
 trials.append({'scenario':name,'sourceFilesChanged':pre['source_files_to_change'],'applicationAndIdempotencePassed':True,'rollbackVerifiedByRunner':True})
# Read only complete, successful outputs. The missing combined-run summary is not treated as a pass.
native=json.loads((E/'native/native-verification.json').read_text());assert native['status']=='blocked' and native['dartExecuted']==False
syntax=0
for e in manifest['entries']:
 p=B/'files'/e['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==e['after_sha256']
 if p.suffix in ['.json','.jsonc']:json.loads(p.read_text());syntax+=1
 elif p.suffix=='.py':compile(p.read_text(),str(p),'exec');syntax+=1
report={'schemaVersion':1,'date':'2026-09-27','sourceChanges':len(manifest['entries']),'additions':sum(e['before_sha256'] is None for e in manifest['entries']),
 'testGroups':totals,'targetedTestsPassed':sum(totals.values()),'newExecutedTestsPassed':n,'additionalJsonAndPythonSyntaxChecks':syntax,
 'manifestSha256':hashlib.sha256((B/'manifest.json').read_bytes()).hexdigest(),'installerTrials':trials,'nativeVerification':native,
 'portableRecoveryVerification':jvm,'overallStatus':'portable_checks_passed_native_blocked',
 'executionNote':'The combined runner hit the host command limit during installer slices. All six independently completed installer slices were then checked with the complete Node/JVM logs. Partial/incomplete runs are not counted.',
 'androidHostCompiled':False,'androidKeystoreVerified':False,'flutterCompiled':False,'dartExecuted':False,'deviceTestsExecuted':False,'appsRegistered':0,
 'remoteMigrations':0,'realProviderCalls':0,'wholeMigrationCompleted':False}
(E/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['sourceChanges','additions','testGroups','targetedTestsPassed','installerTrials','overallStatus']},indent=2))
