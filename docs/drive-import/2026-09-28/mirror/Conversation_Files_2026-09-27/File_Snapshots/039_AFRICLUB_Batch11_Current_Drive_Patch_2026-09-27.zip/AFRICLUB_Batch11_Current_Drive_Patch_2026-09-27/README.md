# AFRICLUB Batch 11 — incremental native recovery source

Current-source patch: 13 additions and 3 existing-file updates. Not a cumulative
v1-v4 replacement. Android storage/Flutter host and Dart are not device validated;
no app is registered or switched. Runtime adapters are disabled by default.

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB"
python3 apply_patch.py --root "/path/to/AFRICLUB" --apply
python3 verify_bundle.py --results "/tmp/africlub-batch11-checks"
```

Unknown edits stop the installer. Stop builds/editors during a multi-file install.
Keep its rollback journal. No script deploys, runs remote migrations, sends payments,
changes billing, installs SDKs or enables roles. Exit 2 of the bundle verifier means
native tooling is blocked even when portable/Node/installer tests pass. Check the
implementation report and native/android/README.md for the actual validation scope.
The before-source backup is scoped, not a full repository or database backup.
