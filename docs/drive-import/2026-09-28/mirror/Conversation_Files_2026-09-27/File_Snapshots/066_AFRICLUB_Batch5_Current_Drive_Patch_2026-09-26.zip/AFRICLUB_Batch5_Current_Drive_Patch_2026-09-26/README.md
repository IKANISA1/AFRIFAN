# AFRICLUB Batch5 — current-Drive incremental patch

Read `AFRICLUB_Batch5_Implementation_Report_2026-09-26.md` first.

This is **not cumulative v5**. The live Drive source had already advanced beyond
historical v4. Sixteen new source files are delivered with one exact-hash edit to
the current queued-auth delivery file. No older auth schema, API or client is
substituted. Do not apply v1-v4 cumulative archives to downgrade the newer files.

Preflight and apply to an authorized matching local checkout with editors/builds
stopped:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB"
python3 apply_patch.py --root "/path/to/AFRICLUB" --apply
python3 verify_bundle.py --results "/tmp/africlub-batch5-checks"
```

Keep the printed rollback journal. Unknown edits fail without force-overwriting.
`files/` contains proposed source changes; `context/` contains the scoped, current
before-source and unchanged test prerequisites used for isolated verification.
`context/` is not a full repository and must not be blindly copied over one.

Sixteen new sources were created in Drive and checksum-verified. The existing-file
update was blocked by connector argument validation; its proposed bytes are in this
bundle and saved separately in output. They were NOT installed into the original.
The source backup and full delivery/readback receipts are saved alongside the
package in `AFRICLUB/output/refactor-2026-09-26/batch5-whatsapp-delivery/`.

The private provider template remains disabled. The original queue keeps its legacy
mode until a separate reviewed staging configuration explicitly selects the new
private transport. Missing private bindings never fall back to the legacy sender.
The installer applies no SQL, sends no message and makes no account/deployment call.

The 234 executed targeted tests are scoped current-code and new-code checks; they
are not a full application, live provider, workerd or production acceptance result.
