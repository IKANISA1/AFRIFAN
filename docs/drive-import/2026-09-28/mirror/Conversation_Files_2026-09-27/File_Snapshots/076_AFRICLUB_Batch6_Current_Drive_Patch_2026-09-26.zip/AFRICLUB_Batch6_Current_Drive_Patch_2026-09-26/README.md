# AFRICLUB Batch 6 — current-source incremental patch

21 paths: 19 new receipt files, README update and previously pending Batch5 delivery integration. All 21 are installed at exact Drive source paths with checksum readback. No deployment or database migration. This is NOT a cumulative v4 downgrade.

See the implementation report, manifest.json, baseline_provenance.json and the source/verification registers. Tests and evidence are bundled.

From this directory, stop editors/builds then run:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB"
python3 apply_patch.py --root "/path/to/AFRICLUB" --apply
python3 verify_bundle.py --results "/tmp/africlub-batch6-verification"
```

Unknown edits stop application. Already matching source is preserved. Retain the printed rollback directory. The installer performs no network, provider, SQL, billing, secret or deployment calls. All new runtime templates remain disabled.
