#!/usr/bin/env python3
"""Verify the source-only, current-Drive incremental patch in disposable local storage.
No remote account, database, provider or deployment operations are made.
"""
from pathlib import Path
import argparse,concurrent.futures,hashlib,importlib.util,json,re,shutil,subprocess,sys,tempfile,time,unittest
BUNDLE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(command,where,log):
 result=subprocess.run(command,cwd=where,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log.write_text(result.stdout)
 if result.returncode:raise RuntimeError(f'Check failed; see {log}')
 return result.stdout

def source_map(root):return {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file() and 'output' not in p.relative_to(root).parts}
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--results',type=Path,required=True);args=parser.parse_args()
 output=args.results.absolute();output.mkdir(parents=True,exist_ok=True)
 m=json.loads((BUNDLE/'manifest.json').read_text())
 for e in m['entries']:assert sha(BUNDLE/'files'/e['path'])==e['after_sha256'],e['path']
 for e in m['preconditions']:assert sha(BUNDLE/'context'/e['path'])==e['sha256'],e['path']
 summary={'manifest_sha256':sha(BUNDLE/'manifest.json'),'sourceChanges':len(m['entries']),
  'nodeVersion':subprocess.check_output(['node','--version'],text=True).strip(),'pythonVersion':sys.version.split()[0],
  'remoteOperations':0,'actualProviderMessagesSent':0,'deploymentPerformed':False}
 with tempfile.TemporaryDirectory(prefix='africlub-b6-verify-') as temp:
  candidate=Path(temp)/'candidate';shutil.copytree(BUNDLE/'context',candidate);shutil.copytree(BUNDLE/'files',candidate,dirs_exist_ok=True)
  tests=sorted(candidate.glob('cloudflare/auth-code-delivery/tests/*.test.mjs'))
  tests+=sorted(candidate.glob('cloudflare/supporter-auth/tests/*.test.mjs'))
  text=run(['node','--test',*map(str,tests)],candidate,output/'node-tests.log')
  counts={k:int(re.search(rf'^# {k} (\d+)$',text,re.M).group(1)) for k in ['tests','pass','fail','skipped']}
  assert counts['fail']==0 and counts['skipped']==0;summary['nodeTests']=counts
  run(['node','cloudflare/auth-code-delivery/scripts/check-deployment.mjs'],candidate,output/'disabled-config.log')
  run(['node','cloudflare/auth-code-delivery/scripts/check-receipts-deployment.mjs'],candidate,output/'receipts-disabled-config.log')
  checked=0
  for p in (BUNDLE/'files').rglob('*'):
   if p.suffix=='.mjs':run(['node','--check',str(p)],candidate,output/f'syntax-{checked}.log');checked+=1
   elif p.suffix in ['.json','.jsonc']:json.loads(p.read_text());checked+=1
  summary['syntaxAndJsonChecks']=checked
  # Reuse the exact previously tested installer; independently repeat its 33 regressions.
  spec=importlib.util.spec_from_file_location('installer_tests',BUNDLE/'tests/test_patch_installer.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  names=unittest.defaultTestLoader.getTestCaseNames(mod.PatchInstallerTests)
  def installer_slice(i):
   sub=names[i::6]
   code="import sys,unittest;sys.path.insert(0,sys.argv[1]);import test_patch_installer as m; suite=unittest.TestSuite(m.PatchInstallerTests(n) for n in sys.argv[2:]); r=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not r.wasSuccessful())"
   run([sys.executable,'-c',code,str(BUNDLE/'tests'),*sub],candidate,output/f'installer-{i}.log');return len(sub)
  with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:total=sum(pool.map(installer_slice,range(6)))
  summary['installerTestsPassed']=total
  trials=[]
  for label,preinstall in [('before-delivery-integration',False),('current-drive-integrated',False),('new-source-already-uploaded',True)]:
   root=Path(temp)/label;shutil.copytree(BUNDLE/'context',root)
   if label!='before-delivery-integration':
    rel='cloudflare/supporter-auth/src/delivery.mjs';shutil.copy2(BUNDLE/'files'/rel,root/rel)
   if preinstall:
    for e in m['entries']:
     if e['before_sha256'] is None:
      p=root/e['path'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(BUNDLE/'files'/e['path'],p)
   before=source_map(root);cmd=[sys.executable,str(BUNDLE/'apply_patch.py'),'--root',str(root)]
   pre=json.loads(run(cmd,root,output/f'{label}-preflight.json'))
   applied=json.loads(run(cmd+['--apply'],root,output/f'{label}-apply.json'))
   for e in m['entries']:assert sha(root/e['path'])==e['after_sha256']
   again=json.loads(run(cmd+['--apply'],root,output/f'{label}-repeat.json'));assert again['status']=='already_applied'
   run(cmd+['--rollback',applied['rollback_directory']],root,output/f'{label}-rollback.json');assert source_map(root)==before
   trials.append({'startingState':label,'changed':applied['source_files_changed'],'rollbackRestoredExactStartingBytes':True})
  summary['installationTrials']=trials
 summary['totalTargetedTestsPassed']=summary['nodeTests']['pass']+summary['installerTestsPassed']
 summary['actualCloudflareRuntimeVerified']=False
 (output/'verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
