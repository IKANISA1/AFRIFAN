// Web Crypto only: no platform-specific crypto dependency or persistent raw secrets.
const encoder = new TextEncoder();
export function base64url(bytes) { return btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,''); }
export function bytes(value) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]+$/.test(value)) throw new Error('Invalid encoded bytes');
  const result=Uint8Array.from(atob(value.replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0));
  if (base64url(result)!==value) throw new Error('Noncanonical bytes');
  return result;
}
export function secret() { return base64url(crypto.getRandomValues(new Uint8Array(32))); }
export function code() {
  const sample=new Uint32Array(1), bound=Math.floor(2**32/1_000_000)*1_000_000;
  do { crypto.getRandomValues(sample); } while(sample[0]>=bound);
  return String(sample[0]%1_000_000).padStart(6,'0');
}
export async function sha(value) { return [...new Uint8Array(await crypto.subtle.digest('SHA-256',encoder.encode(value)))].map(b=>b.toString(16).padStart(2,'0')).join(''); }
export function equal(a,b) {
  if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length) return false;
  let difference=0; for(let i=0;i<a.length;i++) difference|=a.charCodeAt(i)^b.charCodeAt(i);
  return difference===0;
}
export function validKey(value) { try { return bytes(value).length===32; } catch { return false; } }
export async function mac(key,value) {
  const k=await crypto.subtle.importKey('raw',bytes(key),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  return [...new Uint8Array(await crypto.subtle.sign('HMAC',k,encoder.encode(value)))].map(b=>b.toString(16).padStart(2,'0')).join('');
}
export async function seal(key,context,value) {
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const k=await crypto.subtle.importKey('raw',bytes(key),'AES-GCM',false,['encrypt']);
  const encrypted=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:encoder.encode(context)},k,encoder.encode(JSON.stringify(value)));
  return `${base64url(iv)}.${base64url(new Uint8Array(encrypted))}`;
}
export async function unseal(key,context,value) {
  const [iv,payload,...extra]=value.split('.'); if(extra.length) throw new Error('Invalid ciphertext');
  const k=await crypto.subtle.importKey('raw',bytes(key),'AES-GCM',false,['decrypt']);
  return JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:bytes(iv),additionalData:encoder.encode(context)},k,bytes(payload))));
}
