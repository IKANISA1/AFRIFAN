#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
export function checkDeployment(c,{ready=false}={}) {
  const errors=[];const check=(yes,message)=>{if(!yes)errors.push(message);};
  check(c.name==='africlub-supporter-auth-staging','unexpected Worker name');
  check(c.main==='src/worker.mjs','unexpected entrypoint');
  check(c.workers_dev===false&&c.preview_urls===false,'unreviewed ingress');
  check(!c.assets&&!c.env&&!c.dispatch_namespaces&&!c.durable_objects,'unexpected router or binding override');
  check(!c.vars?.PHONE_HMAC_KEY&&!c.vars?.OTP_HMAC_KEY&&!c.vars?.RESPONSE_ENCRYPTION_KEY,'secrets must not be plaintext variables');
  check(c.vars?.AUTH_KEY_ID==='v1','unexpected identity key version');
  const db=c.d1_databases?.[0];
  check(c.d1_databases?.length===1&&db?.binding==='AUTH_DB'&&db?.database_name==='africlub-supporter-identity-staging'&&db?.migrations_dir==='migrations','isolated identity database required');
  if(ready) {
    check(c.vars?.AUTH_ENABLED==='true'&&c.vars?.MAINTENANCE_ENABLED==='true','service and privacy maintenance switches must be explicit');
    let origin;try{origin=new URL(c.vars.AUTH_ORIGIN);}catch{}
    check(origin?.protocol==='https:'&&origin?.origin===c.vars.AUTH_ORIGIN&&!origin?.hostname.endsWith('.invalid')&&!origin?.hostname.endsWith('.localhost')&&origin?.hostname!=='localhost','reviewed exact HTTPS origin required');
    check(c.routes?.length===1&&c.routes[0]?.custom_domain===true&&c.routes[0]?.pattern===origin?.hostname,'direct custom-domain ingress required');
    check(/^[0-9a-f-]{36}$/.test(db?.database_id||'')&&db.database_id!=='00000000-0000-0000-0000-000000000000','real isolated database ID required');
    check(c.services?.length===1&&c.services[0]?.binding==='OTP_DELIVERY'&&c.services[0]?.service==='africlub-auth-code-delivery-staging'&&c.services[0]?.entrypoint==='AuthenticationCodeDelivery','reviewed dedicated delivery binding required');
    check(c.triggers?.crons?.length===1&&c.triggers.crons[0]==='*/5 * * * *','bounded maintenance schedule required');
  }else {
    check(c.vars?.AUTH_ENABLED==='false'&&c.vars?.MAINTENANCE_ENABLED==='false','templates must stay disabled');
    check(c.vars?.AUTH_ORIGIN===''&&c.routes?.length===0&&c.services?.length===0&&c.triggers?.crons?.length===0,'template enables external activity');
    check(db?.database_id==='00000000-0000-0000-0000-000000000000','template must not select existing project data');
  }
  return {configurationPassed:errors.length===0,errors,mode:ready?'candidate-config-only':'disabled-template',
    liveIdentityMappingsVerified:false,liveProviderVerified:false,actualCloudflareRuntimeVerified:false,
    secretProvisioningVerified:false,releaseAuthorized:false,deploymentPerformed:false};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href) {
  try{const file=process.argv[2]||new URL('../wrangler.staging.jsonc',import.meta.url);const report=checkDeployment(JSON.parse(readFileSync(file,'utf8')),{ready:process.argv.includes('--ready')});console.log(JSON.stringify(report,null,2));if(!report.configurationPassed)process.exitCode=1;}
  catch{console.error('Invalid deployment input');process.exitCode=1;}
}
