/** Typed bearer protocol adapter. Native clients must use OS-protected storage.
 * No implicit sign-in, refresh, storage, retry, cookie or permission elevation. */
export interface Tokens {
  schemaVersion:1; tokenType:'Bearer'; userId:string; clubId:number; sessionId:string;
  accessToken:string; refreshToken:string; accessExpiresAt:number; sessionExpiresAt:number;scope:'supporter:self';
}
export interface Challenge {schemaVersion:1;challengeId:string;clubId:number;state:'pending'|'sent'|'delivery_unknown'|'superseded'|'consumed'|'expired';expiresAt:number;}
export interface Identity {schemaVersion:1;userId:string;clubId:number;clubSlug:string;sessionId:string;phoneVerified:true;authenticatedAt:number;scope:'supporter:self';}
export class ProtocolError extends Error {constructor(public readonly code:string,public readonly status:number){super(code);}}
export class OutcomeUnknown extends Error {constructor(){super('Outcome unknown: preserve the original request and operation ID.');}}
const uuid=(v:unknown):v is string=>typeof v==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(v);
const obj=(v:unknown):v is Record<string,unknown>=>v!==null&&typeof v==='object'&&!Array.isArray(v);
function check(ok:unknown):asserts ok {if(!ok)throw new ProtocolError('invalid_protocol',0);}
export class SupporterAuthClient {
  private readonly origin:string;
  constructor(origin:string,readonly clubId:number,private readonly transport:typeof fetch=fetch,private readonly timeoutMs=15_000) {
    const url=new URL(origin);check(url.protocol==='https:'&&url.origin===origin&&!url.username&&!url.password&&Number.isSafeInteger(clubId)&&clubId>0);
    check(Number.isFinite(timeoutMs)&&timeoutMs>=1&&timeoutMs<=60_000);this.origin=origin;
  }
  async createVerifier():Promise<{verifier:string;verifierHash:string}> {
    const bytes=crypto.getRandomValues(new Uint8Array(32));
    const verifier=btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
    const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier));
    return {verifier,verifierHash:[...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,'0')).join('')};
  }
  newRequestId():string {return crypto.randomUUID();}
  private async call(path:string,input?:unknown,accessToken?:string):Promise<unknown> {
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),this.timeoutMs);
    try {
      const headers:Record<string,string>={Accept:'application/json'};
      if(input!==undefined){headers['Content-Type']='application/json';headers['X-AFRICLUB-Auth']='native-v1';}
      if(accessToken)headers.Authorization=`Bearer ${accessToken}`;
      const response=await this.transport(`${this.origin}/v1/auth/clubs/${this.clubId}/${path}`,{
        method:input===undefined?'GET':'POST',headers,credentials:'omit',redirect:'error',cache:'no-store',
        body:input===undefined?undefined:JSON.stringify(input),signal:controller.signal,
      });
      check(response.headers.get('content-type')?.includes('application/json'));
      const reader=response.body?.getReader();check(reader);let length=0;const chunks:Uint8Array[]=[];
      try{for(;;){const part=await reader.read();if(part.done)break;length+=part.value.length;
        if(length>16384){await reader.cancel();throw new ProtocolError('invalid_protocol',response.status);}chunks.push(part.value);}}
      finally{reader.releaseLock();}
      const all=new Uint8Array(length);let offset=0;for(const chunk of chunks){all.set(chunk,offset);offset+=chunk.length;}
      let result:unknown;try{result=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(all));}catch{throw new ProtocolError('invalid_protocol',response.status);}
      if(!response.ok){
        const known=new Set(['invalid_request','invalid_grant','invalid_session','rate_limited','service_unavailable','delivery_unavailable','unavailable_club','request_conflict','reauthentication_required','invalid_origin','method_not_allowed','body_too_large','unsupported_media_type','cookie_auth_not_supported']);
        throw new ProtocolError(obj(result)&&typeof result.error==='string'&&known.has(result.error)?result.error:'request_failed',response.status);
      }
      check(obj(result)&&result.schemaVersion===1&&result.clubId===this.clubId);return result;
    }catch(error){
      if(error instanceof ProtocolError)throw error;
      if(input!==undefined)throw new OutcomeUnknown();
      throw new ProtocolError('network_unavailable',0);
    }finally{clearTimeout(timer);}
  }
  private tokens(value:unknown):Tokens {
    check(obj(value)&&value.schemaVersion===1&&value.clubId===this.clubId&&value.tokenType==='Bearer'&&value.scope==='supporter:self'&&uuid(value.userId)&&uuid(value.sessionId));
    check(typeof value.accessToken==='string'&&/^aca_[A-Za-z0-9_-]{43}$/.test(value.accessToken));
    check(typeof value.refreshToken==='string'&&/^acr_[A-Za-z0-9_-]{43}$/.test(value.refreshToken));
    check(Number.isSafeInteger(value.accessExpiresAt)&&Number.isSafeInteger(value.sessionExpiresAt)&&(value.accessExpiresAt as number)<=(value.sessionExpiresAt as number));
    return value as unknown as Tokens;
  }
  async requestOtp(input:{phone:string;verifierHash:string;requestId:string}):Promise<Challenge> {
    check(/^\+[1-9][0-9]{7,14}$/.test(input.phone)&&/^[0-9a-f]{64}$/.test(input.verifierHash)&&uuid(input.requestId));
    const r=await this.call('otp/request',input);check(obj(r)&&uuid(r.challengeId)&&Number.isSafeInteger(r.expiresAt)&&['pending','sent','delivery_unknown','superseded','consumed','expired'].includes(String(r.state)));
    return r as unknown as Challenge;
  }
  async verifyOtp(input:{challengeId:string;code:string;verifier:string;requestId:string}):Promise<Tokens> {
    check(uuid(input.challengeId)&&/^\d{6}$/.test(input.code)&&/^[A-Za-z0-9_-]{43}$/.test(input.verifier)&&uuid(input.requestId));
    return this.tokens(await this.call('otp/verify',input));
  }
  async refresh(input:{refreshToken:string;requestId:string},expected:{userId:string;sessionId:string}):Promise<Tokens> {
    check(/^acr_[A-Za-z0-9_-]{43}$/.test(input.refreshToken)&&uuid(input.requestId)&&uuid(expected.userId)&&uuid(expected.sessionId));
    const r=this.tokens(await this.call('sessions/refresh',input));check(r.userId===expected.userId&&r.sessionId===expected.sessionId);return r;
  }
  async current(accessToken:string):Promise<Identity> {
    check(/^aca_[A-Za-z0-9_-]{43}$/.test(accessToken));const r=await this.call('sessions/current',undefined,accessToken);
    check(obj(r)&&uuid(r.userId)&&uuid(r.sessionId)&&typeof r.clubSlug==='string'&&r.phoneVerified===true&&r.scope==='supporter:self'&&Number.isSafeInteger(r.authenticatedAt));return r as unknown as Identity;
  }
  async logout(accessToken:string,scope:'current'|'others'|'all'):Promise<void> {
    check(/^aca_[A-Za-z0-9_-]{43}$/.test(accessToken)&&['current','others','all'].includes(scope));
    const r=await this.call('sessions/logout',{scope},accessToken);check(obj(r)&&r.revoked===true&&r.scope===scope);
  }
}
