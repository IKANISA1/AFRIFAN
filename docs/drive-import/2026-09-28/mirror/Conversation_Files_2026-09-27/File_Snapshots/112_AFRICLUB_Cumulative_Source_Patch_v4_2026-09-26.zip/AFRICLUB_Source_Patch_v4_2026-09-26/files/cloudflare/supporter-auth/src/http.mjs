import { AuthError, requireThat, isClub } from './policy.mjs';
import { SupporterAuth } from './service.mjs';
const routes=new Map([
  ['otp/request','POST'],['otp/verify','POST'],['sessions/refresh','POST'],
  ['sessions/current','GET'],['sessions/logout','POST'],
]);
function json(body,status=200) { return new Response(JSON.stringify(body),{status,headers:{
  'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',
  'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',
  'Content-Security-Policy':"default-src 'none'; frame-ancestors 'none'",
  ...(status===429?{'Retry-After':'60'}:{}),
}}); }
async function body(request) {
  requireThat(/^application\/json(?:\s*;\s*charset=utf-8)?$/i.test(request.headers.get('content-type')||''),'unsupported_media_type',415);
  requireThat(!request.headers.has('content-encoding'),'unsupported_media_type',415);
  const declared=request.headers.get('content-length');
  requireThat(declared===null||(/^\d+$/.test(declared)&&Number(declared)<=4096),'body_too_large',413);
  const reader=request.body?.getReader();requireThat(reader);
  let size=0;const parts=[];
  try { for(;;) { const r=await reader.read();if(r.done)break;size+=r.value.length;
    if(size>4096) { await reader.cancel();throw new AuthError('body_too_large',413); } parts.push(r.value); }
  } finally {reader.releaseLock();}
  const bytes=new Uint8Array(size);let at=0;for(const part of parts) {bytes.set(part,at);at+=part.length;}
  try {return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));} catch {throw new AuthError('invalid_request',400);}
}
function bearer(request) {
  const match=/^Bearer (aca_[A-Za-z0-9_-]{43})$/.exec(request.headers.get('authorization')||'');
  requireThat(match,'invalid_session',401);return match[1];
}
// The factory is a test seam, not a request-controlled bypass. Worker uses its default.
export function handler(serviceFactory=env=>new SupporterAuth(env)) {
  return async function fetch(request,env) {
    try {
      const url=new URL(request.url),match=/^\/v1\/auth\/clubs\/([1-9]\d*)\/(otp\/(?:request|verify)|sessions\/(?:refresh|current|logout))$/.exec(url.pathname);
      if(!match||!routes.has(match[2]))return json({error:'not_found'},404);
      requireThat(request.method===routes.get(match[2]),'method_not_allowed',405);
      requireThat(url.protocol==='https:'&&url.origin===env.AUTH_ORIGIN&&!url.username&&!url.password&&!url.search,'invalid_origin',403);
      const origin=request.headers.get('origin');requireThat(origin===null||origin===env.AUTH_ORIGIN,'invalid_origin',403);
      // Native bearer protocol only. Do not put these tokens in browser cookies/localStorage.
      requireThat(!request.headers.has('cookie'),'cookie_auth_not_supported',400);
      requireThat(request.method==='GET'||request.headers.get('x-africlub-auth')==='native-v1','invalid_request',400);
      const club=Number(match[1]);requireThat(isClub(club));
      const service=serviceFactory(env);
      const network=await service.networkLimit(request.headers.get('cf-connecting-ip'));
      let result;
      if(match[2]==='sessions/current') result=await service.current(club,bearer(request));
      else {
        const input=await body(request);
        if(match[2]==='otp/request') result=await service.requestOtp(club,input,network);
        if(match[2]==='otp/verify') result=await service.verifyOtp(club,input);
        if(match[2]==='sessions/refresh') result=await service.refresh(club,input);
        if(match[2]==='sessions/logout') result=await service.logout(club,bearer(request),input);
      }
      return json(result,match[2]==='otp/request'?202:200);
    } catch(error) {
      // Never return database errors, provider messages, codes, phones or bearer tokens.
      return json({error:error instanceof AuthError?error.code:'service_unavailable'},error instanceof AuthError?error.status:503);
    }
  };
}
export default {fetch:handler()};
