import { POLICY as P, AuthError, requireThat, fields, isUuid, isHash, isSecret, isClub, phone, token, config } from './policy.mjs';
import { sha, mac, seal, unseal, secret, code, validKey, equal } from './crypto.mjs';

// Authentication only. No membership, points, financial, staff or payment grant.
const ACTIVE_JOIN=`FROM auth_sessions s JOIN auth_identities i ON i.user_id=s.user_id
 JOIN auth_tenants t ON t.club_id=s.club_id
 JOIN auth_identity_clubs g ON g.user_id=s.user_id AND g.club_id=s.club_id`;
const ACTIVE=`s.revoked_at IS NULL AND i.status='active' AND t.enabled=1 AND g.enabled=1
 AND s.identity_version=i.security_version AND s.tenant_revision=t.revision AND s.grant_revision=g.revision`;
const IDENTITY_JOIN=`FROM auth_identities i JOIN auth_identity_clubs g ON g.user_id=i.user_id
 JOIN auth_tenants t ON t.club_id=g.club_id`;
const IDENTITY_ACTIVE=`i.status='active' AND g.enabled=1 AND t.enabled=1`;

export class SupporterAuth {
  constructor(env,{clock=()=>Date.now()}={}) {
    config(env);
    requireThat(['PHONE_HMAC_KEY','OTP_HMAC_KEY','RESPONSE_ENCRYPTION_KEY'].every(k=>validKey(env[k])),'service_unavailable',503);
    requireThat(new Set([env.PHONE_HMAC_KEY,env.OTP_HMAC_KEY,env.RESPONSE_ENCRYPTION_KEY]).size===3,'service_unavailable',503);
    this.env=env; this.db=env.AUTH_DB; this.clock=clock;
  }
  stmt(sql,...args) { return this.db.prepare(sql).bind(...args); }
  first(sql,...args) { return this.db.withSession('first-primary').prepare(sql).bind(...args).first(); }
  all(sql,...args) { return this.db.withSession('first-primary').prepare(sql).bind(...args).all(); }
  async write(sql,...args) { return this.stmt(sql,...args).run(); }
  guard(id,sql,args=[]) { return this.stmt(`INSERT INTO auth_atomic_guards VALUES (?, CASE WHEN (${sql}) THEN 1 ELSE 0 END)`,id,...args); }
  clearGuard(id) { return this.stmt('DELETE FROM auth_atomic_guards WHERE guard_id=?',id); }
  audit(type,s,now=this.clock()) { return this.stmt('INSERT INTO auth_audit_events VALUES (?,?,?,?,?,?)',crypto.randomUUID(),type,s.user_id,s.club_id,s.session_id,now); }
  async tenant(clubId) {
    requireThat(isClub(clubId));
    const t=await this.first('SELECT * FROM auth_tenants WHERE club_id=? AND enabled=1',clubId);
    requireThat(t,'unavailable_club',404); return t;
  }
  async hit(key,windowMs,limit) {
    const start=Math.floor(this.clock()/windowMs)*windowMs;
    const r=await this.first(`INSERT INTO auth_rate_windows VALUES (?,?,1)
      ON CONFLICT(bucket_key,window_start) DO UPDATE SET hits=MIN(hits+1,1000000) RETURNING hits`,key,start);
    requireThat(r&&r.hits<=limit,'rate_limited',429);
  }
  async networkLimit(ip) {
    requireThat(typeof ip==='string'&&ip.length>0&&ip.length<=64,'service_unavailable',503);
    // Deployment requires direct Cloudflare ingress; public client headers are not an IP authority.
    const hash=await mac(this.env.PHONE_HMAC_KEY,`network:${ip}`);
    await this.hit(`ip:${hash}`,60_000,P.requestsPerIpMinute); return hash;
  }
  async requestOtp(clubId,input,ipHash) {
    fields(input,['phone','verifierHash','requestId']); phone(input.phone);
    requireThat(isHash(input.verifierHash)&&isUuid(input.requestId)&&isHash(ipHash));
    requireThat(this.env.OTP_DELIVERY&&typeof this.env.OTP_DELIVERY.deliver==='function','delivery_unavailable',503);
    const t=await this.tenant(clubId), now=this.clock();
    const phoneHash=await mac(this.env.PHONE_HMAC_KEY,`phone:${input.phone}`);
    const requestHash=await sha(JSON.stringify([clubId,phoneHash,input.verifierHash,input.requestId]));
    const existing=await this.first('SELECT * FROM auth_challenges WHERE club_id=? AND request_id=?',clubId,input.requestId);
    if(existing) return this.requestResult(existing,requestHash);
    await this.hit(`send:phone:${phoneHash}`,3_600_000,P.phoneSendsPerHour);
    await this.hit(`send:ip:${ipHash}`,600_000,P.ipSendsPerTenMinutes);
    await this.hit('send:global',3_600_000,P.globalSendsPerHour);
    const id=crypto.randomUUID(), otp=code(), expires=now+P.codeMs, guardId=crypto.randomUUID(), controlGuard=crypto.randomUUID();
    const digest=await mac(this.env.OTP_HMAC_KEY,JSON.stringify([id,clubId,phoneHash,otp]));
    try {
      await this.db.batch([
        this.guard(guardId,'EXISTS(SELECT 1 FROM auth_tenants WHERE club_id=? AND enabled=1 AND revision=?)',[clubId,t.revision]),
        this.stmt('INSERT INTO auth_phone_controls(phone_hash) VALUES (?) ON CONFLICT DO NOTHING',phoneHash),
        this.stmt(`UPDATE auth_phone_controls SET next_send_at=?,
          failed_attempts=CASE WHEN locked_until>0 AND locked_until<=? THEN 0 ELSE failed_attempts END,
          locked_until=CASE WHEN locked_until<=? THEN 0 ELSE locked_until END
          WHERE phone_hash=? AND next_send_at<=? AND locked_until<=?`,now+P.sendCooldownMs,now,now,phoneHash,now,now),
        this.guard(controlGuard,'changes()=1'),
        this.stmt(`UPDATE auth_challenges SET state='superseded' WHERE phone_hash=? AND state IN ('pending','sent','delivery_unknown')`,phoneHash),
        this.stmt(`INSERT INTO auth_challenges(challenge_id,request_id,request_hash,club_id,tenant_revision,
          phone_hash,verifier_hash,code_hash,state,created_at,expires_at) VALUES (?,?,?,?,?,?,?,?,'pending',?,?)`,
          id,input.requestId,requestHash,clubId,t.revision,phoneHash,input.verifierHash,digest,now,expires),
        this.clearGuard(controlGuard),this.clearGuard(guardId),
      ]);
    } catch(error) {
      const winner=await this.first('SELECT * FROM auth_challenges WHERE club_id=? AND request_id=?',clubId,input.requestId);
      if(winner) return this.requestResult(winner,requestHash);
      if(/CHECK constraint failed|UNIQUE constraint failed/.test(String(error))) throw new AuthError('rate_limited',429);
      throw error;
    }
    // Codes and destination exist only in memory and the trusted delivery binding.
    // No automatic delivery retries: an interrupted send stays unknown, never successful by assumption.
    let timer;
    try {
      const result=await Promise.race([
        this.env.OTP_DELIVERY.deliver({challengeId:id,clubId,phone:input.phone,code:otp,expiresAt:expires,channel:'whatsapp'}),
        new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('delivery timeout')),P.providerTimeoutMs);}),
      ]);
      requireThat(result?.accepted===true&&result?.challengeId===id,'delivery_unavailable',503);
      const confirmedAt=this.clock();
      const changed=await this.write(`UPDATE auth_challenges SET state='sent' WHERE challenge_id=? AND state='pending' AND expires_at>?
        AND EXISTS(SELECT 1 FROM auth_tenants WHERE club_id=? AND enabled=1 AND revision=?)`,id,confirmedAt,clubId,t.revision);
      requireThat(changed.meta.changes===1,'delivery_unavailable',503);
    } catch {
      await this.write("UPDATE auth_challenges SET state='delivery_unknown' WHERE challenge_id=? AND state='pending'",id);
    } finally { clearTimeout(timer); }
    return this.requestResult(await this.first('SELECT * FROM auth_challenges WHERE challenge_id=?',id),requestHash);
  }
  requestResult(row,requestHash) {
    requireThat(row&&equal(row.request_hash,requestHash),'request_conflict',409);
    return {schemaVersion:1,challengeId:row.challenge_id,clubId:row.club_id,
      state:row.expires_at<=this.clock()?'expired':row.state,expiresAt:row.expires_at};
  }
  async sessionRow(id,clubId,{access=false,generation=null}={}) {
    const now=this.clock();
    const s=await this.first(`SELECT s.*,t.club_slug ${ACTIVE_JOIN} WHERE s.session_id=? AND s.club_id=? AND ${ACTIVE}
      AND s.absolute_expires_at>? ${access?'AND s.access_expires_at>?':''} ${generation===null?'':'AND s.generation=?'}`,
      id,clubId,now,...(access?[now]:[]),...(generation===null?[]:[generation]));
    requireThat(s,'invalid_session',401); return s;
  }
  async bundle(userId,clubId,sessionId,absolute,now) {
    const accessToken=`aca_${secret()}`,refreshToken=`acr_${secret()}`;
    return {schemaVersion:1,tokenType:'Bearer',userId,clubId,sessionId,accessToken,refreshToken,
      accessExpiresAt:Math.min(now+P.accessMs,absolute),sessionExpiresAt:absolute,scope:'supporter:self'};
  }
  async recoverLogin(row,requestHash) {
    requireThat(row.verify_request_hash===requestHash&&row.recovery_until>this.clock()&&row.response_ciphertext,'invalid_grant',401);
    await this.sessionRow(row.session_id,row.club_id,{generation:0});
    return unseal(this.env.RESPONSE_ENCRYPTION_KEY,`login:${row.challenge_id}:${requestHash}`,row.response_ciphertext);
  }
  async verifyOtp(clubId,input) {
    fields(input,['challengeId','code','verifier','requestId']);
    requireThat(isUuid(input.challengeId)&&typeof input.code==='string'&&/^\d{6}$/.test(input.code)&&isSecret(input.verifier)&&isUuid(input.requestId));
    const t=await this.tenant(clubId);
    const row=await this.first('SELECT * FROM auth_challenges WHERE challenge_id=? AND club_id=?',input.challengeId,clubId);
    requireThat(row&&equal(row.verifier_hash,await sha(input.verifier)),'invalid_grant',401);
    const codeHash=await mac(this.env.OTP_HMAC_KEY,JSON.stringify([row.challenge_id,clubId,row.phone_hash,input.code]));
    const requestHash=await sha(input.requestId);
    if(row.state==='consumed') {
      requireThat(equal(row.code_hash,codeHash),'invalid_grant',401);
      return this.recoverLogin(row,requestHash);
    }
    const now=this.clock();
    requireThat(row.state==='sent'&&row.expires_at>now&&row.attempts<P.attemptsPerChallenge&&row.tenant_revision===t.revision,'invalid_grant',401);
    const controls=await this.first('SELECT * FROM auth_phone_controls WHERE phone_hash=?',row.phone_hash);
    requireThat(controls&&controls.locked_until<=now,'rate_limited',429);
    if(!equal(codeHash,row.code_hash)) {
      const guardId=crypto.randomUUID();
      try {
        await this.db.batch([
          this.stmt(`UPDATE auth_challenges SET attempts=attempts+1 WHERE challenge_id=? AND state='sent' AND attempts<? AND expires_at>?`,row.challenge_id,P.attemptsPerChallenge,now),
          this.guard(guardId,'changes()=1'),
          this.stmt(`UPDATE auth_phone_controls SET failed_attempts=failed_attempts+1,
            locked_until=CASE WHEN failed_attempts+1>=? THEN ? ELSE locked_until END WHERE phone_hash=?`,P.failedPhoneAttempts,now+P.phoneLockMs,row.phone_hash),
          this.clearGuard(guardId),
        ]);
      } catch(error) { if(!/CHECK constraint failed/.test(String(error))) throw error; }
      throw new AuthError('invalid_grant',401);
    }
    // Source UUID and club mapping are imported/reviewed independently; phone proof never creates or merges identities.
    const identity=await this.first(`SELECT i.user_id,i.security_version,g.revision grant_revision ${IDENTITY_JOIN}
      WHERE i.phone_hash=? AND t.club_id=? AND ${IDENTITY_ACTIVE}`,row.phone_hash,clubId);
    requireThat(identity,'invalid_grant',401);
    const sessionId=crypto.randomUUID(), current=this.clock(), absolute=current+P.sessionMs;
    const result=await this.bundle(identity.user_id,clubId,sessionId,absolute,current);
    const [accessHash,refreshHash,cipher]=await Promise.all([sha(result.accessToken),sha(result.refreshToken),
      seal(this.env.RESPONSE_ENCRYPTION_KEY,`login:${row.challenge_id}:${requestHash}`,result)]);
    const guardId=crypto.randomUUID(), authGuard=crypto.randomUUID();
    try {
      await this.db.batch([
        this.guard(authGuard,`EXISTS(SELECT 1 ${IDENTITY_JOIN} WHERE i.user_id=? AND i.phone_hash=? AND t.club_id=?
          AND ${IDENTITY_ACTIVE} AND i.security_version=? AND t.revision=? AND g.revision=?)`,
          [identity.user_id,row.phone_hash,clubId,identity.security_version,t.revision,identity.grant_revision]),
        this.stmt(`UPDATE auth_challenges SET state='consumed',verify_request_hash=?,session_id=?,response_ciphertext=?,recovery_until=?
          WHERE challenge_id=? AND state='sent' AND expires_at>? AND attempts<? AND tenant_revision=?
          AND EXISTS(SELECT 1 FROM auth_phone_controls WHERE phone_hash=? AND locked_until<=?)`,
          requestHash,sessionId,cipher,current+P.recoveryMs,row.challenge_id,this.clock(),P.attemptsPerChallenge,t.revision,row.phone_hash,this.clock()),
        this.guard(guardId,'changes()=1'),
        this.stmt(`INSERT INTO auth_sessions(session_id,user_id,club_id,identity_version,tenant_revision,grant_revision,
          access_hash,access_expires_at,absolute_expires_at,authenticated_at) VALUES (?,?,?,?,?,?,?,?,?,?)`,
          sessionId,identity.user_id,clubId,identity.security_version,t.revision,identity.grant_revision,accessHash,result.accessExpiresAt,absolute,current),
        this.stmt(`INSERT INTO auth_refresh_tokens(token_hash,session_id,generation,expires_at) VALUES (?,?,0,?)`,refreshHash,sessionId,absolute),
        this.stmt('UPDATE auth_phone_controls SET failed_attempts=0,locked_until=0 WHERE phone_hash=?',row.phone_hash),
        this.audit('signed_in',{user_id:identity.user_id,club_id:clubId,session_id:sessionId},current),
        this.clearGuard(guardId),this.clearGuard(authGuard),
      ]);
      return result;
    } catch(error) {
      const winner=await this.first('SELECT * FROM auth_challenges WHERE challenge_id=? AND club_id=?',row.challenge_id,clubId);
      if(winner?.state==='consumed') return this.recoverLogin(winner,requestHash);
      if(/CHECK constraint failed/.test(String(error))) throw new AuthError('invalid_grant',401);
      throw error;
    }
  }
  async current(clubId,accessToken) {
    requireThat(isClub(clubId)); token(accessToken,'aca_');
    const digest=await sha(accessToken),now=this.clock();
    const s=await this.first(`SELECT s.*,t.club_slug ${ACTIVE_JOIN} WHERE s.club_id=? AND s.access_hash=? AND ${ACTIVE}
      AND s.access_expires_at>? AND s.absolute_expires_at>?`,clubId,digest,now,now);
    requireThat(s,'invalid_session',401);
    return {schemaVersion:1,userId:s.user_id,clubId:s.club_id,clubSlug:s.club_slug,sessionId:s.session_id,
      phoneVerified:true,authenticatedAt:s.authenticated_at,scope:'supporter:self'};
  }
  async recoverRefresh(row,requestHash,clubId) {
    const s=await this.sessionRow(row.session_id,clubId);
    if(row.request_hash!==requestHash) {
      await this.db.batch([
        this.stmt("UPDATE auth_sessions SET revoked_at=?,revoke_reason='refresh_reuse' WHERE session_id=? AND revoked_at IS NULL",this.clock(),s.session_id),
        this.stmt(`INSERT INTO auth_audit_events SELECT ?, 'refresh_reuse',user_id,club_id,session_id,? FROM auth_sessions WHERE session_id=? AND changes()=1`,crypto.randomUUID(),this.clock(),s.session_id),
      ]);
      throw new AuthError('invalid_session',401);
    }
    requireThat(row.recovery_until>this.clock()&&row.response_ciphertext&&s.generation===row.generation+1,'reauthentication_required',401);
    return unseal(this.env.RESPONSE_ENCRYPTION_KEY,`refresh:${row.token_hash}:${requestHash}`,row.response_ciphertext);
  }
  async refresh(clubId,input) {
    fields(input,['refreshToken','requestId']); requireThat(isClub(clubId)&&isUuid(input.requestId));token(input.refreshToken,'acr_');
    const tokenHash=await sha(input.refreshToken),requestHash=await sha(input.requestId);
    const row=await this.first(`SELECT r.* FROM auth_refresh_tokens r JOIN auth_sessions s ON s.session_id=r.session_id WHERE r.token_hash=? AND s.club_id=?`,tokenHash,clubId);
    requireThat(row&&row.expires_at>this.clock(),'invalid_session',401);
    if(row.consumed_at!==null) return this.recoverRefresh(row,requestHash,clubId);
    const s=await this.sessionRow(row.session_id,clubId,{generation:row.generation});
    await this.hit(`session:${s.session_id}`,60_000,P.sessionActionsPerMinute);
    const now=this.clock(),result=await this.bundle(s.user_id,clubId,s.session_id,s.absolute_expires_at,now);
    const [accessHash,refreshHash,cipher]=await Promise.all([sha(result.accessToken),sha(result.refreshToken),
      seal(this.env.RESPONSE_ENCRYPTION_KEY,`refresh:${tokenHash}:${requestHash}`,result)]);
    const guardId=crypto.randomUUID(),checkId=crypto.randomUUID();
    try {
      await this.db.batch([
        this.guard(guardId,`EXISTS(SELECT 1 ${ACTIVE_JOIN} WHERE s.session_id=? AND s.club_id=? AND ${ACTIVE} AND s.absolute_expires_at>? AND s.generation=?)`,[s.session_id,clubId,this.clock(),row.generation]),
        this.stmt(`UPDATE auth_refresh_tokens SET consumed_at=?,request_hash=?,response_ciphertext=?,recovery_until=? WHERE token_hash=? AND consumed_at IS NULL AND expires_at>?`,now,requestHash,cipher,now+P.recoveryMs,tokenHash,this.clock()),
        this.guard(checkId,'changes()=1'),
        this.stmt(`UPDATE auth_sessions SET generation=generation+1,access_hash=?,access_expires_at=? WHERE session_id=?`,accessHash,result.accessExpiresAt,s.session_id),
        this.stmt(`INSERT INTO auth_refresh_tokens(token_hash,session_id,generation,expires_at) VALUES (?,?,?,?)`,refreshHash,s.session_id,row.generation+1,s.absolute_expires_at),
        this.audit('refreshed',s,now),this.clearGuard(checkId),this.clearGuard(guardId),
      ]);
      return result;
    } catch(error) {
      const winner=await this.first('SELECT * FROM auth_refresh_tokens WHERE token_hash=?',tokenHash);
      if(winner && winner.consumed_at!==null) return this.recoverRefresh(winner,requestHash,clubId);
      if(/CHECK constraint failed/.test(String(error))) throw new AuthError('invalid_session',401);
      throw error;
    }
  }
  async logout(clubId,accessToken,input) {
    fields(input,['scope']);requireThat(['current','others','all'].includes(input.scope));
    const context=await this.current(clubId,accessToken),now=this.clock(),id=crypto.randomUUID();
    const target=input.scope==='current'?'AND session_id=?':input.scope==='others'?'AND session_id<>?':'';
    const s={user_id:context.userId,club_id:clubId,session_id:context.sessionId};
    await this.db.batch([
      this.guard(id,`EXISTS(SELECT 1 ${ACTIVE_JOIN} WHERE s.session_id=? AND s.access_hash=? AND ${ACTIVE} AND s.access_expires_at>? AND s.absolute_expires_at>?)`,[context.sessionId,await sha(accessToken),this.clock(),this.clock()]),
      this.stmt(`UPDATE auth_sessions SET revoked_at=?,revoke_reason='sign_out' WHERE user_id=? AND club_id=? AND revoked_at IS NULL ${target}`,now,context.userId,clubId,...(target?[context.sessionId]:[])),
      this.audit(input.scope==='current'?'signed_out':input.scope==='others'?'other_sessions_revoked':'all_sessions_revoked',s,now),
      this.clearGuard(id),
    ]);
    return {schemaVersion:1,revoked:true,scope:input.scope,clubId};
  }
  async scrubRecoverySecrets() {
    // Bounded privacy maintenance, not account erasure or historic audit deletion.
    const now=this.clock();
    await this.db.batch([
      this.stmt(`UPDATE auth_challenges SET response_ciphertext=NULL WHERE challenge_id IN
        (SELECT challenge_id FROM auth_challenges WHERE response_ciphertext IS NOT NULL AND recovery_until<=? LIMIT 500)`,now),
      this.stmt(`UPDATE auth_refresh_tokens SET response_ciphertext=NULL WHERE token_hash IN
        (SELECT token_hash FROM auth_refresh_tokens WHERE response_ciphertext IS NOT NULL AND recovery_until<=? LIMIT 500)`,now),
      this.stmt(`DELETE FROM auth_rate_windows WHERE rowid IN (SELECT rowid FROM auth_rate_windows WHERE window_start<? LIMIT 500)`,now-2*3_600_000),
    ]);
    return {scrubbed:true,limitPerTable:500};
  }
}
