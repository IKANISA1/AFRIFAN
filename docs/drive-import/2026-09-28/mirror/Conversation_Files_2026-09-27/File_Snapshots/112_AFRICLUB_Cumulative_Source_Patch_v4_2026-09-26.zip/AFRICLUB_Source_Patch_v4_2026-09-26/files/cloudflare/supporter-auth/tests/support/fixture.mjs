import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { SupporterAuth } from '../../src/service.mjs';
import { base64url,mac,secret,sha } from '../../src/crypto.mjs';
// Synthetic identities/keys. No account credential or provider request occurs.
export const USER='10000000-0000-4000-8000-000000000001';
export const PHONE='+250700000001';
export class Database {
  constructor(path=':memory:') {
    this.sql=new DatabaseSync(path);this.sql.exec('PRAGMA foreign_keys=ON');
    this.sql.exec(readFileSync(new URL('../../migrations/0001_supporter_identity.sql',import.meta.url),'utf8'));
    this.failAt=null;this.beforeBatch=null;this.loseAfterCommit=false;this.constraints=[];this.batchSizes=[];
  }
  withSession(c) {this.constraints.push(c);return this;}
  prepare(sql) {
    const db=this;return {sql,args:[],bind(...args){return {...this,args};},
      async first(){return db.sql.prepare(sql).get(...this.args)??null;},
      async all(){return {results:db.sql.prepare(sql).all(...this.args)};},
      async run(){const r=db.sql.prepare(sql).run(...this.args);return {success:true,meta:{changes:Number(r.changes)}};},
    };
  }
  async batch(statements) {
    if(this.beforeBatch) {const h=this.beforeBatch;this.beforeBatch=null;await h(this);}
    this.batchSizes.push(statements.length);this.sql.exec('BEGIN IMMEDIATE');
    try {
      const results=[];
      for(let i=0;i<statements.length;i++) {
        if(i===this.failAt)throw new Error('injected SQL failure');
        const s=statements[i],r=this.sql.prepare(s.sql).run(...s.args);results.push({success:true,meta:{changes:Number(r.changes)}});
      }
      this.sql.exec('COMMIT');
      if(this.loseAfterCommit) {this.loseAfterCommit=false;throw new Error('simulated lost response');}
      return results;
    }catch(e){if(this.sql.isTransaction)this.sql.exec('ROLLBACK');throw e;}
  }
  close(){this.sql.close();}
}
export async function fixture({active=true}={}) {
  const db=new Database();let now=Date.UTC(2026,8,26,12,0,0);
  const delivered=[],env={AUTH_ENABLED:'true',AUTH_KEY_ID:'v1',AUTH_ORIGIN:'https://auth.example.invalid',
    PHONE_HMAC_KEY:base64url(new Uint8Array(32).fill(1)),OTP_HMAC_KEY:base64url(new Uint8Array(32).fill(2)),
    RESPONSE_ENCRYPTION_KEY:base64url(new Uint8Array(32).fill(3)),AUTH_DB:db,
    OTP_DELIVERY:{async deliver(input){delivered.push(input);return {accepted:true,challengeId:input.challengeId};}},
  };
  db.sql.prepare('INSERT INTO auth_tenants(club_id,club_slug,enabled) VALUES (24,?,1),(44,?,1)').run('rayon_sports_rw','vitalo_test');
  const hash=await mac(env.PHONE_HMAC_KEY,`phone:${PHONE}`);
  db.sql.prepare('INSERT INTO auth_identities(user_id,phone_hash,status,created_at) VALUES (?,?,?,?)').run(USER,hash,active?'active':'suspended',now);
  db.sql.prepare('INSERT INTO auth_identity_clubs(user_id,club_id,enabled) VALUES (?,24,1),(?,44,1)').run(USER,USER);
  const service=new SupporterAuth(env,{clock:()=>now}),ipHash='a'.repeat(64);
  async function request(clubId=24,number=PHONE){
    const verifier=secret(),requestId=crypto.randomUUID();
    const input={phone:number,verifierHash:await sha(verifier),requestId};
    const response=await service.requestOtp(clubId,input,ipHash);
    const item=delivered.find(x=>x.challengeId===response.challengeId);
    return {response,input,verify:{challengeId:response.challengeId,code:item?.code??'000000',verifier,requestId:crypto.randomUUID()}};
  }
  async function login(clubId=24){const c=await request(clubId);return {...c,tokens:await service.verifyOtp(clubId,c.verify)};}
  return {db,env,service,delivered,ipHash,request,login,now:()=>now,advance(ms){now+=ms;},close:()=>db.close()};
}
