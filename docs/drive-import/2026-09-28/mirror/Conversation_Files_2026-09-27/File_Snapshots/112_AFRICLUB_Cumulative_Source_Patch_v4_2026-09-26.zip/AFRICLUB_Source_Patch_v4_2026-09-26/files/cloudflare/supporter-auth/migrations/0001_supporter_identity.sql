-- Separate supporter identity database. No production identities or grants seeded.
-- Do not execute against the Rayon public-content or financial databases.
PRAGMA foreign_keys = ON;
CREATE TABLE auth_tenants (
  club_id INTEGER PRIMARY KEY CHECK(club_id > 0),
  club_slug TEXT NOT NULL UNIQUE,
  enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN (0,1)),
  revision INTEGER NOT NULL DEFAULT 1 CHECK(revision > 0)
);
CREATE TABLE auth_identities (
  user_id TEXT PRIMARY KEY CHECK(length(user_id)=36),
  phone_hash TEXT NOT NULL UNIQUE CHECK(length(phone_hash)=64),
  status TEXT NOT NULL DEFAULT 'suspended' CHECK(status IN ('active','suspended','deletion_pending','closed')),
  security_version INTEGER NOT NULL DEFAULT 1 CHECK(security_version > 0),
  created_at INTEGER NOT NULL
);
CREATE TABLE auth_identity_clubs (
  user_id TEXT NOT NULL REFERENCES auth_identities(user_id),
  club_id INTEGER NOT NULL REFERENCES auth_tenants(club_id),
  enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN (0,1)),
  revision INTEGER NOT NULL DEFAULT 1 CHECK(revision > 0),
  PRIMARY KEY(user_id, club_id)
);
CREATE TABLE auth_source_identities (
  source_project TEXT NOT NULL,
  source_user_id TEXT NOT NULL,
  user_id TEXT NOT NULL REFERENCES auth_identities(user_id),
  source_sha256 TEXT NOT NULL CHECK(length(source_sha256)=64),
  PRIMARY KEY(source_project,source_user_id),
  UNIQUE(user_id), CHECK(source_user_id=user_id)
);
CREATE TABLE auth_rate_windows (
  bucket_key TEXT NOT NULL,
  window_start INTEGER NOT NULL,
  hits INTEGER NOT NULL CHECK(hits > 0),
  PRIMARY KEY(bucket_key,window_start)
);
CREATE INDEX auth_rate_windows_expiry ON auth_rate_windows(window_start);
CREATE TABLE auth_phone_controls (
  phone_hash TEXT PRIMARY KEY,
  next_send_at INTEGER NOT NULL DEFAULT 0,
  failed_attempts INTEGER NOT NULL DEFAULT 0 CHECK(failed_attempts >= 0),
  locked_until INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE auth_challenges (
  challenge_id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  club_id INTEGER NOT NULL REFERENCES auth_tenants(club_id),
  tenant_revision INTEGER NOT NULL,
  phone_hash TEXT NOT NULL,
  verifier_hash TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('pending','sent','delivery_unknown','superseded','consumed')),
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts>=0),
  verify_request_hash TEXT,
  session_id TEXT,
  response_ciphertext TEXT,
  recovery_until INTEGER,
  UNIQUE(club_id, request_id)
);
CREATE INDEX auth_challenges_phone ON auth_challenges(phone_hash,state);
CREATE INDEX auth_challenges_expiry ON auth_challenges(expires_at);
CREATE INDEX auth_challenges_recovery ON auth_challenges(recovery_until) WHERE response_ciphertext IS NOT NULL;
CREATE TABLE auth_sessions (
  session_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES auth_identities(user_id),
  club_id INTEGER NOT NULL REFERENCES auth_tenants(club_id),
  identity_version INTEGER NOT NULL,
  tenant_revision INTEGER NOT NULL,
  grant_revision INTEGER NOT NULL,
  generation INTEGER NOT NULL DEFAULT 0 CHECK(generation>=0),
  access_hash TEXT NOT NULL UNIQUE,
  access_expires_at INTEGER NOT NULL,
  absolute_expires_at INTEGER NOT NULL,
  authenticated_at INTEGER NOT NULL,
  revoked_at INTEGER,
  revoke_reason TEXT
);
CREATE INDEX auth_sessions_user ON auth_sessions(user_id,club_id,revoked_at);
CREATE TABLE auth_refresh_tokens (
  token_hash TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES auth_sessions(session_id),
  generation INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  consumed_at INTEGER,
  request_hash TEXT,
  response_ciphertext TEXT,
  recovery_until INTEGER,
  UNIQUE(session_id,generation)
);
CREATE INDEX auth_refresh_recovery ON auth_refresh_tokens(recovery_until) WHERE response_ciphertext IS NOT NULL;
CREATE TABLE auth_audit_events (
  event_id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL CHECK(event_type IN ('signed_in','refreshed','signed_out','other_sessions_revoked','all_sessions_revoked','refresh_reuse')),
  user_id TEXT NOT NULL,
  club_id INTEGER NOT NULL,
  session_id TEXT NOT NULL,
  occurred_at INTEGER NOT NULL
);
CREATE INDEX auth_audit_user ON auth_audit_events(user_id,occurred_at);
-- Guards are inserted/deleted inside the same batch. A failed guard rolls it back.
CREATE TABLE auth_atomic_guards (guard_id TEXT PRIMARY KEY, ok INTEGER NOT NULL CHECK(ok=1));
CREATE TRIGGER auth_tenant_revision AFTER UPDATE OF enabled,club_slug ON auth_tenants BEGIN
  UPDATE auth_tenants SET revision=OLD.revision+1 WHERE club_id=NEW.club_id;
END;
CREATE TRIGGER auth_identity_revision AFTER UPDATE OF status,phone_hash ON auth_identities BEGIN
  UPDATE auth_identities SET security_version=OLD.security_version+1 WHERE user_id=NEW.user_id;
END;
CREATE TRIGGER auth_grant_revision AFTER UPDATE OF enabled ON auth_identity_clubs BEGIN
  UPDATE auth_identity_clubs SET revision=OLD.revision+1 WHERE user_id=NEW.user_id AND club_id=NEW.club_id;
END;
-- Monotonic versions prevent revoke-and-reenable from reviving old sessions.
CREATE TRIGGER auth_tenant_monotonic BEFORE UPDATE OF revision ON auth_tenants WHEN NEW.revision<=OLD.revision BEGIN SELECT RAISE(ABORT,'revision must increase'); END;
CREATE TRIGGER auth_identity_monotonic BEFORE UPDATE OF security_version ON auth_identities WHEN NEW.security_version<=OLD.security_version BEGIN SELECT RAISE(ABORT,'version must increase'); END;
CREATE TRIGGER auth_grant_monotonic BEFORE UPDATE OF revision ON auth_identity_clubs WHEN NEW.revision<=OLD.revision BEGIN SELECT RAISE(ABORT,'revision must increase'); END;
CREATE TRIGGER auth_identity_id_immutable BEFORE UPDATE OF user_id ON auth_identities BEGIN SELECT RAISE(ABORT,'identity immutable'); END;
CREATE TRIGGER auth_tenant_id_immutable BEFORE UPDATE OF club_id ON auth_tenants BEGIN SELECT RAISE(ABORT,'tenant immutable'); END;
CREATE TRIGGER auth_grant_keys_immutable BEFORE UPDATE OF user_id,club_id ON auth_identity_clubs BEGIN SELECT RAISE(ABORT,'grant keys immutable'); END;
CREATE TRIGGER auth_grant_no_delete BEFORE DELETE ON auth_identity_clubs BEGIN SELECT RAISE(ABORT,'disable grant instead'); END;
CREATE TRIGGER auth_source_no_update BEFORE UPDATE ON auth_source_identities BEGIN SELECT RAISE(ABORT,'source mapping immutable'); END;
CREATE TRIGGER auth_source_no_delete BEFORE DELETE ON auth_source_identities BEGIN SELECT RAISE(ABORT,'source mapping retained'); END;
CREATE TRIGGER auth_audit_no_update BEFORE UPDATE ON auth_audit_events BEGIN SELECT RAISE(ABORT,'audit immutable'); END;
CREATE TRIGGER auth_audit_no_delete BEFORE DELETE ON auth_audit_events BEGIN SELECT RAISE(ABORT,'audit retained'); END;
