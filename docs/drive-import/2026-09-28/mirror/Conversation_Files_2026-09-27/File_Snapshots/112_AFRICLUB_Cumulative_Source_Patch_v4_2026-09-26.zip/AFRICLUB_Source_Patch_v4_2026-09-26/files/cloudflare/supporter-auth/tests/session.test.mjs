import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture,USER,PHONE } from './support/fixture.mjs';
import { secret,sha } from '../src/crypto.mjs';
import { POLICY as P,ownedBy } from '../src/policy.mjs';
const fails=(promise,code)=>assert.rejects(promise,e=>e.code===code);
async function setup(t,options) {const f=await fixture(options);t.after(()=>f.close());return f;}
const count=(f,table)=>f.db.sql.prepare(`SELECT count(*) n FROM ${table}`).get().n;

test('verified sign-in preserves the source UUID and only self scope',async t=>{
  const f=await setup(t),{tokens}=await f.login();assert.equal(tokens.userId,USER);assert.equal(tokens.scope,'supporter:self');
  assert.deepEqual(await f.service.current(24,tokens.accessToken),{schemaVersion:1,userId:USER,clubId:24,clubSlug:'rayon_sports_rw',sessionId:tokens.sessionId,phoneVerified:true,authenticatedAt:f.now(),scope:'supporter:self'});
  assert.equal(count(f,'auth_sessions'),1);assert.equal(count(f,'auth_audit_events'),1);assert.equal(count(f,'auth_atomic_guards'),0);
  assert.ok(f.db.constraints.length>0&&f.db.constraints.every(c=>c==='first-primary'));
});
test('database contains no raw phone, OTP or unencrypted bearer credentials',async t=>{
  const f=await setup(t),c=await f.login();
  const text=JSON.stringify(['auth_identities','auth_challenges','auth_sessions','auth_refresh_tokens','auth_audit_events','auth_rate_windows'].map(n=>f.db.sql.prepare(`SELECT * FROM ${n}`).all()));
  for(const secretValue of [PHONE,c.tokens.accessToken,c.tokens.refreshToken,c.verify.verifier])assert.ok(!text.includes(secretValue));
  assert.notEqual(f.db.sql.prepare('SELECT code_hash FROM auth_challenges').get().code_hash,c.verify.code);
  assert.ok(!Object.keys(c.tokens).some(k=>/admin|membership|role|money/i.test(k)));
});
test('request retry is idempotent and does not resend the code',async t=>{
  const f=await setup(t),c=await f.request();assert.deepEqual(await f.service.requestOtp(24,c.input,f.ipHash),c.response);assert.equal(f.delivered.length,1);
});
test('request-ID reuse with a changed destination conflicts',async t=>{
  const f=await setup(t),c=await f.request();await fails(f.service.requestOtp(24,{...c.input,phone:'+250700000002'},f.ipHash),'request_conflict');assert.equal(f.delivered.length,1);
});
test('parallel identical OTP requests send exactly once',async t=>{
  const f=await setup(t),input={phone:PHONE,verifierHash:await sha(secret()),requestId:crypto.randomUUID()};
  const results=await Promise.all([f.service.requestOtp(24,input,f.ipHash),f.service.requestOtp(24,input,f.ipHash)]);
  assert.equal(results[0].challengeId,results[1].challengeId);assert.equal(f.delivered.length,1);assert.equal(count(f,'auth_challenges'),1);
});
test('known and unknown phone requests share the same response shape; unknown proof creates nothing',async t=>{
  const f=await setup(t),a=await f.request(),b=await f.request(24,'+250700000009');
  assert.deepEqual(Object.keys(a.response),Object.keys(b.response));assert.equal(b.response.state,'sent');
  await fails(f.service.verifyOtp(24,b.verify),'invalid_grant');assert.equal(count(f,'auth_identities'),1);assert.equal(count(f,'auth_sessions'),0);
});
test('no identity is activated merely because a code is correct',async t=>{
  const f=await setup(t,{active:false}),c=await f.request();await fails(f.service.verifyOtp(24,c.verify),'invalid_grant');assert.equal(count(f,'auth_sessions'),0);
});
test('missing club mapping cannot be supplied by client metadata',async t=>{
  const f=await setup(t);f.db.sql.exec('UPDATE auth_identity_clubs SET enabled=0 WHERE club_id=24');const c=await f.request();
  await fails(f.service.verifyOtp(24,c.verify),'invalid_grant');await fails(f.service.verifyOtp(24,{...c.verify,isAdmin:true}),'invalid_request');
});
test('wrong club cannot use a challenge or consume it',async t=>{
  const f=await setup(t),c=await f.request();await fails(f.service.verifyOtp(44,c.verify),'invalid_grant');assert.equal((await f.service.verifyOtp(24,c.verify)).userId,USER);
});
test('the client verifier is required independently of the code',async t=>{
  const f=await setup(t),c=await f.request();await fails(f.service.verifyOtp(24,{...c.verify,verifier:secret()}),'invalid_grant');assert.equal(count(f,'auth_sessions'),0);
});
test('incorrect code increments both challenge and phone failures',async t=>{
  const f=await setup(t),c=await f.request();await fails(f.service.verifyOtp(24,{...c.verify,code:c.verify.code==='000000'?'000001':'000000'}),'invalid_grant');
  assert.equal(f.db.sql.prepare('SELECT attempts FROM auth_challenges').get().attempts,1);assert.equal(f.db.sql.prepare('SELECT failed_attempts FROM auth_phone_controls').get().failed_attempts,1);
});
test('five incorrect codes lock that challenge even when correct code follows',async t=>{
  const f=await setup(t),c=await f.request(),wrong=c.verify.code==='000000'?'000001':'000000';
  for(let i=0;i<5;i++)await fails(f.service.verifyOtp(24,{...c.verify,code:wrong}),'invalid_grant');
  await fails(f.service.verifyOtp(24,c.verify),'invalid_grant');assert.equal(count(f,'auth_sessions'),0);
});
test('resending does not reset the phone failure limit',async t=>{
  const f=await setup(t);for(let cycle=0;cycle<2;cycle++){const c=await f.request();for(let i=0;i<5;i++)await fails(f.service.verifyOtp(24,{...c.verify,code:c.verify.code==='000000'?'000001':'000000'}),'invalid_grant');f.advance(P.sendCooldownMs);}
  assert.equal(f.db.sql.prepare('SELECT failed_attempts FROM auth_phone_controls').get().failed_attempts,10);
  await fails(f.request(),'rate_limited');assert.equal(f.delivered.length,2);
});
test('newly delivered code supersedes the previous phone challenge',async t=>{
  const f=await setup(t),old=await f.request();f.advance(P.sendCooldownMs);const next=await f.request();await fails(f.service.verifyOtp(24,old.verify),'invalid_grant');assert.equal((await f.service.verifyOtp(24,next.verify)).userId,USER);
});
test('success clears accumulated unsuccessful phone attempts',async t=>{
  const f=await setup(t),c=await f.request();await fails(f.service.verifyOtp(24,{...c.verify,code:c.verify.code==='000000'?'000001':'000000'}),'invalid_grant');await f.service.verifyOtp(24,c.verify);assert.equal(f.db.sql.prepare('SELECT failed_attempts FROM auth_phone_controls').get().failed_attempts,0);
});
test('code expiry rejects the exact boundary',async t=>{const f=await setup(t),c=await f.request();f.advance(P.codeMs);await fails(f.service.verifyOtp(24,c.verify),'invalid_grant');});
test('changing then reenabling tenant invalidates previously issued code',async t=>{const f=await setup(t),c=await f.request();f.db.sql.exec('UPDATE auth_tenants SET enabled=0 WHERE club_id=24; UPDATE auth_tenants SET enabled=1 WHERE club_id=24');await fails(f.service.verifyOtp(24,c.verify),'invalid_grant');});
test('provider failure never reports a delivered code',async t=>{const f=await setup(t);f.env.OTP_DELIVERY.deliver=async()=>{throw new Error('private provider failure');};const c=await f.request();assert.equal(c.response.state,'delivery_unknown');await fails(f.service.verifyOtp(24,c.verify),'invalid_grant');});
test('provider acknowledgement must match the actual challenge',async t=>{const f=await setup(t);f.env.OTP_DELIVERY.deliver=async()=>({accepted:true,challengeId:crypto.randomUUID()});const c=await f.request();assert.equal(c.response.state,'delivery_unknown');});
test('no delivery binding is a hard failure without reserving a challenge',async t=>{const f=await setup(t);delete f.env.OTP_DELIVERY;await fails(f.request(),'delivery_unavailable');assert.equal(count(f,'auth_challenges'),0);});
test('tenant revocation during delivery prevents usable code',async t=>{const f=await setup(t);f.env.OTP_DELIVERY.deliver=async x=>{f.delivered.push(x);f.db.sql.exec('UPDATE auth_tenants SET enabled=0 WHERE club_id=24');return {accepted:true,challengeId:x.challengeId};};const c=await f.request();assert.equal(c.response.state,'delivery_unknown');});
test('same verification request can recover a lost committed sign-in',async t=>{
  const f=await setup(t),c=await f.request();f.db.loseAfterCommit=true;const result=await f.service.verifyOtp(24,c.verify);
  assert.equal(result.userId,USER);assert.deepEqual(await f.service.verifyOtp(24,c.verify),result);assert.equal(count(f,'auth_sessions'),1);
});
test('concurrent identical verification has one session and one audit event',async t=>{
  const f=await setup(t),c=await f.request(),results=await Promise.all([f.service.verifyOtp(24,c.verify),f.service.verifyOtp(24,c.verify)]);
  assert.deepEqual(results[0],results[1]);assert.equal(count(f,'auth_sessions'),1);assert.equal(count(f,'auth_audit_events'),1);
});
test('same code with a different operation ID cannot mint another session',async t=>{
  const f=await setup(t),c=await f.login();await fails(f.service.verifyOtp(24,{...c.verify,requestId:crypto.randomUUID()}),'invalid_grant');assert.equal(count(f,'auth_sessions'),1);
});
test('sign-in recovery still requires the correct code and verifier',async t=>{
  const f=await setup(t),c=await f.login();await fails(f.service.verifyOtp(24,{...c.verify,code:c.verify.code==='000000'?'000001':'000000'}),'invalid_grant');await fails(f.service.verifyOtp(24,{...c.verify,verifier:secret()}),'invalid_grant');
});
test('sign-in replay expires, and revoked sessions cannot be recovered',async t=>{
  const f=await setup(t),c=await f.login();await f.service.logout(24,c.tokens.accessToken,{scope:'current'});await fails(f.service.verifyOtp(24,c.verify),'invalid_session');f.advance(P.recoveryMs);await fails(f.service.verifyOtp(24,c.verify),'invalid_grant');
});
test('session refresh rotates access and refresh credentials without extending absolute life',async t=>{
  const f=await setup(t),c=await f.login();f.advance(120_000);const n=await f.service.refresh(24,{refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()});
  assert.notEqual(n.accessToken,c.tokens.accessToken);assert.notEqual(n.refreshToken,c.tokens.refreshToken);assert.equal(n.sessionExpiresAt,c.tokens.sessionExpiresAt);assert.equal(n.sessionId,c.tokens.sessionId);
  await fails(f.service.current(24,c.tokens.accessToken),'invalid_session');assert.equal((await f.service.current(24,n.accessToken)).userId,USER);
});
test('expired access can be refreshed but cannot authorize a read',async t=>{const f=await setup(t),c=await f.login();f.advance(P.accessMs);await fails(f.service.current(24,c.tokens.accessToken),'invalid_session');assert.ok((await f.service.refresh(24,{refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()})).accessToken);});
test('absolute expiry requires new authentication',async t=>{const f=await setup(t),c=await f.login();f.advance(P.sessionMs);await fails(f.service.refresh(24,{refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()}),'invalid_session');});
test('refresh response loss is recoverable only using the original request ID',async t=>{const f=await setup(t),c=await f.login(),input={refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()};f.db.loseAfterCommit=true;const n=await f.service.refresh(24,input);assert.deepEqual(await f.service.refresh(24,input),n);assert.equal(count(f,'auth_refresh_tokens'),2);});
test('parallel identical refreshes return the same result',async t=>{
  const f=await setup(t),c=await f.login(),input={refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()};
  const r=await Promise.all([f.service.refresh(24,input),f.service.refresh(24,input)]);assert.deepEqual(r[0],r[1]);assert.equal(count(f,'auth_refresh_tokens'),2);
});
test('consumed refresh token reuse with a different request revokes the family',async t=>{
  const f=await setup(t),c=await f.login(),n=await f.service.refresh(24,{refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()});
  await fails(f.service.refresh(24,{refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()}),'invalid_session');await fails(f.service.current(24,n.accessToken),'invalid_session');assert.equal(f.db.sql.prepare("SELECT count(*) n FROM auth_audit_events WHERE event_type='refresh_reuse'").get().n,1);
});
test('guessed token cannot revoke a real session',async t=>{const f=await setup(t),c=await f.login();await fails(f.service.refresh(24,{refreshToken:`acr_${secret()}`,requestId:crypto.randomUUID()}),'invalid_session');assert.ok(await f.service.current(24,c.tokens.accessToken));});
test('wrong-club refresh cannot revoke a token even if consumed',async t=>{const f=await setup(t),c=await f.login(),input={refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()},n=await f.service.refresh(24,input);await fails(f.service.refresh(44,{...input,requestId:crypto.randomUUID()}),'invalid_session');assert.ok(await f.service.current(24,n.accessToken));});
test('stale response recovery cannot return superseded credentials',async t=>{const f=await setup(t),c=await f.login(),a={refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()},n=await f.service.refresh(24,a);await f.service.refresh(24,{refreshToken:n.refreshToken,requestId:crypto.randomUUID()});await fails(f.service.refresh(24,a),'reauthentication_required');});
test('expired same-request recovery fails without falsely revoking a family',async t=>{const f=await setup(t),c=await f.login(),input={refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()},n=await f.service.refresh(24,input);f.advance(P.recoveryMs);await fails(f.service.refresh(24,input),'reauthentication_required');assert.ok(await f.service.current(24,n.accessToken));});
for(const kind of ['identity','grant','tenant'])test(`${kind} revoke-and-reenable never revives sessions`,async t=>{
  const f=await setup(t),c=await f.login();
  const sql=kind==='identity'?"UPDATE auth_identities SET status='suspended'; UPDATE auth_identities SET status='active'":kind==='grant'?'UPDATE auth_identity_clubs SET enabled=0 WHERE club_id=24; UPDATE auth_identity_clubs SET enabled=1 WHERE club_id=24':'UPDATE auth_tenants SET enabled=0 WHERE club_id=24; UPDATE auth_tenants SET enabled=1 WHERE club_id=24';
  f.db.sql.exec(sql);await fails(f.service.current(24,c.tokens.accessToken),'invalid_session');await fails(f.service.refresh(24,{refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()}),'invalid_session');
});
test('revocation immediately before sign-in commit rolls back consumption',async t=>{const f=await setup(t),c=await f.request();f.db.beforeBatch=db=>db.sql.exec("UPDATE auth_identities SET status='suspended'");await fails(f.service.verifyOtp(24,c.verify),'invalid_grant');assert.equal(count(f,'auth_sessions'),0);assert.equal(f.db.sql.prepare('SELECT state FROM auth_challenges').get().state,'sent');});
test('revocation immediately before refresh commit creates no token',async t=>{const f=await setup(t),c=await f.login();f.db.beforeBatch=db=>db.sql.exec('UPDATE auth_identity_clubs SET enabled=0 WHERE club_id=24');await fails(f.service.refresh(24,{refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()}),'invalid_session');assert.equal(count(f,'auth_refresh_tokens'),1);});
test('sign-out other sessions preserves the current one and other clubs',async t=>{const f=await setup(t),a=await f.login();f.advance(P.sendCooldownMs);const b=await f.login();f.advance(P.sendCooldownMs);const c=await f.login(44);await f.service.logout(24,b.tokens.accessToken,{scope:'others'});await fails(f.service.current(24,a.tokens.accessToken),'invalid_session');assert.ok(await f.service.current(24,b.tokens.accessToken));assert.ok(await f.service.current(44,c.tokens.accessToken));});
test('sign-out all is scoped to this user and club',async t=>{const f=await setup(t),a=await f.login();f.advance(P.sendCooldownMs);const b=await f.login();await f.service.logout(24,a.tokens.accessToken,{scope:'all'});await fails(f.service.current(24,b.tokens.accessToken),'invalid_session');await fails(f.service.refresh(24,{refreshToken:a.tokens.refreshToken,requestId:crypto.randomUUID()}),'invalid_session');});
test('logout rejects caller-supplied user IDs',async t=>{const f=await setup(t),a=await f.login();await fails(f.service.logout(24,a.tokens.accessToken,{scope:'all',userId:'another'}),'invalid_request');assert.ok(await f.service.current(24,a.tokens.accessToken));});
test('retained audit and identity mapping cannot be overwritten or silently deleted',async t=>{const f=await setup(t);await f.login();assert.throws(()=>f.db.sql.exec('DELETE FROM auth_audit_events'));assert.throws(()=>f.db.sql.exec("UPDATE auth_audit_events SET event_type='refreshed'"));assert.throws(()=>f.db.sql.exec('DELETE FROM auth_identity_clubs'));assert.throws(()=>f.db.sql.exec('UPDATE auth_identities SET security_version=1'));});
test('resource ownership helper requires both trusted user and tenant',()=>{assert.ok(ownedBy({userId:USER,clubId:24},{userId:USER,clubId:24}));assert.throws(()=>ownedBy({userId:USER,clubId:24},{userId:USER,clubId:44}));assert.throws(()=>ownedBy({userId:USER,clubId:24},{userId:'other',clubId:24}));});
test('bounded maintenance removes expired encrypted recovery copies without deleting audit',async t=>{const f=await setup(t),c=await f.login();await f.service.refresh(24,{refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()});f.advance(P.recoveryMs);await f.service.scrubRecoverySecrets();assert.equal(f.db.sql.prepare('SELECT response_ciphertext FROM auth_challenges').get().response_ciphertext,null);assert.equal(f.db.sql.prepare('SELECT response_ciphertext FROM auth_refresh_tokens WHERE consumed_at IS NOT NULL').get().response_ciphertext,null);assert.equal(count(f,'auth_audit_events'),2);});
for(let position=0;position<9;position++)test(`verification SQL failure at statement ${position} rolls back all authentication effects`,async t=>{const f=await setup(t),c=await f.request();f.db.failAt=position;await assert.rejects(f.service.verifyOtp(24,c.verify));assert.equal(count(f,'auth_sessions'),0);assert.equal(count(f,'auth_refresh_tokens'),0);assert.equal(count(f,'auth_audit_events'),0);assert.equal(count(f,'auth_atomic_guards'),0);assert.equal(f.db.sql.prepare('SELECT state FROM auth_challenges').get().state,'sent');f.db.failAt=null;assert.ok(await f.service.verifyOtp(24,c.verify));});
for(let position=0;position<8;position++)test(`refresh SQL failure at statement ${position} leaves the prior tokens usable`,async t=>{const f=await setup(t),c=await f.login();f.db.failAt=position;await assert.rejects(f.service.refresh(24,{refreshToken:c.tokens.refreshToken,requestId:crypto.randomUUID()}));assert.equal(count(f,'auth_refresh_tokens'),1);assert.equal(count(f,'auth_audit_events'),1);assert.ok(await f.service.current(24,c.tokens.accessToken));});
