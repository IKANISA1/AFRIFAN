import { WorkerEntrypoint } from 'cloudflare:workers';
import gateway from './http.mjs';
import { SupporterAuth } from './service.mjs';
import { AuthError } from './policy.mjs';
export default {
  fetch:gateway.fetch,
  async scheduled(_event,env) {
    if(env.MAINTENANCE_ENABLED!=='true') return;
    await new SupporterAuth(env).scrubRecoverySecrets();
  },
};
// Only reviewed resource-API bindings may use this entrypoint. Caller supplies
// a bearer credential, not asserted user/role metadata. It grants no staff role.
export class SupporterIdentity extends WorkerEntrypoint {
  async authorize(accessToken,expectedClubId) {
    try {return await new SupporterAuth(this.env).current(expectedClubId,accessToken);}
    catch(error) { if(error instanceof AuthError&&error.status===401)return null;throw new Error('identity_unavailable'); }
  }
  fetch() {return new Response(null,{status:404});}
}
