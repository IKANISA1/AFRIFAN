#!/usr/bin/env python3
"""Repeat bounded source tests in a disposable subset; never applies the patch."""
from __future__ import annotations
import argparse
import ast
import concurrent.futures
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

BUNDLE = Path(__file__).resolve().parent
sys.path.insert(0, str(BUNDLE))
from apply_patch import digest, read_manifest, safe_path


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, help='Optional output directory for test logs')
    args=parser.parse_args()
    for tool in ('node','git','tsc'):
        if not shutil.which(tool):
            parser.error(f'{tool} is required')
    manifest, _ = read_manifest(BUNDLE)
    results=[]
    with tempfile.TemporaryDirectory(prefix='africlub-patch-verify-') as temporary:
        root=Path(temporary)/'candidate'; root.mkdir()
        for condition in manifest.get('preconditions',[]):
            source=safe_path(BUNDLE, 'context/'+condition['path'])
            if digest(source)!=condition['sha256']: raise RuntimeError('Context checksum failed: '+condition['path'])
            target=safe_path(root,condition['path']);target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(source,target)
        for entry in manifest['entries']:
            source=safe_path(BUNDLE, 'files/'+entry['path'])
            if digest(source)!=entry['after_sha256']:raise RuntimeError('Payload checksum failed: '+entry['path'])
            target=safe_path(root,entry['path']);target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(source,target)
        cases=[
            ('node-regressions', ['node','--experimental-sqlite','--test',
                'tools/scripts/validate_repository_boundary.test.mjs',
                'tools/scripts/validate_predict_economics_contract.test.mjs',
                'cloudflare/rayon-public/tests/snapshot.test.mjs'],root),
            ('operator-regressions',['node','--test',
                'cloudflare/operator-api/tests/auth-http.test.mjs',
                'cloudflare/operator-api/tests/publication.test.mjs',
                'cloudflare/operator-api/tests/client.test.mjs',
                'cloudflare/operator-api/tests/deployment.test.mjs',
                'cloudflare/operator-api/tests/contract.test.mjs',
                'cloudflare/operator-api/tests/inspection.test.mjs',
                'cloudflare/operator-api/tests/ui-controller.test.mjs',
                'cloudflare/operator-api/tests/ui-static.test.mjs'],root),
            ('supporter-auth-regressions',['node','--test',
                'cloudflare/supporter-auth/tests/session.test.mjs',
                'cloudflare/supporter-auth/tests/http.test.mjs',
                'cloudflare/supporter-auth/tests/import-crypto.test.mjs',
                'cloudflare/supporter-auth/tests/client.test.mjs',
                'cloudflare/supporter-auth/tests/contract.test.mjs'],root),
            ('supporter-auth-client-compile',['node','cloudflare/supporter-auth/scripts/compile-client.mjs'],root),
            ('supporter-auth-disabled-config',['node','cloudflare/supporter-auth/scripts/check-deployment.mjs'],root),
            ('ui-build-parity',['node','cloudflare/operator-api/scripts/build-ui.mjs','--check'],root),
            ('disabled-deployment-config',['node','cloudflare/operator-api/scripts/check-deployment.mjs'],root),
            ('python-regressions',[sys.executable,'-m','unittest','-v',
                'test_supporter_sms_boundary','test_public_snapshot_import','test_migration_release'],root/'tools/scripts'),

        ]
        for label,command,cwd in cases:
            run=subprocess.run(command,cwd=cwd,capture_output=True,text=True,timeout=120,
                               env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
            text=run.stdout+run.stderr
            print(f'{label}: {"PASS" if run.returncode==0 else "FAIL"}')
            if args.results:
                args.results.mkdir(parents=True,exist_ok=True)
                (args.results/f'{label}.log').write_text(text)
            if run.returncode: print(text,file=sys.stderr)
            results.append({'name':label,'exit_code':run.returncode})
    # Independent installer fixtures can run in bounded parallel slices. Every
    # test name is derived from the shipped test class; none is silently omitted.
    tree=ast.parse((BUNDLE/'tests/test_patch_installer.py').read_text())
    names=sorted(n.name for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body
                 if isinstance(n,ast.FunctionDef) and n.name.startswith('test_'))
    def installer_slice(item):
        i,part=item
        command=[sys.executable,'-m','unittest','-v',*[f'test_patch_installer.PatchInstallerTests.{n}' for n in part]]
        run=subprocess.run(command,cwd=BUNDLE/'tests',capture_output=True,text=True,timeout=90,
                           env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        label=f'installer-regressions-{i+1}'
        if args.results:(args.results/f'{label}.log').write_text(run.stdout+run.stderr)
        return {'name':label,'exit_code':run.returncode,'test_count':len(part),'tests':part}
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        installer_results=list(pool.map(installer_slice,enumerate([names[i::6] for i in range(6)])))
    for result in installer_results:
        print(f"{result['name']}: {'PASS' if result['exit_code']==0 else 'FAIL'}")
    results.extend(installer_results)
    report={'scope':'targeted disposable source subset, not full checkout or Cloudflare runtime',
            'tests':results,'node':subprocess.check_output(['node','--version'],text=True).strip(),
            'python':sys.version.split()[0], 'dart_flutter_executed':False,
            'rendered_browser_executed':False, 'browser_validation':'Separate explicit run; not part of this source-check command',
            'deployment_performed':False,'database_migrations_applied_remotely':False}
    if args.results:(args.results/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if all(r['exit_code']==0 for r in results) else 1


if __name__=='__main__':sys.exit(main())
