# AFRICLUB cumulative source patch v4

Date: 26 September 2026. Includes every source change in v1, v2 and v3. **Use v4
instead of applying an older package afterward.** This is source delivery, not a
completed migration, production-ready authentication service or deployment.

The cumulative patch has **103 source changes: 24 modifications to original source
files and 79 additions**. Batch 4 contributes **20 new files and one modification**
to the existing source-check script. Its disabled identity/session service handles
only approved imported verified-phone identities. No original Flutter authentication
caller is changed. External code-delivery and the remaining auth journeys are not
implemented by this batch.

Google Drive and Files expose read actions only in this turn. No v3/v4 upload,
existing-file overwrite, remote migration, enrollment, key/provider/billing action,
production switch or Supabase retirement was performed.

## Read-only preflight and source application

Extract this archive outside an authorized AFRICLUB checkout. Stop source editors
and builds, then run from the extracted package directory:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB"
python3 apply_patch.py --root "/path/to/AFRICLUB" --apply
python3 verify_bundle.py --results "/tmp/africlub-v4-verification"
```

Preserve the returned rollback directory. To restore the source state present at
application time, with the exact same package and manifest:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB" --rollback "/exact/printed/rollback_directory"
```

Only explicitly recognized original/v1/v2/v3 per-file hashes are accepted. Unknown
edits, path traversal, symlinks, mismatched journals and corrupted payloads stop the
installer; there is no force overwrite. Existing new files are backed up and restored
rather than blindly deleted. Individual writes are atomic, but the multi-file
operation is not an atomic transaction for concurrent readers.

The installer does not call providers, provision resources, execute database
migrations, change billing or deploy. These source backups are not production data
backups. Run the pinned full Flutter/Next.js/database/native acceptance checks
separately; the targeted verifier does not replace them or lower toolchain versions.

## Evidence and files

- `files/`: exact relative source payloads.
- `context/`: seven unchanged prerequisites used for targeted validation.
- `manifest.json`: before/after hashes, known original Drive IDs and exact prior
  version hashes. New unuploaded files do not receive invented Drive IDs.
- `changes.patch`: original-baseline cumulative diff; prefer the installer for
  recognized upgrades from already-applied v1/v2/v3.
- `batch4.patch`, `batch4-changes.json`: changes relative to v3 only.
- `IMPLEMENTATION_REPORT.md`: actual current scope, tests and unfinished work.
- `evidence/batch4/`: freshly executed cumulative tests, syntax and four installation
  trials. `evidence/prior-through-v3/` retains explicitly historical evidence.
- `remaining_actions.json`: workstream status without turning inventory into ports.
- `files/cloudflare/supporter-auth/README.md`: protocol, limits, delivery contract,
  failure recovery, privacy and staging prerequisites.

The current cumulative verifier repeats **453 passing targeted tests**, including
145 new supporter-auth tests. Real Cloudflare/provider authentication, native secure
storage, full application builds and production behavior remain unverified.
Prior v3 browser cases were blocked by administrator policy and were not rerun here.

Raw identity exports, authentication plans, live credentials, media, databases,
dependency caches and font files are not included. Synthetic test identities and
synthetic test keys are explicitly labelled in the test fixture. Hashes establish
byte consistency, not independent security certification or release authorization.
