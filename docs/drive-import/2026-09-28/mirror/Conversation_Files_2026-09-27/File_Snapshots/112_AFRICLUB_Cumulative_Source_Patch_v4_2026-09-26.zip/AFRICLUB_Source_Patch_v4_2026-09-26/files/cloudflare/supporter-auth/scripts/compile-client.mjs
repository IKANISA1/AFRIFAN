#!/usr/bin/env node
import { execFileSync } from 'node:child_process';
import { mkdtempSync,rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
const out=mkdtempSync(join(tmpdir(),'africlub-auth-types-'));
try{execFileSync('tsc',[fileURLToPath(new URL('../client.ts',import.meta.url)),'--strict','--target','ES2022','--module','ES2022','--lib','ES2022,DOM','--outDir',out],{stdio:'inherit'});console.log('Supporter client strict compilation passed.');}
finally{rmSync(out,{recursive:true,force:true});}
