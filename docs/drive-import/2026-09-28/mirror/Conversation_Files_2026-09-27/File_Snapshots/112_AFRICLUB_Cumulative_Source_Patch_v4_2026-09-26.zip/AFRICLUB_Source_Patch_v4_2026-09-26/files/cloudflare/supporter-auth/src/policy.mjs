// Candidate defaults; release requires traffic/abuse and identity-risk review.
export const POLICY=Object.freeze({codeMs:300_000,accessMs:300_000,sessionMs:7*86_400_000,
  recoveryMs:120_000,sendCooldownMs:60_000,phoneSendsPerHour:5,ipSendsPerTenMinutes:20,
  globalSendsPerHour:200,attemptsPerChallenge:5,failedPhoneAttempts:10,phoneLockMs:3_600_000,
  requestsPerIpMinute:120,sessionActionsPerMinute:30,providerTimeoutMs:8_000});
export class AuthError extends Error { constructor(code,status=400) { super(code); this.code=code; this.status=status; } }
export function requireThat(value,code='invalid_request',status=400) { if(!value) throw new AuthError(code,status); }
export const isUuid=v=>typeof v==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(v);
export const isHash=v=>typeof v==='string'&&/^[0-9a-f]{64}$/.test(v);
export const isSecret=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{43}$/.test(v);
export const isClub=v=>Number.isSafeInteger(v)&&v>0;
export function phone(value) { requireThat(typeof value==='string'&&/^\+[1-9][0-9]{7,14}$/.test(value)); return value; }
export function fields(value,required) {
  requireThat(value&&typeof value==='object'&&!Array.isArray(value));
  requireThat(Object.keys(value).length===required.length&&required.every(k=>Object.hasOwn(value,k)));
}
export function token(value,prefix) { requireThat(typeof value==='string'&&value.startsWith(prefix)&&isSecret(value.slice(prefix.length)),'invalid_session',401); return value; }
export function config(env) {
  requireThat(env.AUTH_ENABLED==='true','service_unavailable',503);
  requireThat(env.AUTH_DB&&typeof env.AUTH_DB.withSession==='function','service_unavailable',503);
  requireThat(env.AUTH_KEY_ID==='v1','service_unavailable',503);
}
export function ownedBy(context,resource) {
  requireThat(context&&resource&&context.userId===resource.userId&&context.clubId===resource.clubId,'forbidden',403);
  return true;
}
