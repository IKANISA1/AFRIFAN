# Supporter identity and sessions — disabled migration candidate

Date: 26 September 2026. This is an additive, native-bearer authentication candidate,
not the completed replacement of AFRICLUB authentication or a deployed service.
The existing Flutter/Supabase repository, phone-change, anonymous, profile and
account-deletion flows are unchanged. No live users have been imported.

## Scope and authority

The initial scope is **previously verified phone identities imported with explicit
club mappings**. Original source UUIDs are preserved. No new account, automatic
phone-based merge, anonymous-account link, paid membership, reward entitlement,
staff role or operator permission is granted by this service. Successful phone
verification alone cannot create an identity or enable a club mapping.

A global identity database is separate from each club's transactional database and
from the Rayon public-source database. `AUTH_DB` must point only at a deliberately
provisioned identity database. The template uses a placeholder database ID,
`workers_dev: false`, no domain or service binding, and disabled switches. There is
no automatic account creation, provisioning, enrollment, migration, deployment,
message delivery, financial write, key change or Supabase shutdown.

`src/http.mjs` provides five endpoints under `/v1/auth/clubs/{clubId}/`:

| Method | Path | Effect |
| --- | --- | --- |
| POST | `otp/request` | Request a single-use code bound to a client verifier and request UUID. |
| POST | `otp/verify` | Consume a valid code and create one club-bound session for an enabled imported identity. |
| POST | `sessions/refresh` | Rotate access and refresh credentials without extending the session's absolute lifetime. |
| GET | `sessions/current` | Validate the current access credential and return identity plus club, not entitlements. |
| POST | `sessions/logout` | Revoke this, other, or all sessions for the same user **within this club**. |

The exact protocol is `contracts/openapi.json`. This is not an OAuth/OIDC server,
not cookie/browser session middleware, and not a claim of NIST assurance-level
compliance. Phone delivery is not phishing-resistant; recycled numbers, account
recovery, device compromise and SIM/provider takeover require separate controls.

## Request, verification and interrupted responses

The native client creates a cryptographically random 32-byte verifier and a request
UUID. Only the SHA-256 verifier hash accompanies the phone request. Store the
verifier and pending operation in OS-protected storage, scoped to the club and app
account. A received code without its verifier cannot complete the request.

The server creates a random six-digit code, stores an HMAC bound to challenge,
phone and club, and calls the **private** `OTP_DELIVERY.deliver` binding. A request
is `sent` only after a matching accepted acknowledgement. A timeout or ambiguous
provider response becomes `delivery_unknown`, not assumed success. Missing delivery
binding fails closed. There is no unauthenticated callback that marks a code valid.
Retries of the same request UUID do not send another code. A crash may leave a
challenge pending until its five-minute expiry; explicitly begin a new request only
after the cooldown and preserve the old outcome. Superseded codes are unusable.

Verification requires challenge ID, six-digit code, original verifier, club and a
separate stable verification-request UUID. Consumption, identity/version recheck,
session creation, hashed credentials, audit event and short-lived encrypted
response are in one batch. A wrong code increases both challenge and phone counters;
a resend does not reset the phone failure count. Missing, disabled or ineligible
identities receive the same invalid-grant response. The request step does not query
identity existence, though provider availability and eligible-user outcomes can
still have observable timing differences; no complete side-channel proof is claimed.

Preserve the exact request and request UUID before every credential-changing call.
For a lost verification or refresh response, explicitly retry the **same request**
within two minutes to recover the same encrypted result. No second session or
refresh generation is created. Recovery rechecks current authority and generation.
After the recovery window, reauthenticate; do not generate a new request UUID for a
consumed refresh token. A different request UUID using a consumed refresh token
revokes that session family as a reuse event. This is a deliberate bounded recovery
exception, not general acceptance of old tokens. A thief with both token and saved
request UUID may exploit that recovery window, so the entire operation is sensitive.

The TypeScript adapter does not automatically retry writes. `OutcomeUnknown`, an
invalid response body, a protocol-validation error after a write, or a transport
failure can all occur after a commit. Retain the original pending operation until
resolved. Reference-client code is not a native secure-storage or single-flight
implementation: those integrations still need to be built and tested in Flutter.

## Identity, session and privacy controls

Every session fixes user ID, club, identity security version, tenant revision and
club-binding revision. Reads use a fresh D1 `first-primary` session; mutation batches
recheck those versions and expiries. Suspending then reactivating an identity or
disabling then reenabling a grant does not revive earlier sessions or challenges.
Correctness on the actual D1 runtime, scheduling and read-replication configuration
still needs live staging verification; local SQLite is not that proof.

Access tokens and refresh tokens have independent 32-byte random values. Normal
records retain their hashes, not plaintext tokens. A response needed for bounded
retry recovery is AES-GCM encrypted with operation-bound associated data. Phone
lookup uses keyed HMAC. Code and raw destination exist transiently for delivery;
do not log request bodies, tokens, provider payloads, codes or phone numbers.
Pseudonymous UUIDs, HMACs and audit rows are still sensitive personal data.

Provision three independent random 32-byte canonical base64url secrets through the
reviewed secret mechanism: `PHONE_HMAC_KEY`, `OTP_HMAC_KEY`, and
`RESPONSE_ENCRYPTION_KEY`. They must differ. No real key is shipped. `AUTH_KEY_ID=v1`
is the only supported key generation. Zero-downtime key rollover is NOT implemented;
rotate only through an approved remapping/reauthentication procedure, never by
silently changing a phone HMAC key beneath existing mappings.

The `SupporterIdentity` private entrypoint validates an actual bearer credential and
expected club and returns `supporter:self`. Binding callers cannot assert a user ID
or role instead. Only explicitly reviewed resource API Workers should receive this
binding. Its HTTP entrypoint returns 404. The resource service must independently
check the canonical resource owner, club, operation and relevant entitlement at its
own mutation boundary; identity lookup is not a distributed financial transaction.
The small `ownedBy` helper expects a trusted database-loaded resource, never a
client-authored object. A private service name alone does not prove binding safety.

Audit rows are append-only under the supplied schema. The scheduled function clears
at most 500 expired encrypted response bodies from each recovery table and 500 old
rate-window rows per run, using indexed selections. It does not erase accounts or
purge challenge, phone-control, refresh-history, source-mapping or audit records.
Set retention, privacy, alerting, export and legally required deletion procedures
before production; bounded cleanup needs throughput and backlog monitoring.

## Candidate policy values

These are deliberately bounded pilot defaults, not approved traffic forecasts:

| Control | Candidate value |
| --- | --- |
| Code validity / access-token validity | 5 minutes each |
| Absolute session lifetime | 7 days, not sliding |
| Same-request response recovery | 2 minutes |
| Resend cooldown | 60 seconds |
| Send limits | 5 per phone/hour; 20 per network address/10 minutes; 200 globally/hour |
| Invalid codes | 5 per challenge; 10 accumulated per phone trigger a 1-hour lock |
| General ingress / refresh limits | 120 per network address/minute; 30 new refresh actions/session/minute |
| Delivery timeout | 8 seconds |

The phone lock spans club requests. These controls can inconvenience legitimate
shared networks and can be abused to deny another person's sign-in. They do not
replace upstream abuse protection, risk checks, monitoring or a recovery channel.
`Retry-After: 60` is a minimum suggested wait, not a promise that a longer quota or
phone lock has cleared. Capacity and cost review are required before enabling.

## Delivery contract — adapter not implemented here

`contracts/delivery.json` specifies `AuthenticationCodeDelivery.deliver`. The
candidate calls this private adapter but **does not implement or configure an
external WhatsApp/SMS provider**. No real phone was messaged in testing. To complete
it, preserve the approved provider and template/consent requirements, provision its
credentials server-side, enforce the exact registered sender and template, bind
idempotency to `challengeId`, bound timeouts and response size, and verify real
accepted/rejected/ambiguous outcomes. An `accepted` acknowledgement means dispatch
acceptance, not delivery to a device, code verification or identity proof. The public
API never accepts provider credentials or a destination URL from the caller.

Do not point the binding at generic notification infrastructure without proving
its authentication-code confidentiality, deduplication and retention contract.
Queued automatic retries are not enabled here. The surrounding code must preserve
unknown delivery states rather than introducing another unchecked resend route.

## Offline import preparation

The planner consumes two private JSON files and the expected exact export hash:

```sh
# PHONE_HMAC_KEY is supplied privately in the process environment, never committed.
node cloudflare/supporter-auth/scripts/prepare-identity-import.mjs \
  users.private.json mappings.private.json EXPECTED_EXPORT_SHA256 plan.private.json
```

`users.private.json` is `{ "users": [...] }` using stable source fields `id`, `phone`,
`phone_confirmed_at`, `is_anonymous`, `banned_until`, and `deleted_at`.
`mappings.private.json` has exactly `sourceProject`, `reviewRef`, `clubs` (each with
`clubId` and `clubSlug`), and `bindings` (each with `userId` and `clubId`). Metadata
claims from users do not authorize club assignment. Review the source project and
bindings independently. This format is a bounded importer input contract, not an
assertion that every provider export already has this wrapper.

The planner checks the source hash, duplicate UUIDs/phones, verified state and
explicit bindings. Anonymous, unverified, banned or deleted users are excluded;
excluded identities cannot be bound. It produces **parameterized INSERT plans**,
not an executable network request: tenants and club bindings are disabled and users
suspended. All explicitly included UUIDs are preserved, with immutable source provenance.
Plans contain sensitive identifiers/hashes and must stay outside tracked source.
The CLI writes a new 0600 file and refuses overwrite. A review-reference label does
not prove review. No apply, activation, role-administration or account-deletion
endpoint is included. The saved production auth inventory was not imported here.

## Deployment and validation

Run only the offline/source checks in the provided environment:

```sh
node cloudflare/supporter-auth/scripts/check-deployment.mjs
node cloudflare/supporter-auth/scripts/compile-client.mjs
node --test cloudflare/supporter-auth/tests/*.test.mjs
```

The configuration checker always reports live runtime, identity mappings, provider,
secret provisioning and release approval as unverified. `--ready` validates a
separately prepared staging configuration; it does not provision or deploy it. The
fixed service/database names are prospective isolated staging resources, not proof
that they exist. Discover commands from the installed pinned Wrangler help before
remote work. Never run the new schema in an existing unrelated D1 database.

The HTTP gateway is native bearer-only: HTTPS and exact configured origin, a fixed
protocol header for POST, strict 4096-byte JSON limits, no cookies, no CORS and no
client-selected callback/actor. The custom protocol header is not a credential.
Rate limiting relies on `CF-Connecting-IP` from directly invoked Cloudflare ingress;
a generic reverse proxy or arbitrary Worker caller could invalidate that trust
assumption. Test actual ingress and service-binding exposure before enablement.
Browser/Next.js use requires a reviewed secure cookie/BFF design and is not supplied.

Source tests use real Web Crypto, actual SQLite schema/triggers and simulated
Cloudflare D1-shaped adapters, delivery and ingress. They cover duplicate operations,
wrong-club denial, revocation races, expired codes, locked phones, code/verifier
replay, lost responses, rollback injection and refresh-family reuse. They are not
workerd/D1, a real provider, signing, physical-device or production load tests.
The WorkerEntrypoint wrapper is syntax-checked, not instantiated in Workers.

Before cutover, implement and verify the remaining anonymous/new-user/linking,
phone-change and lost-phone recovery, profile/bootstrap, privacy/export/deletion,
full staff roles, native protected storage, complete API adapters and real provider
flows. Do not delete Supabase auth or claim parity while these are missing. The
existing caller still uses the old backend; installing this source changes none of
its network destinations. Financial and ticketing authority remain unchanged.

## References used for design, not certification

- NIST SP 800-63B-4: https://pages.nist.gov/800-63-4/sp800-63b.html
- OAuth security best practice (rotation/replay discussion only; this protocol is
  not OAuth): https://www.rfc-editor.org/rfc/rfc9700.html
- D1 batch and sessions: https://developers.cloudflare.com/d1/worker-api/d1-database/
- D1 read replication: https://developers.cloudflare.com/d1/best-practices/read-replication/
- Workers Web Crypto: https://developers.cloudflare.com/workers/runtime-apis/web-crypto/

References checked 26 September 2026. Platform documentation is not evidence that
this candidate was deployed or passed an independent security or compliance review.
