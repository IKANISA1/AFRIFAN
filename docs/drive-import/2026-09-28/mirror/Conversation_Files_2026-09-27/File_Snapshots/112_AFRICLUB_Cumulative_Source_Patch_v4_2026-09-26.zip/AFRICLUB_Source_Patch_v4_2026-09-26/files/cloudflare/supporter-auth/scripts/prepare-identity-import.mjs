#!/usr/bin/env node
// OFFLINE planning only. Input files contain private identity data; keep outside Git.
import { readFileSync,writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { sha,mac,validKey } from '../src/crypto.mjs';
import { isUuid,isHash,isClub,phone } from '../src/policy.mjs';
function check(value) {if(!value)throw new Error('identity_import_input_invalid');}
export async function prepareIdentityImport(userBytes,bindingBytes,expectedHash,key,{now=Date.now()}={}) {
  check(typeof userBytes==='string'&&typeof bindingBytes==='string'&&userBytes.length<=16_000_000&&bindingBytes.length<=2_000_000);
  check(isHash(expectedHash)&&validKey(key));check(await sha(userBytes)===expectedHash);
  const source=JSON.parse(userBytes),mapping=JSON.parse(bindingBytes);
  check(mapping&&typeof mapping==='object'&&!Array.isArray(mapping)&&Object.keys(mapping).sort().join(',')==='bindings,clubs,reviewRef,sourceProject');
  check(source&&typeof source==='object'&&Array.isArray(source.users)&&source.users.length<=1000);
  check(typeof mapping.sourceProject==='string'&&/^[a-z0-9_-]{3,64}$/.test(mapping.sourceProject));
  check(typeof mapping.reviewRef==='string'&&mapping.reviewRef.length>=8&&mapping.reviewRef.length<=200);
  check(Array.isArray(mapping.clubs)&&mapping.clubs.length>0&&mapping.clubs.length<=5);
  check(Array.isArray(mapping.bindings)&&mapping.bindings.length>0&&mapping.bindings.length<=5000);
  const clubs=new Map(),slugs=new Set(),users=new Map(),phones=new Map(),excluded=[];
  for(const c of mapping.clubs) {
    check(c&&Object.keys(c).sort().join(',')==='clubId,clubSlug'&&isClub(c.clubId)&&typeof c.clubSlug==='string'&&/^[a-z0-9_]{3,64}$/.test(c.clubSlug));
    check(!clubs.has(c.clubId)&&!slugs.has(c.clubSlug));clubs.set(c.clubId,c);slugs.add(c.clubSlug);
  }
  const seen=new Set();
  for(const u of source.users) {
    check(u&&isUuid(u.id)&&!seen.has(u.id));seen.add(u.id);
    const confirmed=Date.parse(u.phone_confirmed_at||'');
    const banned=!!u.banned_until&&(!Number.isFinite(Date.parse(u.banned_until))||Date.parse(u.banned_until)>now);
    if(u.is_anonymous!==false||!Number.isFinite(confirmed)||confirmed>now||u.deleted_at||banned) {excluded.push({userId:u.id,reason:'not_eligible_verified_identity'});continue;}
    const normalized=typeof u.phone==='string'&&/^\d+$/.test(u.phone)?`+${u.phone}`:u.phone;
    try {phone(normalized);}catch{throw new Error('identity_import_input_invalid');}
    const hash=await mac(key,`phone:${normalized}`);check(!phones.has(hash));phones.set(hash,u.id);users.set(u.id,{id:u.id,hash});
  }
  const bindings=[],pairs=new Set();
  for(const b of mapping.bindings) {
    check(b&&Object.keys(b).sort().join(',')==='clubId,userId'&&users.has(b.userId)&&clubs.has(b.clubId));
    const pair=`${b.userId}:${b.clubId}`;check(!pairs.has(pair));pairs.add(pair);bindings.push(b);
  }
  const included=new Set(bindings.map(x=>x.userId)),statements=[];
  for(const c of clubs.values())statements.push({sql:'INSERT INTO auth_tenants(club_id,club_slug,enabled) VALUES (?,?,0)',params:[c.clubId,c.clubSlug]});
  for(const id of [...included].sort()) {
    const u=users.get(id);
    statements.push({sql:"INSERT INTO auth_identities(user_id,phone_hash,status,created_at) VALUES (?,?,'suspended',?)",params:[u.id,u.hash,now]});
    statements.push({sql:'INSERT INTO auth_source_identities(source_project,source_user_id,user_id,source_sha256) VALUES (?,?,?,?)',params:[mapping.sourceProject,u.id,u.id,expectedHash]});
  }
  for(const b of bindings)statements.push({sql:'INSERT INTO auth_identity_clubs(user_id,club_id,enabled) VALUES (?,?,0)',params:[b.userId,b.clubId]});
  return {schemaVersion:1,kind:'disabled-identity-import-plan',keyId:'v1',sourceSha256:expectedHash,
    mappingSha256:await sha(bindingBytes),createdAt:now,identityCount:included.size,bindingCount:bindings.length,
    excluded,unboundVerifiedCount:users.size-included.size,statements,
    executionPerformed:false,grantEnablingPerformed:false,approvalAuthenticated:false};
}
async function main() {
  const args=process.argv.slice(2);
  if(args.length!==4)throw new Error('Usage: prepare-identity-import.mjs users.private.json mappings.private.json expected-sha256 plan.private.json');
  const result=await prepareIdentityImport(readFileSync(args[0],'utf8'),readFileSync(args[1],'utf8'),args[2],process.env.PHONE_HMAC_KEY);
  writeFileSync(args[3],JSON.stringify(result,null,2)+'\n',{flag:'wx',mode:0o600});
  console.log(JSON.stringify({prepared:true,identities:result.identityCount,bindings:result.bindingCount,executed:false}));
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)main().catch(()=>{console.error('Import planning failed; no database action was performed. Check private input/schema/hash and output conflicts.');process.exitCode=1;});
