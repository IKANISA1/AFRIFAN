# Diagnostics retained separately from final source results

The first UI build attempt used an incorrect relative token-file path. It was
corrected and deterministic parity now passes. Initial operator tests could not
load the missing generated bundle; subsequent exact-source suites pass.

An initial synthetic browser fixture tried to delete retained snapshots to create
an empty state. The immutable database trigger correctly refused it. The harness
now starts an empty fixture without importing a snapshot; no retention guard was
weakened.

All 13 completed browser-case attempts failed at initial navigation because the
Chromium administrator policy returned ERR_BLOCKED_BY_ADMINISTRATOR for the
loopback preview. Browser policy was not modified or bypassed. The written browser
suite is not counted among passing tests and has not reached its interaction steps.
No failed browser screenshot is presented as an application screenshot.

The HTML review-reference pattern did not compile with the browser's Unicode-set
regular-expression syntax. Source tests reproduced this with the v flag; escaping
the literal slash and hyphen fixed it. Static pattern tests now pass.

Sequential all-bundle attempts exceeded this tool host's execution window during
installer tests. The same 33 independently isolated installer tests then passed in
six parallel slices. The final delivered verifier repeats every one of those test
names and all source tests; no test is skipped or made permissive.
