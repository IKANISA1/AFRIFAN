import test from 'node:test';import assert from 'node:assert/strict';
import {fixture,PHONE} from './support/fixture.mjs';
import {handler} from '../src/http.mjs';import {SupporterAuth} from '../src/service.mjs';
import {secret,sha} from '../src/crypto.mjs';
async function setup(t){const f=await fixture();t.after(()=>f.close());f.fetch=handler(()=>f.service);f.input={phone:PHONE,verifierHash:await sha(secret()),requestId:crypto.randomUUID()};return f;}
function req(f,path='otp/request',body=f.input,{headers={},origin=f.env.AUTH_ORIGIN,method='POST'}={}){
 return new Request(`${origin}/v1/auth/clubs/24/${path}`,{method,headers:{'content-type':'application/json','cf-connecting-ip':'192.0.2.1','x-africlub-auth':'native-v1',...headers},...(method==='GET'?{}:{body:typeof body==='string'?body:JSON.stringify(body)})});
}
test('HTTP request returns acknowledged state but never the verification secret',async t=>{const f=await setup(t),r=await f.fetch(req(f),f.env),b=await r.json();assert.equal(r.status,202);assert.equal(b.state,'sent');assert.deepEqual(Object.keys(b).sort(),['challengeId','clubId','expiresAt','schemaVersion','state']);assert.equal(r.headers.get('cache-control'),'no-store');assert.equal(r.headers.get('access-control-allow-origin'),null);});
for(const [label,path,opts,status] of [
 ['wrong method','otp/request',{method:'GET'},405],
 ['wrong host','otp/request',{origin:'https://evil.example.invalid'},403],
 ['HTTP transport','otp/request',{origin:'http://auth.example.invalid'},403],
 ['foreign Origin','otp/request',{headers:{origin:'https://evil.example.invalid'}},403],
 ['null Origin','otp/request',{headers:{origin:'null'}},403],
 ['cookie credentials','otp/request',{headers:{cookie:'session=untrusted'}},400],
 ['unrecognized action header','otp/request',{headers:{'x-africlub-auth':'web'}},400],
 ['oversize declaration','otp/request',{headers:{'content-length':'99999'}},413],
 ['bad content length','otp/request',{headers:{'content-length':'-1'}},413],
 ['wrong content type','otp/request',{headers:{'content-type':'text/plain'}},415],
 ['compressed payload','otp/request',{headers:{'content-encoding':'gzip'}},415],
 ['unknown operation','account/erase',{},404],
 ['unscoped query','otp/request?user_id=foreign',{},403],
])test(`HTTP rejects ${label}`,async t=>{const f=await setup(t),r=await f.fetch(req(f,path,f.input,opts),f.env);assert.equal(r.status,status);assert.equal(f.delivered.length,0);});
test('body bytes are bounded without trusting Content-Length',async t=>{const f=await setup(t),r=await f.fetch(req(f,'otp/request','x'.repeat(4097)),f.env);assert.equal(r.status,413);});
test('malformed JSON fails with a safe error',async t=>{const f=await setup(t),r=await f.fetch(req(f,'otp/request','{'),f.env);assert.equal(r.status,400);assert.deepEqual(await r.json(),{error:'invalid_request'});});
test('identity, role and unknown fields in request cannot be accepted',async t=>{const f=await setup(t),r=await f.fetch(req(f,'otp/request',{...f.input,userId:'foreign',role:'admin'}),f.env);assert.equal(r.status,400);assert.equal(f.delivered.length,0);});
test('missing direct-edge IP fails instead of sharing a global anonymous IP',async t=>{const f=await setup(t),r=req(f);r.headers.delete('cf-connecting-ip');const result=await f.fetch(r,f.env);assert.equal(result.status,503);});
test('network limit persists across requests and new codes',async t=>{const f=await setup(t);for(let i=0;i<120;i++)await f.service.networkLimit('192.0.2.2');await assert.rejects(f.service.networkLimit('192.0.2.2'),e=>e.status===429);});
test('current-session route requires actual bearer credential',async t=>{const f=await setup(t),r=await f.fetch(req(f,'sessions/current',null,{method:'GET',headers:{'x-user-id':'invented'}}),f.env);assert.equal(r.status,401);});
test('HTTP sign-in, rotate, current and logout execute the actual service',async t=>{
 const f=await setup(t),c=await f.request();let r=await f.fetch(req(f,'otp/verify',c.verify),f.env);assert.equal(r.status,200);const s=await r.json();
 r=await f.fetch(req(f,'sessions/refresh',{refreshToken:s.refreshToken,requestId:crypto.randomUUID()}),f.env);assert.equal(r.status,200);const n=await r.json();
 r=await f.fetch(req(f,'sessions/current',null,{method:'GET',headers:{authorization:`Bearer ${n.accessToken}`}}),f.env);assert.equal(r.status,200);
 r=await f.fetch(req(f,'sessions/logout',{scope:'current'},{headers:{authorization:`Bearer ${n.accessToken}`}}),f.env);assert.equal(r.status,200);
 r=await f.fetch(req(f,'sessions/current',null,{method:'GET',headers:{authorization:`Bearer ${n.accessToken}`}}),f.env);assert.equal(r.status,401);
});
test('raw database and provider errors never leave the HTTP boundary',async t=>{const f=await setup(t);f.service.requestOtp=async()=>{throw new Error('private phone +250700000001 secret SQL token');};const r=await f.fetch(req(f),f.env);assert.equal(r.status,503);assert.deepEqual(await r.json(),{error:'service_unavailable'});});
test('disabled runtime does not call the provider or database',async t=>{const f=await setup(t);const env={...f.env,AUTH_ENABLED:'false'};const r=await handler()(req(f),env);assert.equal(r.status,503);assert.equal(f.delivered.length,0);});
for(const change of [{PHONE_HMAC_KEY:'weak'},{OTP_HMAC_KEY:'missing'},{RESPONSE_ENCRYPTION_KEY:'bad'},{AUTH_KEY_ID:'v2'}])test(`runtime rejects invalid key configuration ${Object.keys(change)[0]}`,async t=>{const f=await setup(t);assert.throws(()=>new SupporterAuth({...f.env,...change}),e=>e.status===503);});
test('reuse of one key across cryptographic purposes is rejected',async t=>{const f=await setup(t);assert.throws(()=>new SupporterAuth({...f.env,OTP_HMAC_KEY:f.env.PHONE_HMAC_KEY}),e=>e.status===503);});
