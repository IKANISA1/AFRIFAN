/** Offline characterization, not a Cloudflare integration test. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import worker from './index.mjs';

const now = Date.now();
const fresh = new Date(now - 60_000).toISOString();
const old = new Date(now - 48 * 60 * 60_000).toISOString();
const mediaId = '11111111-1111-4111-8111-111111111111';
const news = {
  id: 'synthetic-news', approval_status: 'approved', active: true,
  visibility: 'public', status: 'published', post_type: 'news_feed',
  published_at: new Date(now - 60 * 60_000).toISOString(),
  title: 'Synthetic source item', excerpt: 'No real user or club content.',
  source_url: 'https://example.invalid/news', source_label: 'Synthetic source',
};
const asset = {approval_status:'approved', active:true, visibility:'public'};
const bytes = new TextEncoder().encode('synthetic-image');

// Implements only the SQL reads used by the exact, unmodified Worker.
function makeEnv({freshOtherRecord = false} = {}) {
  const records = [
    {source_table:'news_posts', captured_at_utc: old, payload_json:JSON.stringify(news)},
    {source_table:'media_assets', captured_at_utc: old, payload_json:JSON.stringify(asset)},
  ];
  if (freshOtherRecord) records.push({source_table:'prediction_teams', captured_at_utc:fresh, payload_json:'{}'});
  const queries = [];
  const db = {
    prepare(sql) {
      queries.push(sql);
      let args = [];
      const statement = {
        bind(...values) {args = values; return statement;},
        async all() {
          assert.match(sql, /SELECT payload_json FROM source_records WHERE source_table = \?/);
          return {results:records.filter(r=>r.source_table===args[0]).map(r=>({payload_json:r.payload_json}))};
        },
        async first() {
          if (sql.includes('MAX(captured_at_utc)')) {
            return {captured_at:records.map(r=>r.captured_at_utc).sort().at(-1)};
          }
          assert.match(sql, /FROM source_media m JOIN source_records r/);
          assert.equal(args[0], mediaId);
          return {
            bytes:bytes.byteLength, sha256:createHash('sha256').update(bytes).digest('hex'),
            usage_scopes_json:'["squad"]', usage_rights:'approved-for-publication',
            payload_json:JSON.stringify(asset),
          };
        },
      };
      return statement;
    },
  };
  const r2 = {async get(key) {
    assert.equal(key, `assets/${mediaId}.bin`);
    return {size:bytes.byteLength, body:bytes, writeHttpMetadata(headers){headers.set('content-type','image/png');}};
  }};
  return {env:{RAYON_PUBLIC_DB:db, RAYON_PUBLIC_MEDIA:r2},queries};
}

async function exercise(path, opts) {
  const {env,queries} = makeEnv(opts);
  const response = await worker.fetch(new Request(`https://example.invalid/v1/public/rayon/${path}`),env);
  const body = response.headers.get('content-type')?.includes('application/json') ? await response.json() : {bytes:(await response.arrayBuffer()).byteLength};
  return {status:response.status, body, freshnessQueryExecuted:queries.some(q=>q.includes('MAX(captured_at_utc)'))};
}

const staleNews = await exercise('news');
assert.equal(staleNews.status,503);
assert.equal(staleNews.body.error,'source_stale');
const mixedSnapshotNews = await exercise('news',{freshOtherRecord:true});
assert.equal(mixedSnapshotNews.status,200);
assert.equal(mixedSnapshotNews.body.rows[0].id,'gikundiro-synthetic-news');
const staleMedia = await exercise(`media/${mediaId}`);
assert.equal(staleMedia.status,200);
assert.equal(staleMedia.freshnessQueryExecuted,false);
console.log(JSON.stringify({
  scope:'Exact Worker source, synthetic in-memory D1/R2 read doubles. No real Cloudflare requests, database integration, private data, deployments or writes. Results characterize existing behavior; they do not establish a production incident. A partial refresh must be possible for the mixed-snapshot behavior to matter operationally.',
  nodeVersion:process.version,
  workerSha256:createHash('sha256').update(readFileSync(new URL('./index.mjs',import.meta.url))).digest('hex'),
  results:{staleNews,mixedSnapshotNews,staleMedia},
},null,2));
