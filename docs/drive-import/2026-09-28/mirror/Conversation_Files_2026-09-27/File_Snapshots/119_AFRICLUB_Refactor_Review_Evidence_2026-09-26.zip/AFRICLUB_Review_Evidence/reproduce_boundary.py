#!/usr/bin/env python3
"""Offline, isolated reproduction using the included unmodified source snapshots.

Requires Python 3, Node.js and git. Creates disposable git fixtures; never
executes the inventory script, contacts a backend, or changes a real repository.
"""
from __future__ import annotations
import hashlib
import json
import pathlib
import shutil
import subprocess
import tempfile

HERE = pathlib.Path(__file__).resolve().parent
VALIDATOR = HERE / 'validator-tests' / 'validate_repository_boundary.mjs'
INPUTS = (
    'docs/architecture/cloudflare-backend-migration-plan-2026-09-24.md',
    'docs/architecture/cloudflare-stage0-live-inventory-2026-09-24.md',
    'tools/scripts/inventory_cloudflare_migration.py',
)
REQUIRED = (
    'packages/features/feat_gamification/lib/src/predict/predict_module.dart',
    'packages/features/feat_gamification/lib/src/repositories/prediction_repository.dart',
    'supabase/migrations/20260820080202_football_only_baseline.sql',
    'supabase/tests/repository_boundary_contract.sql',
)
MODULES = ('ClubModule()', 'PredictModule()', 'LiveModule()', 'MembershipModule()', 'TicketingModule()', 'ShopModule()')

def run_case(relative: str | None) -> dict:
    with tempfile.TemporaryDirectory(prefix='africlub-boundary-review-') as folder:
        root = pathlib.Path(folder)
        subprocess.run(['git', 'init', '-q'], cwd=root, check=True, capture_output=True)
        for name in REQUIRED:
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('', encoding='utf-8')
        registry = root / 'packages/app_registry/lib/src/module_registry.dart'
        registry.parent.mkdir(parents=True, exist_ok=True)
        registry.write_text('\n'.join(MODULES), encoding='utf-8')
        (root / '.gitignore').write_text('build/\nnode_modules/\noutput/\n', encoding='utf-8')
        digest = None
        if relative:
            source = HERE / 'collision-inputs' / relative
            target = root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            digest = hashlib.sha256(source.read_bytes()).hexdigest()
        process = subprocess.run(['node', str(VALIDATOR)], cwd=root, text=True, capture_output=True, timeout=30)
        return {'case':relative or 'minimal valid fixture', 'input_sha256':digest,
                'exit_code':process.returncode, 'stdout':process.stdout, 'stderr':process.stderr}

def main() -> None:
    for tool in ('node', 'git'):
        if not shutil.which(tool):
            raise SystemExit(f'Required executable not found: {tool}')
    results = [run_case(None)] + [run_case(name) for name in INPUTS]
    report = {
        'scope':'Isolated boundary-validator reproductions against exact source files. NOT a full repository build, CI run, migration or deployed-system test. Required unrelated repository files are minimal fixture placeholders. No network calls or production changes were made.',
        'node_version':subprocess.check_output(['node','--version'],text=True).strip(),
        'validator_sha256':hashlib.sha256(VALIDATOR.read_bytes()).hexdigest(),
        'results':results,
    }
    destination = HERE / 'boundary_reproduction.json'
    destination.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))
    expected = [0,1,1,1]
    if [row['exit_code'] for row in results] != expected:
        raise SystemExit('Observed behavior differs from the reviewed snapshot. Inspect the report.')

if __name__ == '__main__':
    main()
