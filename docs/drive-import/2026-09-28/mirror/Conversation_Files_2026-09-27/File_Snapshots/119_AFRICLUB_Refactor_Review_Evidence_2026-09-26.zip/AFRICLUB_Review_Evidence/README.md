# AFRICLUB — bounded refactoring-review evidence

Review date: 26 September 2026.
Source: the AFRICLUB Google Drive repository supplied by the owner.

## What was actually executed

1. The supplied repository-boundary validator's six existing Node tests: six passed.
2. The same unmodified validator in four disposable git fixtures: the minimal control passed; each of the two current migration documents and the inventory script was rejected for an unsupported ownership token.
3. The unmodified Rayon public Worker with synthetic D1/R2 read doubles: an entirely old snapshot's news endpoint returned 503; an old news snapshot plus one recent unrelated source record returned 200; an old media snapshot returned 200 without executing the freshness query.

The Worker result describes code behavior, not a demonstrated production incident. The mixed-snapshot risk requires partially refreshed records to coexist; the test does not establish that this occurs in the deployed ingestion process. It is a production-readiness test to add. Media freshness may intentionally differ from text freshness, but its policy needs to be explicit.

## Scope limits

These are focused reproductions, not full-checkout CI or Cloudflare integration tests. Node v22.16.0 was used, not the repository's full pinned build toolchain. Dart/Flutter, mobile builds, Next.js production builds, pgTAP, real D1 transaction tests, providers, physical devices and live deployment status were not tested in this review. No Drive file, production database, billing setting or deployment was changed.

The fixture's required unrelated source files are placeholders. The downloaded validator, collision inputs and Worker are unchanged snapshots. Do not interpret the fixture as a replacement repository.

## Reproduce locally

```sh
node --test validator-tests/validate_repository_boundary.test.mjs
python3 reproduce_boundary.py
node worker-tests/freshness_reproduction.mjs
```

Run from this unpacked directory. Only the Node tests and reproduction scripts are intended to execute. The inventory Python file under collision-inputs is text input for the boundary scan: do not run it as part of this review.

## Recommended corrections

Keep the runtime ownership gate strict, but distinguish governed migration/disposition references from runtime feature ownership. Do not bypass the gate globally or delete the inventory to make CI green. Add the exact colliding files to regression fixtures and retain negative tests for actual unsupported runtime code.

For the staging Worker, publish complete approved snapshots by an atomic active snapshot ID, validate their manifest age/completeness, and define whether media approval freshness and cache expiry follow the same or a separate bounded policy. Preserve read-only routes, rights checks and all disabled transaction flags.

The attached JSON reports and TAP log record the observations. SHA256SUMS.json identifies the delivered source and evidence bytes.
