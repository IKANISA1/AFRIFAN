# AFRICLUB Batch 12 — iOS recovery counterpart

13 additive source files based on the checked current native contract. None has
been uploaded to Drive in this turn: no upload/update action is exposed. See the
upload-pending register. Existing Drive files and all production runtimes are unchanged.

The package contains the exact source payload in `files/`, supporting prior source
in `context/`, checksums, test evidence and a reversible installer. `context/` is
not payload: do not copy it over a newer checkout. This is not cumulative v1-v4.

Run `python3 apply_patch.py --root /path/to/AFRICLUB` for a read-only preflight, then
add `--apply` only against a matching authorized local checkout. Unknown edits stop
the installer. It performs no network, SQL, payment, Keychain, app registration or
deployment work. Individual writes are atomic, not one global source transaction.

`python3 verify_bundle.py --results /tmp/africlub-batch12` runs local regression and
portable checks. Exit 2 marks unresolved real native acceptance, even after portable
success. The source verifier `tools/scripts/verify_ios_recovery.py` runs only the
portable Swift subset. Its tests use unprotected test backends, not Apple Keychain.

68 new portable Swift tests passed. Seven real-Keychain XCTest cases were authored
but not run. The iOS host and Dart bridge are disabled and not registered in any app.
