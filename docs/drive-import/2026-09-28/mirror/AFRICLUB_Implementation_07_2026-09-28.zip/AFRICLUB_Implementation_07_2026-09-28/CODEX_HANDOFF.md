# AFRICLUB Implementation 07 — source handoff

## Baseline and changed paths

Continue the reviewed Implementation 06 candidate. This is a 35-path delta:10 new and25 modified,
with394 scoped source files and359 unchanged prerequisites. `source/` is a test subset, NOT a full
repository. `files/` is the installable delta; `before/` preserves modified originals.

Read REPORT.md, VERIFICATION.json, manifest.json, SOURCE_PROVENANCE.json, TASK_REGISTER.json and
cloudflare/payment-allocation/MEMBERSHIP_HISTORY.md before integration. All130 tasks remain
unaccepted. Drive upload is pending; do not treat these local files as an uploaded release.

## Safe source installation (no cloud effects)

```sh
python3 install.py --root /path/to/reviewed/AFRICLUB
python3 install.py --root /path/to/reviewed/AFRICLUB --apply
# Use the exact rollback_directory returned by apply, not a guessed path:
python3 install.py --root /path/to/reviewed/AFRICLUB --rollback /path/from/apply/result
```

Default is dry-run. Exit2 means conflict or blocked validation, not success. Stop editors and
builds during application. Unknown changes remain untouched. Do not bypass the version0003
migration conflict or replay an old cumulative patch over newer source. No installer runs SQL.

## Verification from the actual repository

```sh
python3 tools/scripts/verify_converged_source.py --profile complete --results /tmp/africlub-07-gates
python3 tools/scripts/check_migration_lineage.py --root .
python3 tools/scripts/verify_native_membership.py --results /tmp/africlub-07-dart
```

Use the unchanged required runtime pins; this delivery's non-pinned Node run is scoped local
evidence only. The exact80-file Node command is in evidence/node-command.json. The new tests are:

- cloudflare/payment-allocation/tests/membership-history.test.mjs
- cloudflare/supporter-membership-api/tests/history.test.mjs
- cloudflare/supporter-browser-api/tests/history.test.mjs
- cloudflare/supporter-web-router/tests/notifications.test.mjs

The new pure-Dart history harness is registered but unexecuted here. Build the real Flutter/native
hosts and integrate the optional NativeMembershipHistoryApi in governed app compositions; do not
count portable Swift/Kotlin harnesses as that work.

## Environment and migration requirements

Resolve the actual hosted financial migration lineage first. Migration0005 only adds a partial
history-read index; its presence is required by the new query. Apply forward-only through the
approved migration workflow, then validate real D1 query plans/latency and private reader methods.
Keep the shipped switches disabled until the relevant checks pass. History adds no financial
mutation or notification-sending capability.

Validate both native and browser GET list/detail paths, exact-scope ownership, private headers,
forbidden bodies/queries/keys, and disabled-creation read-only operation. Test older imported
orders with genuine retained receipt rows, not fabricated payment evidence. Compare actual
provider/account evidence separately; the ledger-history endpoint cannot establish settlement.

## Rendered acceptance required

Build pinned React/Next/OpenNext with the real repository dependencies. Run permitted browser
checks at the configured same-origin host. Exercise sign-in -> Latest history -> Older -> receipt
-> logout, storage failures, disabled checkout, current suspension, BFCache/offline/cross-tab and
service-worker update. Check keyboard, screen readers, large text and desktop/mobile layout.
No browser screenshot/visual acceptance exists from this delivery.

Notification sender payloads must adopt the narrowed landing-page protocol: only admin,
membership, news, fixtures, results and support. Raw lock-screen bodies and arbitrary deep links
are intentionally not rendered. Verify permission/subscription ownership and sender delivery on
actual browsers; receiving-side VM tests do not cover provider sending or tenant token lifecycle.

## Delivery

DELIVERY_STATUS.json states the exact current limitation: the connected Drive action set is
read-only in this session. The outer UPLOAD_PENDING manifest identifies the intended same folder,
local deliverables and hashes. Do not invent Drive IDs or a successful upload receipt.
