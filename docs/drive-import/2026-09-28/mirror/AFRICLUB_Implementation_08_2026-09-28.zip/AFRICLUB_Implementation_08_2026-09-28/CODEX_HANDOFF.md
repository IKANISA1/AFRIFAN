# Implementation 08 handoff

Use the exact reviewed Implementation 07 source baseline. The source candidate is a subset, not a complete repository; do not replace your monorepo with `source/`. Source deployment remains unapproved.

```sh
python3 install.py --root /path/to/reviewed/AFRICLUB
python3 install.py --root /path/to/reviewed/AFRICLUB --apply
```

Stop concurrent editors/builds before application. Save the returned rollback directory. Roll back with `python3 install.py --root /path/to/reviewed/AFRICLUB --rollback <recorded-directory>`. Unknown independent edits are refused, including during rollback.

Review `files/cloudflare/allocation-delivery/README.md`, `manifest.json`, `SOURCE_PROVENANCE.json` and `VERIFICATION.json`. The automatic installer never applies SQL, changes Drive permissions or enables cloud services.

Run these source checks from the repository root with the required Node 22.23.2 and supported native SDKs:

```sh
node --test cloudflare/allocation-delivery/tests/*.test.mjs
node cloudflare/allocation-delivery/scripts/check-deployment.mjs
python3 tools/scripts/verify_converged_source.py --profile complete --results /tmp/africlub08-verification
```

Before hosted testing, reconcile the financial migration history. The new `0006_reliable_event_delivery.sql` belongs to the existing reviewed allocation DB; `allocation-delivery/migrations/0001_operations_inbox.sql` belongs to a separate new isolated inbox DB. Check exact resource IDs, location/retention approvals, consumer UUID, fixed service principals, per-club grants and source/sink separation. No placeholders are deployment approvals.

Freeze the legacy outbox executable, review previous attempted/delivered events without replaying them, and enable only explicitly approved never-attempted events. All shipped switches are disabled, with no routes, previews or Cron schedule. Adopted events cannot be processed by the old claim/ack path. A dead-letter re-drive uses the SAME source event ID with an explicit original operation ID, expected revision and separate review principal.

Add the real Access-authorized operator adapter before using the private review/inbox reader in an admin screen; this package does not supply named human authorization. Only an approved dispatcher should receive the source finish binding. The sink's concrete effect is an operational record, not a payment, refund, contribution fulfillment or notification delivery.

Complete real D1/RPC/lost-response tests, load and retention review and a single scheduler-owner rehearsal before deployment. Review the remaining 130-task register; local tests do not close its broader release requirements.
