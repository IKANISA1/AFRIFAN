# AFRICLUB implementation 03 — integration handover

## Source authority

This is a **25-path delta against the exact Remediation 02 scoped candidate**, not a full monorepo. `source/` contains 322 selected files for inspection/testing, not every Flutter/Next dependency or app shell. Do not replace a full checkout with this directory. Do not apply the older cumulative package blindly over the root Drive source.

Read `SOURCE_PROVENANCE.json`, `manifest.json`, `IMPLEMENTATION_REPORT.md` and `source/cloudflare/payment-exceptions/README.md` first. Preserve the user’s football-first product scope, five-club tenancy, existing membership/payment controls and human approval. No live migration, provider action, ACL change or financial operation is authorized by the included scripts.

## Integrate

1. Establish a protected checkout of the selected Remediation 02 source. Independently reconcile any drift and the two competing payment handoff 0003 migrations. Do not edit historic SQL or bypass checksum failures.
2. Stop editors/builds. Run the wrapper below, inspect its paths, then apply only when it accepts every source prerequisite. It changes no hosted resource.

```sh
python3 install.py --root /absolute/path/to/AFRICLUB
python3 install.py --root /absolute/path/to/AFRICLUB --apply
# To restore exactly this application, use the rollback_directory returned above:
python3 install.py --root /absolute/path/to/AFRICLUB --rollback /absolute/path/to/AFRICLUB/output/refactor-backups/RETURNED_DIRECTORY
```

3. Rerun local source/gateway/case tests and then the complete repository’s pinned Flutter, Next.js, device, provider and real Cloudflare tests. The local delivery used Node 22.16.0, not the existing 22.23.2 pin. Do not change the pin merely to make that evidence look compliant.

```sh
cd /absolute/path/to/AFRICLUB
node --test cloudflare/*/tests/*.test.mjs tools/scripts/*.test.mjs
(cd tools/scripts && python3 -m unittest discover -p 'test_*.py')
node cloudflare/payment-exceptions/scripts/check-deployment.mjs
node cloudflare/operator-api/scripts/check-deployment.mjs
python3 tools/scripts/check_migration_lineage.py --root .
```

## Finish app acceptance without inventing financial authority

Implement the admin case list/detail/review screen using `PaymentCaseClient`. Keep explicit expected revisions; require a different checker; never retry an uncertain command with a new key. Keep case review separate from actual financial reconciliation and refunds. Do not call the service’s case-close state payment/refund completion. No case UI is provided or visually approved in this package.

Only after owner approval, configure an isolated case D1 database and real club/operator grants. The migration, Access account/audience, runtime switches, SQL enable control and private binding require independent readback. Never deploy the all-zero database placeholder. The gateway must remain the sole trusted identity issuer for the case RPC service. Real Access and D1 behavior is not proven by the local adapters.

Keep every task in TASK_REGISTER.json open/in-progress until its actual acceptance evidence exists. Record canonical commit, SDK-pinned logs, UI/device evidence, approved migration plan and deployment receipt separately. Uploading this ZIP is not such evidence.
