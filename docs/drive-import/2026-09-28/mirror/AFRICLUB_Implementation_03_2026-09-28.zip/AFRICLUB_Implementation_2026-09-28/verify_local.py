#!/usr/bin/env python3
"""Run the scoped local suites; writes logs only. Never installs dependencies or deploys."""
import argparse,json,shutil,subprocess,sys
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--results',type=Path,required=True);a=p.parse_args();a.results.mkdir(parents=True,exist_ok=True)
 root=Path(__file__).resolve().parent;source=root/'source'
 missing=[x for x in ['node','tsc'] if shutil.which(x) is None]
 if missing:print(json.dumps({'blocked':missing,'releaseAccepted':False}));return 2
 groups=[('node',['node','--test',*[str(x) for x in sorted(source.glob('cloudflare/*/tests/*.test.mjs'))],*[str(x) for x in sorted(source.glob('tools/scripts/*.test.mjs'))]],source),
 ('python',[sys.executable,'-m','unittest','discover','-v','-p','test_*.py'],source/'tools/scripts'),
 ('installer',[sys.executable,'-m','unittest','discover','-v','-s',str(root/'tests')],root)]
 runs=[]
 for name,cmd,cwd in groups:
  with (a.results/(name+'.log')).open('w') as log:
   result=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
  runs.append({'name':name,'exitCode':result.returncode})
 report={'runs':runs,'passed':all(x['exitCode']==0 for x in runs),'releaseAccepted':False,'deploymentPerformed':False}
 (a.results/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
