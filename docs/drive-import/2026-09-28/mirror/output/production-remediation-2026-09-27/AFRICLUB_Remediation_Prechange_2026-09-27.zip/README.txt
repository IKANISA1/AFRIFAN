Read-only current source backup for scoped production remediation. Not a full repository, secret export or production database backup.
