"""Isolated exact-source validator probes. Creates only temporary local Git fixtures."""
from pathlib import Path
import tempfile, subprocess, json, hashlib
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'current/validate_repository_boundary.mjs.js').read_bytes()
required=['packages/features/feat_gamification/lib/src/predict/predict_module.dart','packages/features/feat_gamification/lib/src/repositories/prediction_repository.dart','supabase/migrations/20260820080202_football_only_baseline.sql','supabase/tests/repository_boundary_contract.sql']
results=[]
for name,extra in [('baseline',None),('current_migration_plan','cloudflare-backend-migration-plan-2026-09-24.md'),('current_live_inventory','cloudflare-stage0-live-inventory-2026-09-24.md')]:
 with tempfile.TemporaryDirectory(prefix='africlub-boundary-audit-') as d:
  root=Path(d)
  for path in required:
   p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('// synthetic required capability\n' if p.suffix=='.dart' else '-- synthetic required capability\n')
  p=root/'packages/app_registry/lib/src/module_registry.dart';p.parent.mkdir(parents=True);p.write_text('ClubModule(); PredictModule(); LiveModule(); MembershipModule(); TicketingModule(); ShopModule();\n')
  (root/'validator.mjs').write_bytes(source)
  if extra:
   p=root/'docs/architecture'/extra;p.parent.mkdir(parents=True);p.write_bytes((ROOT/'current'/extra).read_bytes())
  subprocess.run(['git','init','-q'],cwd=root,check=True)
  r=subprocess.run(['node','validator.mjs'],cwd=root,capture_output=True,text=True,timeout=30)
  results.append({'fixture':name,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
report={'kind':'isolated fixture, not a full-repository CI execution','validatorSha256':hashlib.sha256(source).hexdigest(),'results':results}
(ROOT/'evidence/boundary_probe_results.json').write_text(json.dumps(report,indent=2)+'\n')
assert [r['exitCode'] for r in results]==[0,1,1]
print(json.dumps(report,indent=2))
