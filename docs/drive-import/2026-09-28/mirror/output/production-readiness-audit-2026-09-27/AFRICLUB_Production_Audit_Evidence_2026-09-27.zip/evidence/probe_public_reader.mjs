/** Read-only isolated probes against exact downloaded source. No network or real data. */
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const base = new URL('../', import.meta.url);
const bytes = await readFile(new URL('current/index.mjs.js', base));
const {default: worker} = await import(`data:text/javascript;base64,${bytes.toString('base64')}`);
const now = Date.now(), old = new Date(now-72*3600000).toISOString(), recent = new Date(now).toISOString();
const assetId = '11111111-1111-4111-8111-111111111111';
const real = new TextEncoder().encode('good'), wrong = new TextEncoder().encode('evil');
const results=[];
function db(capture,media=false){const queries=[];return {queries,prepare(sql){queries.push(sql);return {bind(){return this;}, async first(){
 if(sql.includes('MAX(captured_at_utc)'))return {captured_at:capture};
 if(sql.includes('source_media m'))return {bytes:4,sha256:createHash('sha256').update(real).digest('hex'),usage_scopes_json:'["shop"]',usage_rights:'approved-commercial-use',payload_json:JSON.stringify({approval_status:'approved',active:true,visibility:'public'})};
 return null;},async all(){return {results: sql.includes('payload_json FROM source_records')?[{payload_json:JSON.stringify({id:'22222222-2222-4222-8222-222222222222',approval_status:'approved',active:true,visibility:'public',status:'published',post_type:'news_feed',published_at:old,title:'Synthetic stale-source item',excerpt:'Synthetic source record captured 72 hours ago',source_url:'https://example.invalid/news'})}]:[]};}};}};}
for(const [name,captured] of [['all_source_records_stale',old],['unrelated_record_fresh_but_news_source_stale',recent]]){
 const database=db(captured);const response=await worker.fetch(new Request('https://example.invalid/v1/public/rayon/news'),{RAYON_PUBLIC_DB:database});
 results.push({name,conditions:{newsSourceCapturedAt:old,maximumAnyRecordCapturedAt:captured},status:response.status,body:await response.json(),queries:database.queries});
}
for(const [name,content] of [['stale_snapshot_media',real],['same_length_media_hash_mismatch',wrong]]){
 const database=db(old,true); const response=await worker.fetch(new Request('https://example.invalid/v1/public/rayon/media/'+assetId),{RAYON_PUBLIC_DB:database,RAYON_PUBLIC_MEDIA:{async get(){return {size:4,body:content,writeHttpMetadata(h){h.set('content-type','image/png');}};}}});
 const returned = new Uint8Array(await response.arrayBuffer());
 results.push({name,status:response.status,freshnessQueryExecuted:database.queries.some(q=>q.includes('captured_at')),expectedSha256:createHash('sha256').update(real).digest('hex'),returnedSha256:createHash('sha256').update(returned).digest('hex'),cacheControl:response.headers.get('cache-control')});
}
const report={schemaVersion:1,performedAt:new Date().toISOString(),sourceFileId:'11HjHNGCFck0SiQGNHOWljw4Q-nxeMIPw',sourceSha256:createHash('sha256').update(bytes).digest('hex'),kind:'synthetic isolated exact-source behavior probes',networkCalls:0,deployedBehaviorVerified:false,results};
await writeFile(new URL('evidence/public_reader_probe_results.json',base),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
