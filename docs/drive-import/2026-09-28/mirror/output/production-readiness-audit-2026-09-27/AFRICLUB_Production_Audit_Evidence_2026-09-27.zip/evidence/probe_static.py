"""Static-only current-source inspection. Does not install dependencies or deploy."""
from pathlib import Path
import json,re,yaml
R=Path(__file__).resolve().parents[1];C=R/'current';E=R/'evidence'
ci=yaml.safe_load((C/'ci.yaml').read_text());deploy=yaml.safe_load((C/'deploy-gikundiro-web.yml').read_text())
job=next(iter(deploy['jobs'].values()));raw=(C/'ci.yaml').read_text()
terms=['supporter-auth','auth-code-delivery','payment-allocation','operator-api','supporter-membership-api','verify_android_recovery','verify_native_membership','verify_ios_recovery']
r={'ciJobs':list(ci['jobs']),'newCloudflareModuleMentions':{v:v in raw for v in terms},'deployHasNeeds':'needs' in job,'deployHasEnvironmentGate':'environment' in job,'deployRuns':[s['run'] for s in job['steps'] if 'run' in s],'nextIgnoresTypeErrors':bool(re.search(r'ignoreBuildErrors:\s*true',(C/'next.config.ts').read_text())),'externalBranchAndEnvironmentSettingsVerified':False}
(E/'ci_static_findings.json').write_text(json.dumps(r,indent=2)+'\n')
m=json.loads((C/'package.json').read_text());l=json.loads((C/'package-lock.json').read_text());diff=[]
for k in ['dependencies','devDependencies']:
 for dep in set(m.get(k,{}))|set(l['packages'][''].get(k,{})):
  if m.get(k,{}).get(dep)!=l['packages'][''].get(k,{}).get(dep):diff.append([k,dep,m.get(k,{}).get(dep),l['packages'][''].get(k,{}).get(dep)])
r={'lockfileVersion':l['lockfileVersion'],'packageCount':len(l['packages']),'manifestRootDifferences':diff,'resolvedTopDependencies':{k:l['packages']['node_modules/'+k]['version'] for k in ['next','react','react-dom','wrangler','@opennextjs/cloudflare']},'npmInstallOrAdvisoryAuditExecuted':False}
(E/'dependency_manifest_probe.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
