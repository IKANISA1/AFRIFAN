AFRICLUB production-readiness audit evidence — 27 September 2026

This pack contains the selected current source bytes, their hashes, isolated probe scripts/results, and task/source registers. It is NOT a complete repository export, fresh security scan, live D1 test or production sign-off. No environment-secret or keystore contents were retrieved.

From the extracted audit evidence root:
  node evidence/probe_public_reader.mjs
  python evidence/probe_boundary.py
  python evidence/probe_static.py

These scripts use temporary/synthetic data and selected source files. Python static probe requires PyYAML. They do not deploy, write to Drive, change permissions, call a real endpoint, or process payments.

Source integrity: hashes prove the collected bytes, not independent trust of a publicly writable workspace. The owner should contain public-write access and reconcile a trusted Git baseline.
