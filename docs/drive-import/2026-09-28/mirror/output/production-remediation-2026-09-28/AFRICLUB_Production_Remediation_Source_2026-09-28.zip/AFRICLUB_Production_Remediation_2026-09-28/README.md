# AFRICLUB production-remediation source package

28 September 2026. Implemented and tested locally; **not uploaded, deployed or
production-approved**. Start with `IMPLEMENTATION_REPORT.md` and `VERIFICATION.json`.

- `files/`:169 exact repository-relative overlay entries. This includes57 new/revised
  files in this continuation and112 selected earlier patch/dependency paths.
- `context/`:178 selected before/unchanged source files for repeatable verification;
  **not the complete repository and not a directory to copy into production**.
- `manifest.json`:before/after hashes, recognized prior versions and113 untouched
  prerequisites. `source_reconciliation.json` differentiates fresh vs inherited data.
- `apply_patch.py`:read-only preflight by default; exact-source application and rollback.
- `verify_bundle.py`:independent contracts, installer and portable/native phases.
- `AFRICLUB_Production_Task_Register_Updated_2026-09-28.json`:all130original tasks and
  their acceptance criteria;21partial implementations,109Open,zeroacceptedClosed.
- `UPLOAD_PENDING.json`:intended source and deliverable destinations; no upload claim.
- `evidence/`:actual final logs and blocked-gate records; no SDK/keys/fonts included.
- `audit_reference/`:unchanged prior audit originals, not rerun or revised findings.

Preserve source history. Stop editors/builds before an application. Unknown edits
must be reconciled, not forced. The payload leaves financial/runtime promotion
switches disabled. It does not make original and target backends simultaneous writers.

Run `python3 apply_patch.py --root /path/to/AFRICLUB`, then only after reviewing a
clean preflight run the same command with `--apply`. The returned rollback journal
restores the exact before bytes; retain it. Run `verify_bundle.py --phase contracts`,
`--phase installer`, and `--phase native` with separate `--results` directories.

The current host cannot provide the required pinned Node/Dart/Flutter/Apple/Android
or managed-browser acceptance. Tests run on installed tools are scoped evidence,
not grounds for enabling production. Drive upload and ACL changes remain unperformed.
