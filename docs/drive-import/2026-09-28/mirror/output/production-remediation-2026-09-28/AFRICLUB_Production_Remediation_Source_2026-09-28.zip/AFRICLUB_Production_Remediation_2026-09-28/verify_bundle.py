#!/usr/bin/env python3
"""Verify scoped source and reversible installation offline. Never deploys or enables.

Missing pinned Node/Dart produces BLOCKED (exit 2), not release approval. Contracts
can still run on an installed Node as explicitly non-pinned evidence. --phase lets
resource-constrained hosts run independent phases without counting partial runs.
"""
from __future__ import annotations
import argparse,hashlib,importlib.util,json,re,shutil,subprocess,sys,tempfile,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
B=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--results',type=Path,required=True);p.add_argument('--phase',choices=['all','contracts','installer','native'],default='all');a=p.parse_args();out=a.results.resolve();out.mkdir(parents=True,exist_ok=True)
 steps=[];totals={};blocked=[];trials=[]
 def run(name,command,cwd=B,allowed=(0,),timeout=240):
  started=time.monotonic()
  try:r=subprocess.run(command,cwd=cwd,text=True,capture_output=True,timeout=timeout)
  except (OSError,subprocess.SubprocessError) as e:
   (out/(name+'.log')).write_text(type(e).__name__+': '+str(e)+'\n');raise RuntimeError(name+' did not finish') from e
  text=r.stdout+r.stderr;(out/(name+'.log')).write_text(text)
  steps.append({'name':name,'exitCode':r.returncode,'elapsedSeconds':round(time.monotonic()-started,2)})
  if r.returncode not in allowed:raise RuntimeError(name+' failed; see log')
  return text,r.returncode
 catalog=B/'bundle_checksums.json'
 if catalog.exists():
  for name,h in json.loads(catalog.read_text()).items():
   rel=Path(name)
   if rel.is_absolute() or '..' in rel.parts or (B/rel).is_symlink() or digest(B/rel)!=h:raise RuntimeError('Bundle integrity failed: '+name)
 manifest=json.loads((B/'manifest.json').read_text());entries=manifest['entries']
 def assemble(root):
  shutil.copytree(B/'context',root)
  run('scoped-source-apply',[sys.executable,str(B/'apply_patch.py'),'--root',str(root),'--apply'])
  for e in entries:
   if digest(root/e['path'])!=e['after_sha256']:raise RuntimeError('Applied source hash mismatch')
  return root
 with tempfile.TemporaryDirectory(prefix='africlub-remediation-') as tmp:
  base=Path(tmp)
  if a.phase in ('all','installer'):
   root=base/'installer-trial'
   for label,preset in [('selected-known-hash-baseline',[]),('alternating-changes-already-present',entries[::2]),('all-source-already-matching',entries)]:
    if root.exists():shutil.rmtree(root)
    shutil.copytree(B/'context',root)
    for e in preset:
     d=root/e['path'];d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(B/'files'/e['path'],d)
    before={p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file()}
    args=[sys.executable,str(B/'apply_patch.py'),'--root',str(root)]
    pre=json.loads(run(label+'-preflight',args)[0]);applied=json.loads(run(label+'-apply',args+['--apply'])[0]);again=json.loads(run(label+'-repeat',args+['--apply'])[0])
    if again['status']!='already_applied':raise RuntimeError('Installer repeat changed source')
    for e in entries:
     if digest(root/e['path'])!=e['after_sha256']:raise RuntimeError('Wrong installed hash')
    if applied.get('rollback_directory'):run(label+'-rollback',args+['--rollback',applied['rollback_directory']])
    for name,data in before.items():
     if (root/name).read_bytes()!=data:raise RuntimeError('Rollback did not restore '+name)
    for e in entries:
     if e['path'] not in before and (root/e['path']).exists():raise RuntimeError('Rollback retained unexpected source')
    trials.append({'scenario':label,'sourceFilesChanged':pre['source_files_to_change'],'startingBytesRestored':True})
   # Unknown edits must stop preflight and remain unmodified.
   conflict=root/'pubspec.yaml';conflict.write_text(conflict.read_text()+'\n# independent local edit\n');before=conflict.read_bytes()
   _,code=run('unknown-edit-preservation',[sys.executable,str(B/'apply_patch.py'),'--root',str(root),'--apply'],allowed=(2,))
   if conflict.read_bytes()!=before:raise RuntimeError('Unknown edit overwritten')
   methods=re.findall(r'^    def (test_[a-z0-9_]+)\(', (B/'tests/test_patch_installer.py').read_text(),re.M)
   def part(start):
    group=['test_patch_installer.PatchInstallerTests.'+n for n in methods[start:start+6]]
    text,_=run('installer-unit-'+str(start//6),[sys.executable,'-m','unittest','-v',*group],cwd=B/'tests',timeout=90)
    return int(re.search(r'Ran (\d+) tests',text).group(1))
   with ThreadPoolExecutor(max_workers=6) as pool:totals['installer']=sum(pool.map(part,range(0,len(methods),6)))
  if a.phase in ('all','contracts','native'):
   root=assemble(base/'candidate')
  if a.phase in ('all','contracts'):
   modules=['rayon-public','operator-api','supporter-auth','auth-code-delivery','payment-allocation','supporter-membership-api']
   tests=sorted(str(f) for module in modules for f in (root/'cloudflare'/module/'tests').glob('*.test.mjs'))
   tests += [str(root/'tools/scripts'/n) for n in ['validate_repository_boundary.test.mjs','validate_predict_economics_contract.test.mjs']]
   text,_=run('node-contracts',['node','--test',*tests],cwd=root)
   for k in ['fail','cancelled','skipped','todo']:
    if not re.search('^# '+k+' 0$',text,re.M):raise RuntimeError('Incomplete Node suite')
   totals['node']=int(re.search(r'^# pass (\d+)$',text,re.M).group(1))
   text,_=run('python-source-contracts',[sys.executable,'-m','unittest','-v','test_supporter_sms_boundary','test_public_snapshot_import','test_migration_release','test_release_artifact','test_release_evidence','test_ci_contract','test_sensitive_source'],cwd=root/'tools/scripts')
   totals['python']=int(re.search(r'Ran (\d+) tests',text).group(1))
   commands=[('operator-assets','cloudflare/operator-api/scripts/build-ui.mjs',['--check']),('operator-config','cloudflare/operator-api/scripts/check-deployment.mjs',[]),('allocation-config','cloudflare/payment-allocation/scripts/check-deployment.mjs',[]),('checkout-config','cloudflare/payment-allocation/scripts/check-checkout-deployment.mjs',[]),('gateway-config','cloudflare/supporter-membership-api/scripts/check-deployment.mjs',[]),('delivery-config','cloudflare/auth-code-delivery/scripts/check-deployment.mjs',[]),('receipt-config','cloudflare/auth-code-delivery/scripts/check-receipts-deployment.mjs',[]),('client-ts','cloudflare/supporter-membership-api/scripts/compile-client.mjs',[]),('handoff-ts','cloudflare/supporter-membership-api/scripts/compile-handoff.mjs',[])]
   for name,script,args in commands:run(name,['node',script,*args],cwd=root)
   spec=importlib.util.spec_from_file_location('source_guard',root/'tools/scripts/check_sensitive_source.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
   names=sorted({e['path'] for e in entries}|{e['path'] for e in manifest['preconditions']});scan=guard.inspect(root,names);(out/'scoped-sensitive-source.json').write_text(json.dumps(scan,indent=2)+'\n')
   if not scan['passed']:raise RuntimeError('Sensitive source check failed')
   actual=subprocess.check_output(['node','-p','process.versions.node'],text=True).strip();expected=(root/'.nvmrc').read_text().strip()
   if actual!=expected:blocked.append({'gate':'node-pin','expected':expected,'actual':actual})
  if a.phase in ('all','native'):
   for name,script,report,key in [('kotlin','verify_android_recovery.py','android-recovery-verification.json','portableJvmTestsPassed'),('swift','verify_ios_recovery.py','ios-recovery-verification.json','portableTestsPassed')]:
    _,code=run('portable-'+name,[sys.executable,str(root/'tools/scripts'/script),'--results',str(out/name)],cwd=root,allowed=(0,2))
    native=json.loads((out/name/report).read_text())
    if code==0:totals[name]=native[key]
    else:blocked.append({'gate':name,'reason':'toolchain unavailable'})
   _,code=run('native-dart',[sys.executable,str(root/'tools/scripts/verify_native_membership.py'),'--results',str(out/'dart')],cwd=root,allowed=(0,2))
   if code==2:blocked.append({'gate':'dart','reason':'required SDK absent'})
   # Running pure Dart on another host still does not run any actual platform acceptance.
  result={'schemaVersion':1,'phase':a.phase,'status':'blocked_release_gates' if blocked else 'passed_scoped_checks','testGroups':totals,'targetedTestsPassed':sum(totals.values()),'blockedGates':blocked,'installerTrials':trials,'steps':steps,'allSourcePaths':len(manifest['entries'])+len(manifest['preconditions']),'fullApplicationBuildVerified':False,'platformKeystoreVerified':False,'browserVerified':False,'realCloudflareRuntimeVerified':False,'driveUploads':0,'deployments':0,'productionReady':False}
  (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));return 2 if blocked else 0
if __name__=='__main__':sys.exit(main())
