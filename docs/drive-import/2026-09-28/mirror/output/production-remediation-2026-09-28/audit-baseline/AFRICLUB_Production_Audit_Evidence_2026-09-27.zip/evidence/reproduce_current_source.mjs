import {test} from 'node:test';
import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import worker from '../current/index.mjs.js';
import {fixture} from '../archive_checkout/cloudflare/supporter-auth/tests/support/fixture.mjs';
const observations=[];
test('current source: one fresh unrelated record masks an old news snapshot',async()=>{
 const old=new Date(Date.now()-48*3600_000).toISOString(),fresh=new Date().toISOString();
 const article={id:'1',approval_status:'approved',active:true,visibility:'public',status:'published',post_type:'news_feed',published_at:old,title:'Synthetic article',excerpt:'Synthetic stale snapshot',source_url:'https://example.invalid/a'};
 let maximum=old;
 const db={prepare(sql){return {bind(){return this;},async all(){return {results:[{payload_json:JSON.stringify(article)}]};},async first(){return {captured_at:maximum};}};}};
 let r=await worker.fetch(new Request('https://example.invalid/v1/public/rayon/news'),{RAYON_PUBLIC_DB:db});assert.equal(r.status,503);
 maximum=fresh;r=await worker.fetch(new Request('https://example.invalid/v1/public/rayon/news'),{RAYON_PUBLIC_DB:db});const body=await r.json();assert.equal(r.status,200);assert.equal(body.rows.length,1);
 observations.push({case:'mixed_snapshot',uniformlyOldStatus:503,oldNewsWithFreshUnrelatedRecordStatus:200,oldNewsReturned:true,sourceCapturedAt:body.sourceCapturedAt,simulation:'D1 reads only; no live deployment'});
});
test('current source: media bypasses freshness and compares size but not actual hash',async()=>{
 let freshnessReads=0;const db={prepare(sql){if(sql.includes('MAX(captured'))freshnessReads++;return {bind(){return this;},async first(){return {bytes:4,sha256:'0'.repeat(64),usage_scopes_json:'["public"]',usage_rights:'licensed',payload_json:JSON.stringify({approval_status:'approved',active:true,visibility:'public'})};}};}};
 const r=await worker.fetch(new Request('https://example.invalid/v1/public/rayon/media/10000000-0000-4000-8000-000000000001'),{RAYON_PUBLIC_DB:db,RAYON_PUBLIC_MEDIA:{async get(){return {size:4,body:'TEST',writeHttpMetadata(h){h.set('content-type','image/png');}};}}});
 assert.equal(r.status,200);assert.equal(freshnessReads,0);assert.equal(await r.text(),'TEST');observations.push({case:'media',status:200,freshnessReads,knownIncorrectDigestStillServed:true,simulation:'D1/R2 doubles; original Worker unchanged'});
});
test('current source: global OTP budget blocks another club after ten new challenges',async t=>{
 const f=fixture(t);f.clock.now=Math.floor(Date.now()/60000)*60000+1000;
 for(let i=1;i<=10;i++)await f.issue({phone:`+25070000${String(i).padStart(4,'0')}`,club:24});
 let code;try{await f.issue({phone:'+250700009999',club:26});}catch(e){code=e.code;}
 assert.equal(code,'rate_limited');assert.equal(f.count('auth_challenges'),10);observations.push({case:'global_otp_budget',acceptedAtClub24:10,club26EleventhRequest:code,simulation:'actual IdentityService with local SQLite and test keys; no messages sent'});
});
process.on('exit',()=>writeFileSync(new URL('current_source_observations.json',import.meta.url),JSON.stringify(observations,null,2)));
