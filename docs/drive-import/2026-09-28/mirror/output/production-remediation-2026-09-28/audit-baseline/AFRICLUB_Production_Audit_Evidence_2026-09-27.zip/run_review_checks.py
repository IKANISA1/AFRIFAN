from pathlib import Path
import subprocess,json,shutil,re,hashlib
B=Path('/mnt/data/africlub_production_audit'); E=B/'evidence'; C=B/'current'
def run(cmd,cwd,name,timeout=30):
 r=subprocess.run(cmd,cwd=cwd,text=True,capture_output=True,timeout=timeout)
 (E/(name+'.log')).write_text('$ '+' '.join(cmd)+'\n'+r.stdout+r.stderr)
 return {'case':name,'exitCode':r.returncode,'stdout':r.stdout[-2000:]}
f=B/'boundary_fixture';f.mkdir(exist_ok=True)
subprocess.run(['git','init','-q',str(f)],check=True)
for rel in ['packages/features/feat_gamification/lib/src/predict/predict_module.dart','packages/features/feat_gamification/lib/src/repositories/prediction_repository.dart','supabase/migrations/20260820080202_football_only_baseline.sql','supabase/tests/repository_boundary_contract.sql']:
 p=f/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('// Synthetic preservation fixture\n')
p=f/'packages/app_registry/lib/src/module_registry.dart';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('ClubModule();PredictModule();LiveModule();MembershipModule();TicketingModule();ShopModule();\n')
# Keep actual validator outside the enumerated fixture (same source bytes).
results=[run(['node',str(C/'validate_repository_boundary.mjs.js')],f,'boundary_minimal')]
p=f/'docs/architecture/cloudflare-stage0-live-inventory-2026-09-24.md';p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(C/p.name,p)
results.append(run(['node',str(C/'validate_repository_boundary.mjs.js')],f,'boundary_with_actual_inventory'))
(E/'boundary_reproduction.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
# Compare current source with exact original batch-1 proposed source.
import zipfile
z=zipfile.ZipFile('/mnt/data/AFRICLUB_Implemented_Source_Patch_2026-09-26.zip')
comparisons=[]
for fn,suffix in [('validate_repository_boundary.mjs.js','tools/scripts/validate_repository_boundary.mjs'),('index.mjs.js','cloudflare/rayon-public/src/index.mjs'),('pubspec.yaml','pubspec.yaml')]:
 matches=[n for n in z.namelist() if n.endswith('/source/'+suffix)]
 if not matches: matches=[n for n in z.namelist() if n.endswith('/'+suffix) and '/source/' in n]
 if matches:
  a=(C/fn).read_bytes();b=z.read(matches[0]); comparisons.append({'path':suffix,'currentSha256':hashlib.sha256(a).hexdigest(),'patchSha256':hashlib.sha256(b).hexdigest(),'currentBytes':len(a),'patchBytes':len(b),'equal':a==b})
(E/'current_vs_first_implemented_patch.json').write_text(json.dumps(comparisons,indent=2));print(comparisons)
