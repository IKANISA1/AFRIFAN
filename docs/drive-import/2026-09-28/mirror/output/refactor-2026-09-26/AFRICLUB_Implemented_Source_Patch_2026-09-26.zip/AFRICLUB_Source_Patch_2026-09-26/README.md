# AFRICLUB implemented source patch — 26 September 2026

**Delivery state: implemented and tested as a source patch; not installed into the
original Drive source files and not deployed.** The attempted in-place Drive
replacement returned HTTP 403 `appNotAuthorizedToFile`. This package preserves
original IDs and provides exact relative source paths instead of deleting or
silently replacing those originals.

The patch contains **47 source changes: 24 modifications and 23 additions**.
It is not a replacement repository or a completed Supabase-to-Cloudflare migration.
Read `IMPLEMENTATION_REPORT.md`, `remaining_actions.json`, and `changes.patch`.

## Apply to an authorized local AFRICLUB checkout

Use macOS or Linux and Python 3.10+. Stop builds, development servers and other
source editors before application: individual file writes are atomic, but the
whole multi-file update is not atomic for concurrent readers. Keep the bundle
outside the repository. The installer does not install dependencies or execute
any source application, migration, provider call, deployment or billing command.

First perform the read-only preflight:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB"
```

Then apply the checked source changes:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB" --apply
```

Every target must match the retrieved before-hash or the exact already-applied
payload hash. Every unchanged prerequisite and payload is checked too. A different
local edit stops the entire preflight. There is no force-overwrite option. Review
and reconcile a conflict rather than changing the hashes to bypass it.

The installer records exact original bytes and a journal under the checkout's
`output/refactor-backups/<run-id>/`. The printed `rollback_directory` identifies
that run. To restore that source patch:

```sh
python3 apply_patch.py --root "/path/to/AFRICLUB" \
  --rollback "/path/to/AFRICLUB/output/refactor-backups/<run-id>"
```

Rollback is scoped to this exact bundle and root, validates all backups before
restoring anything, and refuses to overwrite an unrecognized concurrent edit.
A regular apply failure attempts rollback; an interrupted process leaves its
journal for the same rollback command. Original file permissions are preserved;
new files receive the manifest's ordinary permission mode. Empty newly created
parent directories may remain. The source backup is **not a database backup**.

## Repeat the targeted tests without applying the patch

The bundle includes the seven unchanged context files required by the tests.
`verify_bundle.py` assembles a disposable source subset. It requires Python 3.10+,
Node with `node:sqlite` support, and Git. It does not need account credentials.

```sh
python3 verify_bundle.py --results "/tmp/africlub-patch-tests"
```

The executed baseline is **136 passing targeted tests**: 52 Node source tests,
60 Python source tests and 24 installer tests. These tests ran using Node 22.16.0
and Python 3.13. The repository's full web build requires Node >=22.22.2 <23 and
npm 12.0.2; the targeted run does not waive that requirement. Dart and Flutter
checks are supplied but were not executed because those SDKs were unavailable.

After application, resolve the repository's existing pinned toolchains and run:

```sh
dart run melos run verify_refactor --no-select
dart run melos run analyze --no-select
dart run melos run test_all --no-select
```

The full-checkout refactor command deliberately requires the repository Node
version and Dart. It does not substitute for the existing web, database,
release-artifact, accessibility, physical-device and provider integration gates.
It is a Melos command, not evidence that a hosted CI workflow already ran it.

## Cloudflare deployment boundary

The existing public Worker must not be deployed independently of its new source
module, forward schema migration and an approved active snapshot. Unpublished or
stale content deliberately returns an unavailable response. Preserve migrations
0001 and 0002 and add 0003 through the documented forward path. No migration was
applied to remote D1 during this work.

The private publication adapter has no HTTP publication endpoint and its staging
configuration defaults to disabled. It still needs a trusted authenticated and
club-authorized operator service binding. The adapter does **not** authenticate an
operator by accepting `approvedBy`; that value must be derived by the trusted
caller. Do not expose it directly to a browser or supporter app.

The R2 staging tool defaults to dry run. Its explicit execute mode targets the
identified staging bucket only. Neither publication nor media upload is performed
by this source installer.

## Package contents

`files/` contains the 47 exact source changes, `context/` contains seven unchanged
source prerequisites, and `manifest.json` contains source hashes and observed
Drive IDs. `changes.patch` is the human-readable unified diff. `source_manifest.json`
records the 31 downloaded baseline files. `evidence/` contains executed-test logs,
counts, hashes and the saved-inventory disposition register. `tests/` tests the
installer. `remaining_actions.json` distinguishes pending integration and release
work from the source changes delivered here.

Raw public-source rows, media originals, SQLite databases, credentials, private
account records, dependency caches and font files are not included. Existing
unreviewed `*.revised-20260926.*` copies in Drive were not deleted or presented as
canonical source. The new `legacy-reference-exceptions.json` was added to Drive,
but the original validator does not consume it until this patch is installed.
