70 scoped files: 60 upstream source/test/config references and ten recovered gateway files before this continuation. Not a complete repository, production data export or database backup.
